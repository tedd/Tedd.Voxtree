using System.Buffers.Binary;
using System.Runtime.CompilerServices;

namespace Tedd.Voxtree;

/// <summary>An immutable point-lookup snapshot with predecoded 32-bit child indexes.</summary>
/// <remarks>
/// Create with <see cref="Octree.CreateLookup"/> or <see cref="OctreeSpan.CreateLookup"/> when repeated reads justify compilation and
/// extra memory. Tree nodes occupy 36 bytes each. Dense storage is borrowed from the immutable
/// source snapshot when available; borrowed dense spans are copied. Uniform storage retains one value. Rebuilding the source does not change
/// this snapshot. Concurrent reads need no locks. Serialized bytes retain their existing format.
/// </remarks>
public sealed class OctreeLookup
{
    private const int NodeWords = 9;
    private readonly uint[]? _nodes;
    private readonly ReadOnlyMemory<byte> _dense;
    private readonly uint _uniform;

    internal OctreeLookup(ReadOnlySpan<byte> encoded, ReadOnlyMemory<byte> ownedEncoding)
    {
        var view = new OctreeSpan(encoded);
        if (!view.IsWellFormed()) throw new FormatException("The octree data is malformed.");
        Levels = view.Levels;
        var kind = OctreeCodec.GetStorageKindUnchecked(encoded);
        if (kind == StorageKind.Dense)
        {
            _dense = ownedEncoding.IsEmpty ? encoded.ToArray() : ownedEncoding;
            return;
        }
        if (kind == StorageKind.Uniform)
        {
            var cursor = OctreeCodec.HeaderSize;
            OctreeCodec.TryReadVarUInt(encoded, ref cursor, out _uniform);
            return;
        }

        var body = encoded[..^1];
        var root = body.Length - encoded[^1];
        _nodes = new uint[checked(CountNodes(body, root) * NodeWords)];
        var next = 0;
        Compile(body, root, _nodes, ref next);
    }

    /// <summary>The depth of the captured volume.</summary>
    public int Levels { get; }
    /// <summary>The number of voxels along each axis.</summary>
    public int SideLength => 1 << Levels;
    /// <summary>The number of represented voxels.</summary>
    public int Count => 1 << (Levels * 3);
    /// <summary>Backing payload bytes, excluding CLR object headers; dense bytes are shared with the source.</summary>
    public int StorageBytes => _nodes is not null ? _nodes.Length * sizeof(uint) :
        !_dense.IsEmpty ? _dense.Length : sizeof(uint);
    /// <summary>Gets a value from this snapshot.</summary>
    public uint this[int x, int y, int z] => Get(x, y, z);

    /// <summary>Gets a value, throwing when a coordinate is outside the volume.</summary>
    [MethodImpl(MethodImplOptions.AggressiveInlining)]
    public uint Get(int x, int y, int z)
    {
        if ((uint)x >= (uint)SideLength) return OctreeThrowHelper.ThrowCoordinate(nameof(x), x);
        if ((uint)y >= (uint)SideLength) return OctreeThrowHelper.ThrowCoordinate(nameof(y), y);
        if ((uint)z >= (uint)SideLength) return OctreeThrowHelper.ThrowCoordinate(nameof(z), z);
        return GetUnchecked(x, y, z);
    }

    /// <summary>Gets the voxel value and the LOD level of its stored leaf in one query.</summary>
    /// <param name="x">Voxel X coordinate.</param>
    /// <param name="y">Voxel Y coordinate.</param>
    /// <param name="z">Voxel Z coordinate.</param>
    /// <param name="lodLevel">Zero for a single voxel; N for an aligned uniform cube with side 2^N.
    /// Uniform storage returns <see cref="Levels"/>; dense storage returns zero.</param>
    /// <exception cref="ArgumentOutOfRangeException">A coordinate is outside the volume.</exception>
    public uint Get(int x, int y, int z, out int lodLevel)
    {
        lodLevel = 0;
        if ((uint)x >= (uint)SideLength) return OctreeThrowHelper.ThrowCoordinate(nameof(x), x);
        if ((uint)y >= (uint)SideLength) return OctreeThrowHelper.ThrowCoordinate(nameof(y), y);
        if ((uint)z >= (uint)SideLength) return OctreeThrowHelper.ThrowCoordinate(nameof(z), z);
        return GetUnchecked(x, y, z, out lodLevel);
    }

    /// <summary>Gets the stored leaf LOD level at a coordinate and returns its voxel value.</summary>
    /// <remarks>LOD zero is one voxel, and LOD N is an aligned uniform cube with side 2^N.
    /// Uniform storage returns <see cref="Levels"/>; dense storage returns zero.</remarks>
    public int GetLod(int x, int y, int z, out uint value)
    {
        value = Get(x, y, z, out var lodLevel);
        return lodLevel;
    }

    /// <summary>Attempts to get a value and its stored leaf LOD level; failure returns zero in both outputs.</summary>
    /// <remarks>LOD zero is one voxel, and LOD N is an aligned cube with side 2^N.
    /// Uniform storage returns <see cref="Levels"/>; dense storage returns zero.</remarks>
    public bool TryGet(int x, int y, int z, out uint value, out int lodLevel)
    {
        value = default;
        lodLevel = 0;
        if ((uint)(x | y | z) >= (uint)SideLength) return false;
        value = GetUnchecked(x, y, z, out lodLevel);
        return true;
    }

    /// <summary>Attempts a read, returning false for coordinates outside the volume.</summary>
    public bool TryGet(int x, int y, int z, out uint value)
    {
        if ((uint)(x | y | z) >= (uint)SideLength)
        {
            value = default;
            return false;
        }
        value = GetUnchecked(x, y, z);
        return true;
    }

    private uint GetUnchecked(int x, int y, int z)
        => GetUnchecked(x, y, z, out _);

    private uint GetUnchecked(int x, int y, int z, out int lodLevel)
    {
        lodLevel = 0;
        var nodes = _nodes;
        if (nodes is null)
        {
            if (_dense.IsEmpty)
            {
                lodLevel = Levels;
                return _uniform;
            }
            var index = ((x << Levels) + y) * SideLength + z;
            return BinaryPrimitives.ReadUInt32LittleEndian(_dense.Span.Slice(
                OctreeCodec.HeaderSize + index * sizeof(uint), sizeof(uint)));
        }
        var offset = 0;
        for (var bit = Levels - 1; bit >= 0; bit--)
        {
            var child = (((x >> bit) & 1) << 2) | (((y >> bit) & 1) << 1) | ((z >> bit) & 1);
            var token = nodes[offset + child + 1];
            if ((nodes[offset] & (1u << child)) != 0)
            {
                lodLevel = bit;
                return token;
            }
            offset = (int)token;
        }
        // Construction validates the complete source before compiling the private index.
        return OctreeThrowHelper.ThrowMalformed();
    }

    private static int CountNodes(ReadOnlySpan<byte> body, int offset)
    {
        var cursor = offset;
        var mask = body[cursor++];
        var count = 1;
        for (var child = 0; child < 8; child++)
        {
            OctreeCodec.TryReadVarUInt(body, ref cursor, out var token);
            if ((mask & (1 << child)) == 0) count += CountNodes(body, offset - (int)token);
        }
        return count;
    }

    private static int Compile(ReadOnlySpan<byte> body, int offset, uint[] nodes, ref int next)
    {
        var result = next;
        next += NodeWords;
        var cursor = offset;
        var mask = body[cursor++];
        nodes[result] = mask;
        for (var child = 0; child < 8; child++)
        {
            OctreeCodec.TryReadVarUInt(body, ref cursor, out var token);
            nodes[result + child + 1] = (mask & (1 << child)) != 0
                ? token : (uint)Compile(body, offset - (int)token, nodes, ref next);
        }
        return result;
    }
}

