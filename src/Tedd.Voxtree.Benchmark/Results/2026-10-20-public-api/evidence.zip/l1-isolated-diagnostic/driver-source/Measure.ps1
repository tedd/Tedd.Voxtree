param(
    [Parameter(Mandatory)][string]$Rig,
    [Parameter(Mandatory)][string]$LabHost,
    [Parameter(Mandatory)][string]$Workspace,
    [string]$Filter = '*',
    [string]$Label = 'exploration',
    [ValidateSet('fixed','scaled')][string]$Budget = 'fixed',
    [ValidateSet('quiet-validation','cpu-diagnostic')][string]$Profile = 'quiet-validation'
)
$ErrorActionPreference = 'Stop'
$dotnetExecutable = (Get-Command dotnet).Source
$env:TEMP = Join-Path $Workspace 'temp'
$env:TMP = $env:TEMP
New-Item -ItemType Directory -Path $Workspace,$env:TEMP -Force | Out-Null
$driverSnapshot = Join-Path $Workspace 'driver-source'
New-Item -ItemType Directory -Path $driverSnapshot -Force | Out-Null
Get-ChildItem -LiteralPath $PSScriptRoot -File | Where-Object { $_.Extension -eq '.ps1' -or $_.Name.EndsWith('.cs.txt') -or $_.Name -eq 'protocol.md' } | Copy-Item -Destination $driverSnapshot
. (Join-Path $PSScriptRoot 'Host-Lock.ps1')
$hostLeases = Enter-VoxtreePerformanceHost
$targetProcess = $null
$controller = $null
$rpcSequence = 0
try {
    function Invoke-Rpc([string]$Method, $Parameters) {
        $script:rpcSequence++
        $rpcId = $script:rpcSequence
        $rpc = @{jsonrpc='2.0';id=$rpcId;method=$Method;params=$Parameters} | ConvertTo-Json -Depth 60 -Compress
        $controller.StandardInput.WriteLine($rpc); $controller.StandardInput.Flush()
        while ($true) {
            $line = $controller.StandardOutput.ReadLine()
            if (-not $line) { throw 'Owned MCP controller exited unexpectedly; inspect its journal.' }
            $message = $line | ConvertFrom-Json -Depth 70
            if ($message.id -eq $rpcId) {
                if ($message.error) { throw ($message.error | ConvertTo-Json -Depth 30) }
                return $message.result
            }
        }
    }
    function Invoke-Lab([string]$Tool, $Request) {
        $ordered = [ordered]@{}
        if ($Request.ContainsKey('action')) { $ordered.action = $Request.action }
        if ($Request.ContainsKey('view')) { $ordered.view = $Request.view }
        foreach ($key in $Request.Keys) { if (-not $ordered.Contains($key)) { $ordered[$key] = $Request[$key] } }
        $payload = $ordered | ConvertTo-Json -Depth 40 -Compress
        if ($controller) {
            $rpcResult = Invoke-Rpc 'tools/call' @{name=$Tool;arguments=@{request=$ordered}}
            if ($rpcResult.structuredContent) { $parsed = $rpcResult.structuredContent }
            else { $parsed = $rpcResult.content[0].text | ConvertFrom-Json -Depth 60 }
            if ($parsed.status -ne 'ok') { throw ($parsed | ConvertTo-Json -Depth 40) }
            return $parsed.data
        }
        $response = $payload | & $dotnetExecutable exec --fx-version 10.0.13 $LabHost call $Workspace $Tool
        $parsed = $response | ConvertFrom-Json -Depth 50
        if ($LASTEXITCODE -ne 0 -or $parsed.status -ne 'ok') { throw ($response -join "`n") }
        return $parsed.data
    }
    & $dotnetExecutable exec --fx-version 10.0.13 $LabHost init $Workspace | Out-Null
    if ($LASTEXITCODE -ne 0) { throw 'Catalog initialization failed' }
    $start = [Diagnostics.ProcessStartInfo]::new($dotnetExecutable)
    $start.ArgumentList.Add('exec'); $start.ArgumentList.Add('--fx-version'); $start.ArgumentList.Add('10.0.13')
    $start.ArgumentList.Add($Rig); $start.ArgumentList.Add('--harness'); $start.ArgumentList.Add($Workspace)
    $start.UseShellExecute = $false; $start.CreateNoWindow = $true
    $start.RedirectStandardInput = $true; $start.RedirectStandardOutput = $true; $start.RedirectStandardError = $true
    $targetProcess = [Diagnostics.Process]::Start($start)
    $identityLine = $targetProcess.StandardOutput.ReadLine()
    if (-not $identityLine) { throw $targetProcess.StandardError.ReadToEnd() }
    $identity = $identityLine | ConvertFrom-Json
    $identityLine | Set-Content -LiteralPath (Join-Path $Workspace "$Label-target.json")
    $discovery = Invoke-Lab 'lab.discover' @{action='targets';limit=1000}
    $discovered = @($discovery.rows | Where-Object process_id -EQ $identity.process_id)
    if ($discovered.Count -ne 1 -or $discovered[0].target_id -ne $identity.id) { throw 'Harness/discovery identity mismatch' }
    $capabilities = Invoke-Lab 'lab.discover' @{action='capabilities';target_id=$identity.id}
    $capabilities | ConvertTo-Json -Depth 50 | Set-Content -LiteralPath (Join-Path $Workspace "$Label-capabilities.json")
    $scenarioDiscovery = Invoke-Lab 'lab.discover' @{action='scenarios';target_id=$identity.id}
    $scenarioDiscovery | ConvertTo-Json -Depth 50 | Set-Content -LiteralPath (Join-Path $Workspace "$Label-scenarios.json")
    $scenarios = @($scenarioDiscovery.scenarios)
    $selected = @($scenarios | Where-Object id -Like $Filter)
    if ($selected.Count -eq 0) { throw "No scenarios matched $Filter" }
    $plans = @()
    foreach ($scenario in $selected) {
        $operations = 256
        if ($Budget -eq 'scaled') {
            $operations = if ($scenario.id -like 'point-*') { if($scenario.id -like '*-create'){8}elseif($scenario.id -like '*-lifecycle'){1}else{8192} } elseif ($scenario.id -like 'query-*') { 16 } elseif ($scenario.id -like '*-random-*') { 16 } elseif ($scenario.id -like '*-uniform-*') { 4096 } elseif ($scenario.id -like '*-clustered-*') { 1024 } elseif ($scenario.id -like '*-sparse-*') { 128 } else { 256 }
        }
        $plan = Invoke-Lab 'lab.experiment' @{
            action='create_plan';scenario_id=$scenario.id;scenario_version=$scenario.version;input_hash=$scenario.input_hash
            variants=@('baseline','candidate');blocks=12;operations_per_run=$operations;warmup_batches=4;seed='20261020'
            profile=$Profile;independent_blocks=$false;confirmatory=$false;maximum_duration_seconds=120
            target_runtime_version='10.0.13'
            analysis=@{alpha_family=0.05;family_size=$selected.Count;equivalence_lower_ratio=0.95;equivalence_upper_ratio=1.05;useful_improvement_ratio=0.95;meaningful_regression_ratio=1.05;minimum_blocks=10}
        }
        $plans += [pscustomobject]@{scenario=$scenario.id;plan=$plan}
    }
    $plans | ConvertTo-Json -Depth 50 | Set-Content -LiteralPath (Join-Path $Workspace "$Label-plans.json")
    $runBudget = 24 * $selected.Count
    $grantText = & $dotnetExecutable exec --fx-version 10.0.13 $LabHost grant $Workspace $identity.process_id execute_registered_scenario 3600 $runBudget
    if ($LASTEXITCODE -ne 0) { throw $grantText }
    $grant = $grantText | ConvertFrom-Json
    $grantText | Set-Content -LiteralPath (Join-Path $Workspace "$Label-grant.json")
    $observationGrant = $null
    if ($Profile -ne 'quiet-validation') {
        $observationText = & $dotnetExecutable exec --fx-version 10.0.13 $LabHost grant $Workspace $identity.process_id observe 3600 $selected.Count
        if ($LASTEXITCODE -ne 0) { throw $observationText }
        $observationGrant = $observationText | ConvertFrom-Json
        $observationText | Set-Content -LiteralPath (Join-Path $Workspace "$Label-observation-grant.json")
    }
    $controllerStart = [Diagnostics.ProcessStartInfo]::new($dotnetExecutable)
    foreach ($argument in @('exec','--fx-version','10.0.13',$LabHost,'serve',$Workspace)) { $controllerStart.ArgumentList.Add($argument) }
    $controllerStart.UseShellExecute=$false; $controllerStart.CreateNoWindow=$true
    $controllerStart.RedirectStandardInput=$true; $controllerStart.RedirectStandardOutput=$true; $controllerStart.RedirectStandardError=$true
    $controller = [Diagnostics.Process]::Start($controllerStart)
    $controllerErrors = $controller.StandardError.ReadToEndAsync()
    Invoke-Rpc 'initialize' @{protocolVersion='2025-03-26';capabilities=@{};clientInfo=@{name='voxtree-performance';version='1'}} | Out-Null
    $controller.StandardInput.WriteLine('{"jsonrpc":"2.0","method":"notifications/initialized"}')
    Invoke-Lab 'lab.discover' @{action='scenarios';target_id=$identity.id} | Out-Null
    foreach ($item in $plans) {
        $request = @{action='start';target_id=$identity.id;expected_target_epoch=[string]$identity.epoch;plan_id=$item.plan.id;grant_id=$grant.id;idempotency_key="$Label-$($item.scenario)"}
        if ($observationGrant) { $request.observation_grant_id=$observationGrant.id }
        $request | ConvertTo-Json -Depth 30 | Set-Content -LiteralPath (Join-Path $Workspace "$Label-$($item.scenario)-request.json")
        $op = Invoke-Lab 'lab.run' $request
        $op | ConvertTo-Json -Depth 30 | Set-Content -LiteralPath (Join-Path $Workspace "$Label-$($item.scenario)-operation.json")
        while ($op.state -notin 'completed','failed','cancelled','lost','tainted','interrupted') {
            Start-Sleep -Milliseconds 100
            $op = Invoke-Lab 'lab.run' @{action='status';operation_id=$op.id}
        }
        if ($op.state -ne 'completed') { throw ($op | ConvertTo-Json -Depth 30) }
        $result = Invoke-Lab 'lab.inspect' @{action='record';id=$op.result_id}
        $execution = $result.json | ConvertFrom-Json -Depth 50
        if ($execution.capture_id) {
            $stackOperation=Invoke-Lab 'lab.run' @{action='analyze_stacks';capture_id=$execution.capture_id;idempotency_key="$Label-$($item.scenario)-stacks"}
            while ($stackOperation.state -notin 'completed','failed','tainted','cancelled','lost') {
                Start-Sleep -Milliseconds 100
                $stackOperation=Invoke-Lab 'lab.run' @{action='status';operation_id=$stackOperation.id}
            }
            $stackOperation | ConvertTo-Json -Depth 30 | Set-Content -LiteralPath (Join-Path $Workspace "$Label-$($item.scenario)-stack-operation.json")
            if ($stackOperation.state -ne 'completed') { throw 'Stack analysis failed; preserve capture and operation.' }
            foreach ($ranking in @('self','inclusive')) {
                Invoke-Lab 'lab.query' @{view='hotspots';result_id=$stackOperation.result_id;ranking=$ranking;limit=30} |
                    ConvertTo-Json -Depth 60 | Set-Content -LiteralPath (Join-Path $Workspace "$Label-$($item.scenario)-hotspots-$ranking.json")
            }
        }
        $runs = foreach ($runId in $execution.run_ids) { Invoke-Lab 'lab.inspect' @{action='record';id=$runId} }
        $runs | ConvertTo-Json -Depth 60 | Set-Content -LiteralPath (Join-Path $Workspace "$Label-$($item.scenario)-runs.json")
        $comparison = Invoke-Lab 'lab.compare' @{execution_id=$op.result_id;include_objectives=$true}
        $result | ConvertTo-Json -Depth 60 | Set-Content -LiteralPath (Join-Path $Workspace "$Label-$($item.scenario)-execution.json")
        $comparison | ConvertTo-Json -Depth 60 | Set-Content -LiteralPath (Join-Path $Workspace "$Label-$($item.scenario)-comparison.json")
        $effect = $comparison.effects_without_run_ids[0].effect
        Write-Output ($item.scenario + ' speedup=' + [Math]::Round(1 / $effect, 3))
    }
}
finally {
    if ($controller -and -not $controller.HasExited) {
        $controller.StandardInput.Close()
        if (-not $controller.WaitForExit(30000)) { throw 'Owned controller did not exit; preserve its workspace.' }
        $controllerErrors.GetAwaiter().GetResult() | Set-Content -LiteralPath (Join-Path $Workspace "$Label-controller.log")
    }
    if ($targetProcess -and -not $targetProcess.HasExited) {
        $targetProcess.StandardInput.WriteLine('shutdown'); $targetProcess.StandardInput.Close()
        if (-not $targetProcess.WaitForExit(30000)) { throw 'Owned harness did not exit; preserve its workspace.' }
    }
    Exit-VoxtreePerformanceHost $hostLeases
}
