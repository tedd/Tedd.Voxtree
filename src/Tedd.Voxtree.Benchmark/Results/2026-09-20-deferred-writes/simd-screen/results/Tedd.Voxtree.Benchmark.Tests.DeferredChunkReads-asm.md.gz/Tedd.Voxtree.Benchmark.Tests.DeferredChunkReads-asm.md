## .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v3 (Job: Job-GJBZFV(IterationCount=7, IterationTime=150ms, LaunchCount=1, WarmupCount=3))

```assembly
; Tedd.Voxtree.Benchmark.Tests.DeferredChunkReads.DeferredHits()
       push      r15
       push      r14
       push      r13
       push      r12
       push      rdi
       push      rsi
       push      rbp
       push      rbx
       sub       rsp,78
       vxorps    xmm4,xmm4,xmm4
       vmovdqu   ymmword ptr [rsp+40],ymm4
       vmovdqa   xmmword ptr [rsp+60],xmm4
       mov       rbx,rcx
       mov       rsi,[rbx+20]
       xor       edi,edi
       xor       ebp,ebp
       jmp       near ptr 00000000000098E7
M00_L00:
       mov       eax,edi
       vzeroupper
       add       rsp,78
       pop       rbx
       pop       rbp
       pop       rsi
       pop       rdi
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       ret
M00_L01:
       mov       r10,[rsp+38]
M00_L02:
       mov       r9d,0FFFFFFFF
M00_L03:
       test      r9d,r9d
       jl        near ptr 0000000000009AE8
       mov       r10,[rsp+38]
       mov       rcx,[r10+20]
       mov       eax,[rsp+74]
       mov       edx,eax
       imul      edx,[r10+2C]
       mov       r8d,r9d
       sar       r8d,6
       add       edx,r8d
       cmp       edx,[rcx+8]
       jae       near ptr 0000000000009C9F
       mov       rcx,[rcx+rdx*8+10]
       bt        rcx,r9
       jae       near ptr 0000000000009AEC
       mov       rcx,[r10+8]
       cmp       eax,[rcx+8]
       jae       near ptr 0000000000009C9F
       mov       edx,eax
       mov       rcx,[rcx+rdx*8+10]
       cmp       r9d,[rcx+8]
       jae       near ptr 0000000000009C9F
       mov       edx,r9d
       mov       r10d,[rcx+rdx*4+10]
M00_L04:
       add       edi,r10d
       inc       ebp
       cmp       ebp,100
       jge       near ptr 0000000000009850
M00_L05:
       cmp       ebp,[rsi+8]
       jae       near ptr 0000000000009C9F
       mov       r14d,[rsi+rbp*4+10]
       mov       r15,[rbx+18]
       mov       r13d,r14d
       sar       r13d,0A
       mov       r12d,r14d
       sar       r12d,5
       and       r12d,1F
       mov       eax,ebp
       and       eax,1
       mov       [rsp+74],eax
       and       r14d,1F
       cmp       byte ptr [r15+24],0
       jne       near ptr 0000000000009BE4
       mov       rdx,[r15+8]
       mov       rcx,[rdx+8]
       cmp       [rcx+8],eax
       jbe       near ptr 0000000000009C20
       mov       edx,[rdx+10]
       mov       ecx,edx
       and       ecx,1F
       mov       r8d,1
       shlx      r8d,r8d,ecx
       cmp       r13d,r8d
       jae       near ptr 0000000000009C5C
       cmp       r12d,r8d
       jae       near ptr 0000000000009C5C
       cmp       r14d,r8d
       jae       near ptr 0000000000009C5C
       add       edx,edx
       shlx      edx,r13d,edx
       shlx      ecx,r12d,ecx
       or        edx,ecx
       or        edx,r14d
       cmp       qword ptr [r15+10],0
       jne       short 00000000000099C6
       mov       r10,[r15+18]
       test      r10,r10
       je        short 00000000000099EB
       mov       [rsp+38],r10
       mov       ecx,[r10+30]
       test      ecx,ecx
       je        near ptr 000000000000986B
       mov       r8,[r10+10]
       test      r8,r8
       je        short 00000000000099F4
       cmp       ecx,1
       jne       near ptr 0000000000009A28
       cmp       dword ptr [r8+8],0
       jbe       near ptr 0000000000009C9F
       movzx     ecx,word ptr [r8+10]
       cmp       ecx,edx
       jne       near ptr 0000000000009866
       xor       r9d,r9d
       jmp       near ptr 0000000000009871
M00_L06:
       mov       eax,[rsp+74]
       mov       [rsp+20],r14d
       mov       rcx,[r15+10]
       mov       edx,eax
       mov       r8d,r13d
       mov       r9d,r12d
       cmp       [rcx],ecx
       call      qword ptr [0E958]; Tedd.Voxtree.HotOctreeChunk.get_Item(Int32, Int32, Int32, Int32)
       mov       r10d,eax
       jmp       near ptr 00000000000098D6
M00_L07:
       mov       eax,[rsp+74]
       jmp       near ptr 0000000000009AEC
M00_L08:
       mov       r10,[rsp+38]
       mov       r8,[r10+18]
       mov       r9d,ecx
       test      r8,r8
       je        near ptr 0000000000009C98
       cmp       [r8+8],r9d
       jb        near ptr 0000000000009C98
       lea       rcx,[r8+10]
       mov       r8d,r9d
       call      qword ptr [4768]; Precode of System.SpanHelpers.NonPackedIndexOfValueType[[System.Int32, System.Private.CoreLib],[System.SpanHelpers+DontNegate`1[[System.Int32, System.Private.CoreLib]], System.Private.CoreLib]](Int32 ByRef, Int32, Int32)
       mov       r9d,eax
       jmp       near ptr 0000000000009871
M00_L09:
       cmp       ecx,20
       jg        short 0000000000009AA1
       add       ecx,0F
       and       ecx,0FFFFFFF0
       cmp       [r8+8],ecx
       jb        near ptr 0000000000009C98
       add       r8,10
       mov       r9d,ecx
       add       r9,r9
       shr       r9,5
       cmp       r9,7FFFFFFF
       ja        near ptr 0000000000009CA5
       vmovd     xmm0,edx
       vpbroadcastw ymm0,xmm0
       xor       edx,edx
       jmp       short 0000000000009A7B
M00_L10:
       mov       ecx,edx
       shl       rcx,5
       vpcmpeqw  ymm1,ymm0,[r8+rcx]
       vpmovmskb ecx,ymm1
       test      ecx,ecx
       jne       short 0000000000009A8A
       inc       edx
M00_L11:
       cmp       edx,r9d
       jl        short 0000000000009A65
       mov       r10,[rsp+38]
       jmp       near ptr 000000000000986B
M00_L12:
       mov       r9d,edx
       shl       r9d,4
       xor       edx,edx
       tzcnt     edx,ecx
       sar       edx,1
       add       r9d,edx
       jmp       near ptr 0000000000009871
M00_L13:
       mov       r9d,ecx
       cmp       [r8+8],r9d
       jb        near ptr 0000000000009C98
       lea       rcx,[r8+10]
       movzx     edx,dx
       movsx     rdx,dx
       movzx     r8d,dx
       dec       r8d
       cmp       r8d,0FE
       jae       short 0000000000009AD7
       mov       r8d,r9d
       call      qword ptr [0C378]; System.PackedSpanHelpers.IndexOf[[System.SpanHelpers+DontNegate`1[[System.Int16, System.Private.CoreLib]], System.Private.CoreLib],[System.PackedSpanHelpers+NopTransform, System.Private.CoreLib]](Int16 ByRef, Int16, Int32)
       mov       r9d,eax
       jmp       short 0000000000009AE3
M00_L14:
       mov       r8d,r9d
       call      qword ptr [6220]
       mov       r9d,eax
M00_L15:
       jmp       near ptr 0000000000009871
M00_L16:
       mov       eax,[rsp+74]
M00_L17:
       mov       rcx,[r15+8]
       lea       rdx,[rsp+58]
       mov       r8d,eax
       cmp       [rcx],ecx
       call      qword ptr [0DAA0]; Tedd.Voxtree.OctreeChunk.GetChannel(Int32)
       xor       ecx,ecx
       mov       [rsp+50],ecx
       mov       edx,[rsp+68]
       cmp       dword ptr [rsp+60],0
       jne       short 0000000000009B1F
       call      qword ptr [0EA60]; Precode of Tedd.Voxtree.OctreeThrowHelper.ThrowInvalidView()
       mov       r10d,eax
       jmp       near ptr 0000000000009BDF
M00_L18:
       mov       ecx,1
       shlx      ecx,ecx,edx
       cmp       r13d,ecx
       jb        short 0000000000009B49
       mov       edx,r13d
       mov       rcx,24E802D2B18
       call      qword ptr [0EA78]; Precode of Tedd.Voxtree.OctreeThrowHelper.ThrowCoordinate(System.String, Int32)
       mov       r10d,eax
       jmp       near ptr 0000000000009BDF
M00_L19:
       mov       ecx,1
       shlx      ecx,ecx,edx
       cmp       r12d,ecx
       jb        short 0000000000009B70
       mov       edx,r12d
       mov       rcx,24E802E22F8
       call      qword ptr [0EA78]; Precode of Tedd.Voxtree.OctreeThrowHelper.ThrowCoordinate(System.String, Int32)
       mov       r10d,eax
       jmp       short 0000000000009BDF
M00_L20:
       mov       ecx,1
       shlx      ecx,ecx,edx
       cmp       r14d,ecx
       jb        short 0000000000009B97
       mov       edx,r14d
       mov       rcx,24E802E2310
       call      qword ptr [0EA78]; Precode of Tedd.Voxtree.OctreeThrowHelper.ThrowCoordinate(System.String, Int32)
       mov       r10d,eax
       jmp       short 0000000000009BDF
M00_L21:
       vmovdqu   xmm0,xmmword ptr [rsp+58]
       vmovdqu   xmmword ptr [rsp+40],xmm0
       mov       [rsp+20],r12d
       mov       [rsp+28],r14d
       lea       rcx,[rsp+50]
       mov       [rsp+30],rcx
       lea       rcx,[rsp+40]
       movzx     r8d,byte ptr [rsp+6C]
       mov       r9d,r13d
       call      qword ptr [0EA90]; Tedd.Voxtree.OctreeCodec.TryGetUnchecked(System.ReadOnlySpan`1<Byte>, Int32, Tedd.Voxtree.StorageKind, Int32, Int32, Int32, UInt32 ByRef)
       test      eax,eax
       jne       short 0000000000009BDA
       call      qword ptr [0EAA8]; Precode of Tedd.Voxtree.OctreeThrowHelper.ThrowMalformed()
       mov       r10d,eax
       jmp       short 0000000000009BDF
M00_L22:
       mov       r10d,[rsp+50]
M00_L23:
       jmp       near ptr 00000000000098D6
M00_L24:
       mov       rcx,offset MT_System.ObjectDisposedException
       call      0000000000005240
       mov       rbx,rax
       mov       ecx,3F5
       mov       rdx,7FF83A874B88
       call      qword ptr [7138]; Precode of System.String.StrCns(UInt32, IntPtr)
       mov       rdx,rax
       mov       rcx,rbx
       call      qword ptr [6D78]; Precode of System.ObjectDisposedException..ctor(System.String)
       mov       rcx,rbx
       call      000000000000B8A0
       int       3
M00_L25:
       mov       rcx,offset MT_System.ArgumentOutOfRangeException
       call      0000000000005240
       mov       rbx,rax
       mov       ecx,3E1
       mov       rdx,7FF83A874B88
       call      qword ptr [7138]; Precode of System.String.StrCns(UInt32, IntPtr)
       mov       rdx,rax
       mov       rcx,rbx
       call      qword ptr [0D338]; Precode of System.ArgumentOutOfRangeException..ctor(System.String)
       mov       rcx,rbx
       call      000000000000B8A0
       int       3
M00_L26:
       mov       rcx,offset MT_System.ArgumentOutOfRangeException
       call      0000000000005240
       mov       rbx,rax
       mov       ecx,3F1
       mov       rdx,7FF83A874B88
       call      qword ptr [7138]; Precode of System.String.StrCns(UInt32, IntPtr)
       mov       rdx,rax
       mov       rcx,rbx
       call      qword ptr [0D338]; Precode of System.ArgumentOutOfRangeException..ctor(System.String)
       mov       rcx,rbx
       call      000000000000B8A0
       int       3
M00_L27:
       call      qword ptr [7C18]; Precode of System.ThrowHelper.ThrowArgumentOutOfRangeException()
       int       3
M00_L28:
       call      0000000000001788
       int       3
M00_L29:
       call      0000000000001770
       int       3
; Total bytes of code 1163
```
```assembly
; Tedd.Voxtree.HotOctreeChunk.get_Item(Int32, Int32, Int32, Int32)
       push      rbp
       sub       rsp,40
       lea       rbp,[rsp+40]
       xor       eax,eax
       mov       [rbp+0FFF0],rax
       mov       [rbp+0FFF8],rax
       mov       [rbp+10],rcx
       mov       [rbp+18],edx
       mov       [rbp+20],r8d
       mov       [rbp+28],r9d
       lea       rdx,[rbp+0FFF0]
       mov       rcx,[rbp+10]
       mov       r8d,[rbp+18]
       call      qword ptr [0E880]; Tedd.Voxtree.HotOctreeChunk.GetChannelSpan(Int32)
       mov       rcx,[rbp+10]
       call      qword ptr [0E898]; Tedd.Voxtree.HotOctreeChunk.get_Levels()
       mov       [rbp+0FFE8],eax
       mov       dword ptr [rsp+20],1
       mov       r9d,[rbp+0FFE8]
       mov       edx,[rbp+28]
       mov       r8d,[rbp+30]
       mov       ecx,[rbp+20]
       call      qword ptr [0E8B0]; Tedd.Voxtree.DenseVoxel.GetIndex(Int32, Int32, Int32, Int32, Tedd.Voxtree.DenseVoxelLayout)
       mov       [rbp+0FFEC],eax
       mov       eax,[rbp+0FFF8]
       cmp       [rbp+0FFEC],eax
       jae       short 00000000000038E9
       mov       eax,[rbp+0FFEC]
       mov       rcx,[rbp+0FFF0]
       mov       eax,[rcx+rax*4]
       add       rsp,40
       pop       rbp
       ret
M01_L00:
       call      0000000000001788
       int       3
; Total bytes of code 127
```
```assembly
; System.SpanHelpers.NonPackedIndexOfValueType[[System.Int32, System.Private.CoreLib],[System.SpanHelpers+DontNegate`1[[System.Int32, System.Private.CoreLib]], System.Private.CoreLib]](Int32 ByRef, Int32, Int32)
       cmp       r8d,4
       jl        near ptr 0000000000000E5A
       movd      xmm0,edx
       pshufd    xmm0,xmm0,0
       mov       rdx,rcx
       lea       eax,[r8+0FFFC]
       cdqe
       shl       rax,2
       lea       r10,[rdx+rax]
       movups    xmm1,[rcx]
       pcmpeqd   xmm1,xmm0
       ptest     xmm1,xmm1
       je        short 0000000000000E13
M02_L00:
       movmskps  eax,xmm1
       bsf       r8d,eax
       mov       r10d,20
       test      eax,eax
       cmove     r8d,r10d
       mov       rax,rdx
       sub       rax,rcx
       shr       rax,2
       add       eax,r8d
M02_L01:
       ret
M02_L02:
       add       rdx,10
       cmp       rdx,r10
       jbe       near ptr 0000000000000F43
       mov       ecx,r8d
       test      cl,3
       je        near ptr 0000000000000F5A
       movups    xmm1,[r10]
       pcmpeqd   xmm1,xmm0
       ptest     xmm1,xmm1
       je        near ptr 0000000000000F5A
       movmskps  edx,xmm1
       bsf       r8d,edx
       mov       ecx,20
       test      edx,edx
       cmove     r8d,ecx
       shr       rax,2
       add       eax,r8d
       jmp       short 0000000000000E12
M02_L03:
       xor       r10d,r10d
       cmp       r8d,8
       jge       short 0000000000000E8D
M02_L04:
       cmp       r8d,4
       jge       short 0000000000000EDC
M02_L05:
       test      r8d,r8d
       jle       near ptr 0000000000000F5A
M02_L06:
       dec       r8d
       cmp       [rcx+r10*4],edx
       je        short 0000000000000E88
       inc       r10
       test      r8d,r8d
       jg        short 0000000000000E72
       jmp       near ptr 0000000000000F5A
M02_L07:
       mov       eax,r10d
       jmp       short 0000000000000E12
M02_L08:
       add       r8d,0FFFFFFF8
       cmp       [rcx+r10*4],edx
       je        short 0000000000000E88
       cmp       [rcx+r10*4+4],edx
       je        near ptr 0000000000000F3A
       cmp       [rcx+r10*4+8],edx
       je        near ptr 0000000000000F31
       cmp       [rcx+r10*4+0C],edx
       je        short 0000000000000F28
       cmp       [rcx+r10*4+10],edx
       je        short 0000000000000F1F
       cmp       [rcx+r10*4+14],edx
       je        short 0000000000000F16
       cmp       [rcx+r10*4+18],edx
       je        short 0000000000000F0D
       cmp       [rcx+r10*4+1C],edx
       je        short 0000000000000F04
       add       r10,8
       cmp       r8d,8
       jge       short 0000000000000E8D
       jmp       short 0000000000000E63
M02_L09:
       add       r8d,0FFFFFFFC
       cmp       [rcx+r10*4],edx
       je        short 0000000000000E88
       cmp       [rcx+r10*4+4],edx
       je        short 0000000000000F3A
       cmp       [rcx+r10*4+8],edx
       je        short 0000000000000F31
       cmp       [rcx+r10*4+0C],edx
       je        short 0000000000000F28
       add       r10,4
       jmp       near ptr 0000000000000E69
M02_L10:
       lea       eax,[r10+7]
       jmp       near ptr 0000000000000E12
M02_L11:
       lea       eax,[r10+6]
       jmp       near ptr 0000000000000E12
M02_L12:
       lea       eax,[r10+5]
       jmp       near ptr 0000000000000E12
M02_L13:
       lea       eax,[r10+4]
       jmp       near ptr 0000000000000E12
M02_L14:
       lea       eax,[r10+3]
       jmp       near ptr 0000000000000E12
M02_L15:
       lea       eax,[r10+2]
       jmp       near ptr 0000000000000E12
M02_L16:
       lea       eax,[r10+1]
       jmp       near ptr 0000000000000E12
M02_L17:
       movups    xmm1,[rdx]
       pcmpeqd   xmm1,xmm0
       ptest     xmm1,xmm1
       jne       near ptr 0000000000000DF2
       jmp       near ptr 0000000000000E13
M02_L18:
       mov       eax,0FFFFFFFF
       ret
; Total bytes of code 416
```
```assembly
; System.PackedSpanHelpers.IndexOf[[System.SpanHelpers+DontNegate`1[[System.Int16, System.Private.CoreLib]], System.Private.CoreLib],[System.PackedSpanHelpers+NopTransform, System.Private.CoreLib]](Int16 ByRef, Int16, Int32)
       push      r14
       push      rdi
       push      rsi
       push      rbp
       push      rbx
       sub       rsp,50
       vmovaps   [rsp+40],xmm6
       vmovaps   [rsp+30],xmm7
       vmovaps   [rsp+20],xmm8
       mov       rsi,rcx
       mov       edi,edx
       mov       ebx,r8d
       cmp       ebx,8
       jl        near ptr 000000000000D4FC
       mov       rbp,rsi
       cmp       ebx,10
       jle       near ptr 000000000000D479
       vmovd     xmm6,edi
       vpbroadcastb ymm6,xmm6
       cmp       ebx,20
       jle       near ptr 000000000000D3B4
       lea       ecx,[rbx+0FFE0]
       movsxd    rcx,ecx
       lea       rdi,[rbp+rcx*2]
       vmovups   ymm0,[rsi]
       vpackuswb ymm0,ymm0,[rsi+20]
       vpcmpeqb  ymm7,ymm0,ymm6
       vptest    ymm7,ymm7
       jne       short 000000000000D363
M03_L00:
       add       rbp,40
       cmp       rbp,rdi
       jae       short 000000000000D399
       mov       rcx,7FF83A4C8FF0
       vextractf128 xmm8,ymm6,1
       call      0000000000008420
       vmovups   ymm0,[rbp]
       vpackuswb ymm0,ymm0,[rbp+20]
       vinsertf128 ymm6,ymm6,xmm8,1
       vpcmpeqb  ymm7,ymm0,ymm6
       vptest    ymm7,ymm7
       je        short 000000000000D32A
M03_L01:
       mov       rcx,7FF83A4C8FE4
       vextractf128 xmm8,ymm7,1
       call      0000000000008420
       mov       rax,rbp
       sub       rax,rsi
       shr       rax,1
       vinsertf128 ymm7,ymm7,xmm8,1
       vpermq    ymm0,ymm7,0D8
       vpmovmskb ecx,ymm0
       tzcnt     ecx,ecx
       add       eax,ecx
       jmp       short 000000000000D3FC
M03_L02:
       mov       rcx,7FF83A4C8FEC
       vextractf128 xmm8,ymm6,1
       call      0000000000008420
       vinsertf128 ymm6,ymm6,xmm8,1
M03_L03:
       add       ebx,0FFFFFFF0
       movsxd    rcx,ebx
       lea       rbx,[rsi+rcx*2]
       cmp       rbp,rbx
       ja        short 000000000000D41C
       mov       rdi,rbp
M03_L04:
       vmovups   ymm0,[rdi]
       vpackuswb ymm0,ymm0,[rbx]
       vpcmpeqb  ymm6,ymm0,ymm6
       vptest    ymm6,ymm6
       jne       short 000000000000D43C
       mov       rcx,7FF83A4C8FFC
       call      0000000000008420
M03_L05:
       mov       rcx,7FF83A4C900C
       call      0000000000008420
       mov       eax,0FFFFFFFF
M03_L06:
       vzeroupper
       vmovaps   xmm6,[rsp+40]
       vmovaps   xmm7,[rsp+30]
       vmovaps   xmm8,[rsp+20]
       add       rsp,50
       pop       rbx
       pop       rbp
       pop       rsi
       pop       rdi
       pop       r14
       ret
M03_L07:
       mov       rcx,7FF83A4C8FF4
       vextractf128 xmm8,ymm6,1
       call      0000000000008420
       mov       rdi,rbx
       vinsertf128 ymm6,ymm6,xmm8,1
       jmp       short 000000000000D3C6
M03_L08:
       mov       rcx,7FF83A4C8FF8
       vextractf128 xmm7,ymm6,1
       call      0000000000008420
       vinsertf128 ymm6,ymm6,xmm7,1
       vpermq    ymm0,ymm6,0D8
       vpmovmskb ecx,ymm0
       tzcnt     ecx,ecx
       cmp       ecx,10
       jge       near ptr 000000000000D650
M03_L09:
       sub       rdi,rsi
       shr       rdi,1
       lea       eax,[rdi+rcx]
       jmp       short 000000000000D3FC
M03_L10:
       mov       rcx,7FF83A4C8FE8
       call      0000000000008420
       vmovd     xmm6,edi
       vpbroadcastb xmm6,xmm6
       lea       ecx,[rbx+0FFF8]
       movsxd    rcx,ecx
       lea       rbx,[rsi+rcx*2]
       cmp       rsi,rbx
       ja        near ptr 000000000000D65B
       mov       rdi,rsi
M03_L11:
       vmovups   xmm0,[rdi]
       vpackuswb xmm0,xmm0,[rbx]
       vpcmpeqb  xmm6,xmm0,xmm6
       vptest    xmm6,xmm6
       jne       short 000000000000D4CE
       mov       rcx,7FF83A4C9008
       call      0000000000008420
       jmp       near ptr 000000000000D3E8
M03_L12:
       mov       rcx,7FF83A4C9004
       call      0000000000008420
       vpmovmskb ecx,xmm6
       tzcnt     ecx,ecx
       cmp       ecx,8
       jge       near ptr 000000000000D672
M03_L13:
       sub       rdi,rsi
       shr       rdi,1
       lea       eax,[rdi+rcx]
       jmp       near ptr 000000000000D3FC
M03_L14:
       xor       ebp,ebp
       cmp       ebx,4
       jl        short 000000000000D555
       add       ebx,0FFFFFFFC
       movsx     rcx,word ptr [rsi]
       movsx     r14,di
       cmp       ecx,r14d
       je        near ptr 000000000000D59E
       movsx     rcx,word ptr [rsi+2]
       cmp       ecx,r14d
       je        near ptr 000000000000D5CF
       movsx     rcx,word ptr [rsi+4]
       cmp       ecx,r14d
       je        near ptr 000000000000D603
       movsx     rcx,word ptr [rsi+6]
       cmp       ecx,r14d
       je        near ptr 000000000000D637
       mov       rcx,7FF83A4C8FD8
       call      0000000000008420
       mov       ebp,4
M03_L15:
       test      ebx,ebx
       jle       near ptr 000000000000D3E8
       movsx     r14,di
M03_L16:
       dec       ebx
       movsx     rcx,word ptr [rsi+rbp*2]
       cmp       ecx,r14d
       je        short 000000000000D588
       mov       rcx,7FF83A4C8FE0
       call      0000000000008420
       inc       rbp
       test      ebx,ebx
       jg        short 000000000000D561
       jmp       near ptr 000000000000D3E8
M03_L17:
       mov       rcx,7FF83A4C8FDC
       call      0000000000008420
       mov       eax,ebp
       jmp       near ptr 000000000000D3FC
M03_L18:
       mov       rcx,7FF83A4C8FC8
       call      0000000000008420
       xor       eax,eax
       vzeroupper
       vmovaps   xmm6,[rsp+40]
       vmovaps   xmm7,[rsp+30]
       vmovaps   xmm8,[rsp+20]
       add       rsp,50
       pop       rbx
       pop       rbp
       pop       rsi
       pop       rdi
       pop       r14
       ret
M03_L19:
       mov       rcx,7FF83A4C8FCC
       call      0000000000008420
       mov       eax,1
       vzeroupper
       vmovaps   xmm6,[rsp+40]
       vmovaps   xmm7,[rsp+30]
       vmovaps   xmm8,[rsp+20]
       add       rsp,50
       pop       rbx
       pop       rbp
       pop       rsi
       pop       rdi
       pop       r14
       ret
M03_L20:
       mov       rcx,7FF83A4C8FD0
       call      0000000000008420
       mov       eax,2
       vzeroupper
       vmovaps   xmm6,[rsp+40]
       vmovaps   xmm7,[rsp+30]
       vmovaps   xmm8,[rsp+20]
       add       rsp,50
       pop       rbx
       pop       rbp
       pop       rsi
       pop       rdi
       pop       r14
       ret
M03_L21:
       mov       rcx,7FF83A4C8FD4
       call      0000000000008420
       mov       eax,3
       jmp       near ptr 000000000000D3FC
M03_L22:
       mov       rdi,rbx
       add       ecx,0FFFFFFF0
       jmp       near ptr 000000000000D46E
M03_L23:
       mov       rcx,7FF83A4C9000
       call      0000000000008420
       mov       rdi,rbx
       jmp       near ptr 000000000000D4A7
M03_L24:
       mov       rdi,rbx
       add       ecx,0FFFFFFF8
       jmp       near ptr 000000000000D4EE
; Total bytes of code 957
```
```assembly
; Tedd.Voxtree.OctreeChunk.GetChannel(Int32)
       push      rbp
       sub       rsp,70
       lea       rbp,[rsp+70]
       xor       eax,eax
       mov       [rbp+0FFB8],rax
       vxorps    xmm4,xmm4,xmm4
       vmovdqu   ymmword ptr [rbp+0FFC0],ymm4
       vmovdqu   ymmword ptr [rbp+0FFE0],ymm4
       mov       [rbp+10],rcx
       mov       [rbp+18],rdx
       mov       [rbp+20],r8d
       lea       rdx,[rbp+0FFE0]
       mov       rcx,[rbp+10]
       mov       r8d,[rbp+20]
       call      qword ptr [0DB00]; Tedd.Voxtree.OctreeChunk.GetChannelData(Int32)
       lea       rdx,[rbp+0FFF0]
       lea       rcx,[rbp+0FFE0]
       call      qword ptr [0DAD0]; System.ReadOnlyMemory`1[[System.Byte, System.Private.CoreLib]].get_Span()
       mov       rcx,[rbp+10]
       call      qword ptr [0DA10]; Tedd.Voxtree.OctreeChunk.get_Levels()
       mov       [rbp+0FFDC],eax
       vmovdqu   xmm0,xmmword ptr [rbp+0FFF0]
       vmovdqu   xmmword ptr [rbp+0FFC8],xmm0
       vmovdqu   xmm0,xmmword ptr [rbp+0FFF0]
       vmovdqu   xmmword ptr [rbp+0FFB8],xmm0
       lea       rcx,[rbp+0FFB8]
       call      qword ptr [0D8A8]; Tedd.Voxtree.OctreeCodec.GetStorageKindUnchecked(System.ReadOnlySpan`1<Byte>)
       mov       [rbp+0FFB4],eax
       mov       r9d,[rbp+0FFB4]
       lea       rdx,[rbp+0FFC8]
       mov       r8d,[rbp+0FFDC]
       mov       rcx,[rbp+18]
       call      qword ptr [0DB18]; Tedd.Voxtree.OctreeSpan.CreateTrusted(System.ReadOnlySpan`1<Byte>, Int32, Tedd.Voxtree.StorageKind)
       mov       rax,[rbp+18]
       add       rsp,70
       pop       rbp
       ret
; Total bytes of code 152
```
```assembly
; Tedd.Voxtree.OctreeCodec.TryGetUnchecked(System.ReadOnlySpan`1<Byte>, Int32, Tedd.Voxtree.StorageKind, Int32, Int32, Int32, UInt32 ByRef)
       push      rbp
       sub       rsp,130
       lea       rbp,[rsp+130]
       vxorps    xmm4,xmm4,xmm4
       vmovdqa   xmmword ptr [rbp+0FEF0],xmm4
       mov       rax,0FFFFFFFFFF40
M05_L00:
       vmovdqa   xmmword ptr [rbp+rax+0FFC0],xmm4
       vmovdqa   xmmword ptr [rbp+rax+0FFD0],xmm4
       vmovdqa   xmmword ptr [rbp+rax+0FFE0],xmm4
       add       rax,30
       jne       short 0000000000005056
       mov       [rbp+0FFC0],rax
       mov       [rbp+10],rcx
       mov       [rbp+18],edx
       mov       [rbp+20],r8d
       mov       [rbp+28],r9d
       mov       dword ptr [rbp+0FF38],3E8
       mov       rax,[rbp+40]
       xor       ecx,ecx
       mov       [rax],ecx
       mov       eax,1
       mov       ecx,[rbp+18]
       shlx      eax,eax,ecx
       mov       [rbp+0FFC4],eax
       movzx     eax,byte ptr [rbp+20]
       cmp       eax,1
       jne       short 000000000000511A
       mov       dword ptr [rbp+0FFA0],2
       mov       rax,[rbp+10]
       vmovdqu   xmm0,xmmword ptr [rax]
       vmovdqu   xmmword ptr [rbp+0FF20],xmm0
       lea       rcx,[rbp+0FF20]
       lea       rdx,[rbp+0FFA0]
       mov       r8,[rbp+40]
       call      qword ptr [0D6C8]; Tedd.Voxtree.OctreeCodec.TryReadVarUInt(System.ReadOnlySpan`1<Byte>, Int32 ByRef, UInt32 ByRef)
       test      eax,eax
       je        short 0000000000005106
       mov       rcx,7FF83A916700
       call      0000000000008420
       mov       eax,[rbp+0FFA0]
       mov       rcx,[rbp+10]
       cmp       eax,[rcx+8]
       sete      al
       movzx     eax,al
       mov       [rbp+0FF34],eax
       jmp       near ptr 0000000000005522
M05_L01:
       mov       rcx,7FF83A916704
       call      0000000000008420
       jmp       near ptr 0000000000005517
M05_L02:
       movzx     eax,byte ptr [rbp+20]
       cmp       eax,2
       jne       short 000000000000519C
       mov       rcx,7FF83A916708
       call      0000000000008420
       mov       eax,[rbp+28]
       imul      eax,[rbp+0FFC4]
       imul      eax,[rbp+0FFC4]
       mov       ecx,[rbp+30]
       imul      ecx,[rbp+0FFC4]
       add       eax,ecx
       add       eax,[rbp+38]
       mov       [rbp+0FF9C],eax
       mov       eax,[rbp+0FF9C]
       lea       eax,[rax*4+2]
       mov       [rbp+0FF98],eax
       lea       rdx,[rbp+0FF40]
       mov       rcx,[rbp+10]
       mov       r8d,[rbp+0FF98]
       mov       r9d,4
       call      qword ptr [6310]; System.ReadOnlySpan`1[[System.Byte, System.Private.CoreLib]].Slice(Int32, Int32)
       vmovdqu   xmm0,xmmword ptr [rbp+0FF40]
       vmovdqu   xmmword ptr [rbp+0FF10],xmm0
       lea       rcx,[rbp+0FF10]
       call      qword ptr [0EAC0]; Precode of System.Buffers.Binary.BinaryPrimitives.ReadUInt32LittleEndian(System.ReadOnlySpan`1<Byte>)
       mov       rcx,[rbp+40]
       mov       [rcx],eax
       jmp       near ptr 0000000000005457
M05_L03:
       cmp       dword ptr [rbp+18],0
       je        short 00000000000051BB
       mov       rax,[rbp+10]
       cmp       dword ptr [rax+8],0C
       jge       short 00000000000051CF
       mov       rcx,7FF83A91670C
       call      0000000000008420
M05_L04:
       mov       rcx,7FF83A916710
       call      0000000000008420
       jmp       near ptr 0000000000005517
M05_L05:
       mov       rax,[rbp+10]
       mov       [rbp+0FF90],rax
       lea       rdx,[rbp+0FFB0]
       mov       rax,[rbp+0FF90]
       mov       eax,[rax+8]
       lea       r9d,[rax+0FFFF]
       mov       rcx,[rbp+0FF90]
       xor       r8d,r8d
       call      qword ptr [6310]; System.ReadOnlySpan`1[[System.Byte, System.Private.CoreLib]].Slice(Int32, Int32)
       mov       rax,[rbp+10]
       mov       eax,[rax+8]
       dec       eax
       mov       [rbp+0FF54],eax
       mov       rax,[rbp+10]
       mov       eax,[rax+8]
       cmp       [rbp+0FF54],eax
       jae       near ptr 0000000000005532
       mov       rax,[rbp+10]
       mov       rax,[rax]
       mov       ecx,[rbp+0FF54]
       movzx     eax,byte ptr [rax+rcx]
       mov       [rbp+0FFAC],eax
       mov       eax,[rbp+0FFB8]
       sub       eax,[rbp+0FFAC]
       mov       [rbp+0FFA8],eax
       cmp       dword ptr [rbp+0FFAC],9
       jl        short 000000000000524D
       cmp       dword ptr [rbp+0FFAC],29
       jle       short 0000000000005256
       mov       rcx,7FF83A916714
       call      0000000000008420
M05_L06:
       mov       dword ptr [rbp+0FF8C],1
       jmp       short 000000000000526A
M05_L07:
       mov       rcx,7FF83A916718
       call      0000000000008420
       xor       eax,eax
       mov       [rbp+0FF8C],eax
M05_L08:
       cmp       dword ptr [rbp+0FF8C],0
       jne       short 0000000000005285
       cmp       dword ptr [rbp+0FFA8],2
       jge       short 0000000000005299
       mov       rcx,7FF83A91671C
       call      0000000000008420
M05_L09:
       mov       rcx,7FF83A916720
       call      0000000000008420
       jmp       near ptr 0000000000005517
M05_L10:
       mov       eax,[rbp+18]
       dec       eax
       mov       [rbp+0FF88],eax
       jmp       near ptr 00000000000054D6
M05_L11:
       mov       eax,[rbp+0FFA8]
       mov       [rbp+0FF84],eax
       mov       eax,[rbp+0FF84]
       cmp       eax,[rbp+0FFB8]
       jb        short 00000000000052C8
       mov       rcx,7FF83A916724
       call      0000000000008420
       jmp       near ptr 0000000000005517
M05_L12:
       mov       eax,[rbp+0FF84]
       mov       [rbp+0FF78],eax
       mov       eax,[rbp+0FF78]
       mov       [rbp+0FF50],eax
       mov       eax,[rbp+0FF78]
       inc       eax
       mov       [rbp+0FF78],eax
       mov       eax,[rbp+0FFB8]
       cmp       [rbp+0FF50],eax
       jae       near ptr 0000000000005532
       mov       eax,[rbp+0FF50]
       mov       rcx,[rbp+0FFB0]
       movzx     eax,byte ptr [rcx+rax]
       mov       [rbp+0FF74],eax
       mov       eax,[rbp+0FF88]
       sarx      eax,[rbp+28],eax
       and       eax,1
       shl       eax,2
       mov       ecx,[rbp+0FF88]
       sarx      ecx,[rbp+30],ecx
       and       ecx,1
       add       ecx,ecx
       or        eax,ecx
       mov       ecx,[rbp+0FF88]
       sarx      ecx,[rbp+38],ecx
       and       ecx,1
       or        eax,ecx
       mov       [rbp+0FF70],eax
       xor       eax,eax
       mov       [rbp+0FF64],eax
       jmp       short 00000000000053A8
M05_L13:
       vmovdqu   xmm0,xmmword ptr [rbp+0FFB0]
       vmovdqu   xmmword ptr [rbp+0FF00],xmm0
       lea       rcx,[rbp+0FF00]
       lea       r8,[rbp+0FF58]
       lea       rdx,[rbp+0FF78]
       call      qword ptr [0D6C8]; Tedd.Voxtree.OctreeCodec.TryReadVarUInt(System.ReadOnlySpan`1<Byte>, Int32 ByRef, UInt32 ByRef)
       test      eax,eax
       jne       short 000000000000538B
       mov       rcx,7FF83A916728
       call      0000000000008420
       jmp       near ptr 0000000000005517
M05_L14:
       mov       rcx,7FF83A91672C
       call      0000000000008420
       mov       eax,[rbp+0FF64]
       inc       eax
       mov       [rbp+0FF64],eax
M05_L15:
       mov       eax,[rbp+0FF38]
       dec       eax
       mov       [rbp+0FF38],eax
       cmp       dword ptr [rbp+0FF38],0
       jg        short 00000000000053D0
       lea       rcx,[rbp+0FF38]
       mov       edx,125
       call      0000000000003990
M05_L16:
       mov       eax,[rbp+0FF64]
       cmp       eax,[rbp+0FF70]
       jl        near ptr 000000000000534B
       vmovdqu   xmm0,xmmword ptr [rbp+0FFB0]
       vmovdqu   xmmword ptr [rbp+0FEF0],xmm0
       lea       rcx,[rbp+0FEF0]
       lea       r8,[rbp+0FF68]
       lea       rdx,[rbp+0FF78]
       call      qword ptr [0D6C8]; Tedd.Voxtree.OctreeCodec.TryReadVarUInt(System.ReadOnlySpan`1<Byte>, Int32 ByRef, UInt32 ByRef)
       test      eax,eax
       jne       short 0000000000005422
       mov       rcx,7FF83A916730
       call      0000000000008420
       jmp       near ptr 0000000000005517
M05_L17:
       mov       eax,1
       mov       ecx,[rbp+0FF70]
       shlx      eax,eax,ecx
       and       eax,[rbp+0FF74]
       test      eax,eax
       je        short 0000000000005465
       mov       rcx,7FF83A916734
       call      0000000000008420
       mov       rax,[rbp+40]
       mov       ecx,[rbp+0FF68]
       mov       [rax],ecx
M05_L18:
       mov       eax,1
       add       rsp,130
       pop       rbp
       ret
M05_L19:
       cmp       dword ptr [rbp+0FF88],0
       je        short 0000000000005491
       cmp       dword ptr [rbp+0FF68],0
       je        short 00000000000054A2
       mov       eax,[rbp+0FF84]
       add       eax,0FFFFFFFE
       cmp       [rbp+0FF68],eax
       jbe       short 00000000000054B3
       mov       rcx,7FF83A916738
       call      0000000000008420
M05_L20:
       mov       rcx,7FF83A91673C
       call      0000000000008420
       jmp       short 0000000000005517
M05_L21:
       mov       rcx,7FF83A916740
       call      0000000000008420
       jmp       short 0000000000005491
M05_L22:
       mov       rcx,7FF83A916744
       call      0000000000008420
       mov       eax,[rbp+0FF84]
       sub       eax,[rbp+0FF68]
       mov       [rbp+0FFA8],eax
       mov       eax,[rbp+0FF88]
       dec       eax
       mov       [rbp+0FF88],eax
M05_L23:
       mov       eax,[rbp+0FF38]
       dec       eax
       mov       [rbp+0FF38],eax
       cmp       dword ptr [rbp+0FF38],0
       jg        short 00000000000054FE
       lea       rcx,[rbp+0FF38]
       mov       edx,16A
       call      0000000000003990
M05_L24:
       cmp       dword ptr [rbp+0FF88],0
       jge       near ptr 00000000000052A6
       mov       rcx,7FF83A916748
       call      0000000000008420
M05_L25:
       xor       eax,eax
       add       rsp,130
       pop       rbp
       ret
M05_L26:
       movzx     eax,byte ptr [rbp+0FF34]
       add       rsp,130
       pop       rbp
       ret
M05_L27:
       call      0000000000001788
       int       3
; Total bytes of code 1288
```
```assembly
; Tedd.Voxtree.HotOctreeChunk.GetChannelSpan(Int32)
       push      rbp
       sub       rsp,50
       lea       rbp,[rsp+50]
       xor       eax,eax
       mov       [rbp+0FFD8],rax
       vxorps    xmm4,xmm4,xmm4
       vmovdqu   ymmword ptr [rbp+0FFE0],ymm4
       mov       [rbp+10],rcx
       mov       [rbp+18],rdx
       mov       [rbp+20],r8d
       mov       rcx,[rbp+10]
       call      qword ptr [0E8E0]; Tedd.Voxtree.HotOctreeChunk.GetValues()
       mov       [rbp+0FFF0],rax
       mov       rax,[rbp+0FFF0]
       mov       [rbp+0FFE8],rax
       mov       rcx,[rbp+10]
       call      qword ptr [0E8F8]; Tedd.Voxtree.HotOctreeChunk.get_ChannelCount()
       cmp       eax,[rbp+20]
       ja        short 0000000000002F0E
       mov       rcx,offset MT_System.ArgumentOutOfRangeException
       call      0000000000005240
       mov       [rbp+0FFE0],rax
       mov       ecx,3E1
       mov       rdx,7FF83A874B88
       call      qword ptr [7138]; Precode of System.String.StrCns(UInt32, IntPtr)
       mov       [rbp+0FFD8],rax
       mov       rdx,[rbp+0FFD8]
       mov       rcx,[rbp+0FFE0]
       call      qword ptr [0D338]; Precode of System.ArgumentOutOfRangeException..ctor(System.String)
       mov       rcx,[rbp+0FFE0]
       call      000000000000B8A0
       int       3
M06_L00:
       mov       rcx,[rbp+10]
       call      qword ptr [0E898]; Tedd.Voxtree.HotOctreeChunk.get_Levels()
       mov       ecx,eax
       call      qword ptr [0D320]; Tedd.Voxtree.OctreeCodec.GetVoxelCount(Int32)
       mov       [rbp+0FFFC],eax
       mov       eax,[rbp+20]
       mov       r8d,eax
       imul      r8d,[rbp+0FFFC]
       mov       rcx,[rbp+18]
       mov       rdx,[rbp+0FFE8]
       mov       r9d,[rbp+0FFFC]
       call      qword ptr [0E8C8]; System.MemoryExtensions.AsSpan[[System.UInt32, System.Private.CoreLib]](UInt32[], Int32, Int32)
       mov       rax,[rbp+18]
       add       rsp,50
       pop       rbp
       ret
; Total bytes of code 202
```
```assembly
; Tedd.Voxtree.HotOctreeChunk.get_Levels()
       push      rbp
       mov       rbp,rsp
       mov       [rbp+10],rcx
       mov       rax,[rbp+10]
       mov       eax,[rax+20]
       pop       rbp
       ret
; Total bytes of code 17
```
```assembly
; Tedd.Voxtree.DenseVoxel.GetIndex(Int32, Int32, Int32, Int32, Tedd.Voxtree.DenseVoxelLayout)
       push      rbp
       sub       rsp,40
       lea       rbp,[rsp+40]
       vxorps    xmm4,xmm4,xmm4
       vmovdqu   xmmword ptr [rbp+0FFE8],xmm4
       xor       eax,eax
       mov       [rbp+0FFF8],rax
       mov       [rbp+10],ecx
       mov       [rbp+18],edx
       mov       [rbp+20],r8d
       mov       [rbp+28],r9d
       mov       ecx,[rbp+28]
       call      qword ptr [0D308]; Tedd.Voxtree.OctreeCodec.ValidateLevels(Int32)
       mov       ecx,[rbp+30]
       call      qword ptr [0D200]; Tedd.Voxtree.DenseVoxel.Validate(Tedd.Voxtree.DenseVoxelLayout)
       mov       eax,1
       mov       ecx,[rbp+28]
       shlx      eax,eax,ecx
       mov       [rbp+0FFFC],eax
       mov       eax,[rbp+10]
       cmp       eax,[rbp+0FFFC]
       jae       short 00000000000032F0
       mov       eax,[rbp+18]
       cmp       eax,[rbp+0FFFC]
       jae       short 0000000000003334
       mov       eax,[rbp+20]
       cmp       eax,[rbp+0FFFC]
       jb        short 0000000000003345
       mov       rcx,7FF83A938020
       call      0000000000008420
M08_L00:
       mov       rcx,offset MT_System.ArgumentOutOfRangeException
       call      0000000000005240
       mov       [rbp+0FFF0],rax
       mov       ecx,3F1
       mov       rdx,7FF83A874B88
       call      qword ptr [7138]; Precode of System.String.StrCns(UInt32, IntPtr)
       mov       [rbp+0FFE8],rax
       mov       rdx,[rbp+0FFE8]
       mov       rcx,[rbp+0FFF0]
       call      qword ptr [0D338]; Precode of System.ArgumentOutOfRangeException..ctor(System.String)
       mov       rcx,[rbp+0FFF0]
       call      000000000000B8A0
       int       3
M08_L01:
       mov       rcx,7FF83A938024
       call      0000000000008420
       jmp       short 00000000000032F0
M08_L02:
       mov       rcx,7FF83A938028
       call      0000000000008420
       mov       eax,[rbp+30]
       mov       [rsp+20],eax
       mov       ecx,[rbp+10]
       mov       edx,[rbp+18]
       mov       r8d,[rbp+20]
       mov       r9d,[rbp+0FFFC]
       call      qword ptr [0E910]; Tedd.Voxtree.DenseVoxel.Index(Int32, Int32, Int32, Int32, Tedd.Voxtree.DenseVoxelLayout)
       nop
       add       rsp,40
       pop       rbp
       ret
; Total bytes of code 246
```
```assembly
; Tedd.Voxtree.OctreeChunk.GetChannelData(Int32)
       push      rbp
       sub       rsp,30
       lea       rbp,[rsp+30]
       xor       eax,eax
       mov       [rbp+0FFF8],rax
       mov       [rbp+0FFF0],rax
       mov       [rbp+10],rcx
       mov       [rbp+18],rdx
       mov       [rbp+20],r8d
       mov       rcx,[rbp+10]
       call      qword ptr [0DA28]; Tedd.Voxtree.OctreeChunk.get_ChannelCount()
       cmp       eax,[rbp+20]
       ja        short 0000000000004CD3
       mov       rcx,offset MT_System.ArgumentOutOfRangeException
       call      0000000000005240
       mov       [rbp+0FFF8],rax
       mov       ecx,3E1
       mov       rdx,7FF83A874B88
       call      qword ptr [7138]; Precode of System.String.StrCns(UInt32, IntPtr)
       mov       [rbp+0FFF0],rax
       mov       rdx,[rbp+0FFF0]
       mov       rcx,[rbp+0FFF8]
       call      qword ptr [0D338]; Precode of System.ArgumentOutOfRangeException..ctor(System.String)
       mov       rcx,[rbp+0FFF8]
       call      000000000000B8A0
       int       3
M09_L00:
       mov       rax,[rbp+10]
       mov       rax,[rax+8]
       mov       ecx,[rbp+20]
       cmp       ecx,[rax+8]
       jae       short 0000000000004D04
       mov       edx,ecx
       imul      rdx,10
       lea       rax,[rax+rdx+10]
       mov       rcx,[rbp+18]
       vmovdqu   xmm0,xmmword ptr [rax]
       vmovdqu   xmmword ptr [rcx],xmm0
       mov       rax,[rbp+18]
       add       rsp,30
       pop       rbp
       ret
M09_L01:
       call      0000000000001788
       int       3
; Total bytes of code 170
```
```assembly
; System.ReadOnlyMemory`1[[System.Byte, System.Private.CoreLib]].get_Span()
       push      r14
       push      rdi
       push      rsi
       push      rbp
       push      rbx
       sub       rsp,30
       xor       eax,eax
       mov       [rsp+20],rax
       mov       rsi,rcx
       mov       rbx,rdx
       xor       edi,edi
       xor       ebp,ebp
       mov       r14,[rsi]
       test      r14,r14
       je        short 0000000000004915
       mov       rcx,[r14]
       test      dword ptr [rcx],80000000
       je        short 0000000000004938
       lea       rdi,[r14+10]
       mov       ebp,[r14+8]
M10_L00:
       mov       ecx,[rsi+8]
       and       ecx,7FFFFFFF
       mov       r14d,ecx
       mov       esi,[rsi+0C]
       mov       ecx,esi
       add       rcx,r14
       mov       eax,ebp
       cmp       rcx,rax
       ja        short 0000000000004979
       mov       rcx,7FF83A93836C
       call      0000000000008420
       add       rdi,r14
       mov       ebp,esi
M10_L01:
       mov       rcx,7FF83A938370
       call      0000000000008420
       mov       [rbx],rdi
       mov       [rbx+8],ebp
       mov       rax,rbx
       add       rsp,30
       pop       rbx
       pop       rbp
       pop       rsi
       pop       rdi
       pop       r14
       ret
M10_L02:
       mov       rcx,7FF83A938258
       call      0000000000008420
       mov       rcx,r14
       mov       rdx,7FF83A938260
       call      0000000000004AB0
       mov       rcx,r14
       lea       rdx,[rsp+20]
       mov       rax,[r14]
       mov       rax,[rax+40]
       call      qword ptr [rax+28]
       mov       ebp,[rsp+28]
       mov       rdi,[rsp+20]
       jmp       near ptr 00000000000048E6
M10_L03:
       mov       rcx,7FF83A938368
       call      0000000000008420
       call      qword ptr [7C18]; Precode of System.ThrowHelper.ThrowArgumentOutOfRangeException()
       int       3
; Total bytes of code 223
```
```assembly
; Tedd.Voxtree.OctreeChunk.get_Levels()
       mov       eax,[rcx+10]
       ret
; Total bytes of code 4
```
```assembly
; Tedd.Voxtree.OctreeCodec.GetStorageKindUnchecked(System.ReadOnlySpan`1<Byte>)
       push      rbp
       sub       rsp,20
       lea       rbp,[rsp+20]
       mov       [rbp+10],rcx
       mov       rax,[rbp+10]
       cmp       dword ptr [rax+8],1
       jbe       short 000000000000435C
       mov       rax,[rbp+10]
       mov       rax,[rax]
       movzx     eax,byte ptr [rax+1]
       and       eax,3
       add       rsp,20
       pop       rbp
       ret
M12_L00:
       call      0000000000001788
       int       3
; Total bytes of code 50
```
```assembly
; Tedd.Voxtree.OctreeSpan.CreateTrusted(System.ReadOnlySpan`1<Byte>, Int32, Tedd.Voxtree.StorageKind)
       push      rbp
       sub       rsp,50
       lea       rbp,[rsp+50]
       xor       eax,eax
       mov       [rbp+0FFD8],rax
       vxorps    xmm4,xmm4,xmm4
       vmovdqu   ymmword ptr [rbp+0FFE0],ymm4
       mov       [rbp+10],rcx
       mov       [rbp+18],rdx
       mov       [rbp+20],r8d
       mov       [rbp+28],r9d
       mov       rax,[rbp+18]
       vmovdqu   xmm0,xmmword ptr [rax]
       vmovdqu   xmmword ptr [rbp+0FFD8],xmm0
       lea       rdx,[rbp+0FFD8]
       movzx     r9d,byte ptr [rbp+28]
       lea       rcx,[rbp+0FFE8]
       mov       r8d,[rbp+20]
       call      qword ptr [0DB30]; Tedd.Voxtree.OctreeSpan..ctor(System.ReadOnlySpan`1<Byte>, Int32, Tedd.Voxtree.StorageKind)
       mov       rax,[rbp+10]
       vmovdqu   xmm0,xmmword ptr [rbp+0FFE8]
       vmovdqu   xmmword ptr [rax],xmm0
       mov       rcx,[rbp+0FFF8]
       mov       [rax+10],rcx
       mov       rax,[rbp+10]
       add       rsp,50
       pop       rbp
       ret
; Total bytes of code 108
```
```assembly
; Tedd.Voxtree.OctreeCodec.TryReadVarUInt(System.ReadOnlySpan`1<Byte>, Int32 ByRef, UInt32 ByRef)
       push      rbp
       sub       rsp,80
       lea       rbp,[rsp+80]
       vxorps    xmm4,xmm4,xmm4
       vmovdqu   xmmword ptr [rbp+0FFB8],xmm4
       mov       [rbp+10],rcx
       mov       [rbp+18],rdx
       mov       [rbp+20],r8
       mov       dword ptr [rbp+0FFB0],3E8
       mov       rax,[rbp+20]
       xor       ecx,ecx
       mov       [rax],ecx
       mov       rax,[rbp+18]
       mov       eax,[rax]
       mov       [rbp+0FFC4],eax
       xor       eax,eax
       mov       [rbp+0FFC0],eax
       jmp       near ptr 0000000000004B49
M14_L00:
       mov       rax,[rbp+18]
       mov       eax,[rax]
       mov       rcx,[rbp+10]
       cmp       eax,[rcx+8]
       jb        short 0000000000004A5A
       mov       rcx,7FF83A87CF08
       call      0000000000008420
       jmp       near ptr 0000000000004B7E
M14_L01:
       mov       rax,[rbp+18]
       mov       eax,[rax]
       mov       [rbp+0FFB8],eax
       mov       eax,[rbp+0FFB8]
       inc       eax
       mov       rcx,[rbp+18]
       mov       [rcx],eax
       mov       rax,[rbp+10]
       mov       eax,[rax+8]
       cmp       [rbp+0FFB8],eax
       jae       near ptr 0000000000004B96
       mov       rax,[rbp+10]
       mov       rax,[rax]
       mov       ecx,[rbp+0FFB8]
       movzx     eax,byte ptr [rax+rcx]
       mov       [rbp+0FFBC],eax
       cmp       dword ptr [rbp+0FFC0],1C
       jne       short 0000000000004AC4
       mov       eax,[rbp+0FFBC]
       and       eax,0F0
       test      eax,eax
       je        short 0000000000004AB5
       mov       rcx,7FF83A87CF0C
       call      0000000000008420
       jmp       near ptr 0000000000004B7E
M14_L02:
       mov       rcx,7FF83A87CF10
       call      0000000000008420
M14_L03:
       mov       eax,[rbp+0FFBC]
       and       eax,7F
       mov       ecx,[rbp+0FFC0]
       shlx      eax,eax,ecx
       mov       rcx,[rbp+20]
       or        [rcx],eax
       mov       eax,[rbp+0FFBC]
       and       eax,80
       test      eax,eax
       jne       short 0000000000004B31
       mov       rax,[rbp+18]
       mov       eax,[rax]
       sub       eax,[rbp+0FFC4]
       cmp       eax,1
       je        short 0000000000004B14
       mov       rcx,7FF83A87CF14
       call      0000000000008420
       mov       eax,[rbp+0FFBC]
       and       eax,7F
       test      eax,eax
       setne     al
       movzx     eax,al
       mov       [rbp+0FFAC],eax
       jmp       short 0000000000004B89
M14_L04:
       mov       rcx,7FF83A87CF18
       call      0000000000008420
       mov       eax,1
       add       rsp,80
       pop       rbp
       ret
M14_L05:
       mov       rcx,7FF83A87CF1C
       call      0000000000008420
       mov       eax,[rbp+0FFC0]
       add       eax,7
       mov       [rbp+0FFC0],eax
M14_L06:
       mov       eax,[rbp+0FFB0]
       dec       eax
       mov       [rbp+0FFB0],eax
       cmp       dword ptr [rbp+0FFB0],0
       jg        short 0000000000004B65
       lea       rcx,[rbp+0FFB0]
       mov       edx,65
       call      0000000000003990
M14_L07:
       cmp       dword ptr [rbp+0FFC0],1C
       jle       near ptr 0000000000004A37
       mov       rcx,7FF83A87CF20
       call      0000000000008420
M14_L08:
       xor       eax,eax
       add       rsp,80
       pop       rbp
       ret
M14_L09:
       movzx     eax,byte ptr [rbp+0FFAC]
       add       rsp,80
       pop       rbp
       ret
M14_L10:
       call      0000000000001788
       int       3
; Total bytes of code 428
```
```assembly
; System.ReadOnlySpan`1[[System.Byte, System.Private.CoreLib]].Slice(Int32, Int32)
       sub       rsp,28
       mov       eax,r8d
       mov       r8d,r9d
       add       r8,rax
       mov       r10d,[rcx+8]
       cmp       r8,r10
       ja        short 0000000000006388
       add       rax,[rcx]
       mov       [rdx],rax
       mov       [rdx+8],r9d
       mov       rax,rdx
       add       rsp,28
       ret
M15_L00:
       call      qword ptr [0F2B8]
       int       3
; Total bytes of code 47
```
```assembly
; Tedd.Voxtree.HotOctreeChunk.GetValues()
       push      rbp
       sub       rsp,40
       lea       rbp,[rsp+40]
       vxorps    xmm4,xmm4,xmm4
       vmovdqu   ymmword ptr [rbp+0FFE0],ymm4
       mov       [rbp+10],rcx
       mov       rax,[rbp+10]
       mov       rax,[rax+8]
       mov       [rbp+0FFF8],rax
       mov       rax,[rbp+0FFF8]
       mov       [rbp+0FFF0],rax
       cmp       qword ptr [rbp+0FFF8],0
       jne       short 0000000000002FD6
       mov       rcx,offset MT_System.InvalidOperationException
       call      0000000000005240
       mov       [rbp+0FFE8],rax
       mov       ecx,9F3
       mov       rdx,7FF83A874B88
       call      qword ptr [7138]; Precode of System.String.StrCns(UInt32, IntPtr)
       mov       [rbp+0FFE0],rax
       mov       rdx,[rbp+0FFE0]
       mov       rcx,[rbp+0FFE8]
       call      qword ptr [6760]; Precode of System.InvalidOperationException..ctor(System.String)
       mov       rcx,[rbp+0FFE8]
       call      000000000000B8A0
       int       3
M16_L00:
       mov       rax,[rbp+0FFF0]
       add       rsp,40
       pop       rbp
       ret
; Total bytes of code 128
```
```assembly
; Tedd.Voxtree.HotOctreeChunk.get_ChannelCount()
       push      rbp
       mov       rbp,rsp
       mov       [rbp+10],rcx
       mov       rax,[rbp+10]
       mov       eax,[rax+24]
       pop       rbp
       ret
; Total bytes of code 17
```
```assembly
; Tedd.Voxtree.OctreeCodec.GetVoxelCount(Int32)
       push      rbp
       mov       rbp,rsp
       mov       [rbp+10],ecx
       mov       eax,1
       mov       ecx,[rbp+10]
       lea       ecx,[rcx+rcx*2]
       shlx      eax,eax,ecx
       pop       rbp
       ret
; Total bytes of code 25
```
```assembly
; System.MemoryExtensions.AsSpan[[System.UInt32, System.Private.CoreLib]](UInt32[], Int32, Int32)
       sub       rsp,28
       test      rdx,rdx
       je        short 000000000000305F
       mov       r8d,r8d
       mov       eax,r9d
       add       rax,r8
       mov       r10d,[rdx+8]
       cmp       rax,r10
       ja        short 000000000000306B
       lea       rax,[rdx+r8*4+10]
M19_L00:
       mov       [rcx],rax
       mov       [rcx+8],r9d
       mov       rax,rcx
       add       rsp,28
       ret
M19_L01:
       or        r8d,r9d
       jne       short 000000000000306B
       xor       eax,eax
       xor       r9d,r9d
       jmp       short 0000000000003050
M19_L02:
       call      qword ptr [7C18]; Precode of System.ThrowHelper.ThrowArgumentOutOfRangeException()
       int       3
; Total bytes of code 66
```
```assembly
; Tedd.Voxtree.OctreeCodec.ValidateLevels(Int32)
       push      rbp
       sub       rsp,80
       lea       rbp,[rsp+80]
       xor       eax,eax
       mov       [rbp+0FFA8],rax
       vxorps    xmm4,xmm4,xmm4
       vmovdqu   ymmword ptr [rbp+0FFB0],ymm4
       vmovdqu   ymmword ptr [rbp+0FFD0],ymm4
       vmovdqa   xmmword ptr [rbp+0FFF0],xmm4
       mov       [rbp+10],ecx
       cmp       dword ptr [rbp+10],9
       jbe       near ptr 0000000000002C2F
       mov       rcx,offset MT_System.Int32
       call      0000000000005240
       mov       [rbp+0FFD0],rax
       mov       rax,[rbp+0FFD0]
       mov       ecx,[rbp+10]
       mov       [rax+8],ecx
       lea       rcx,[rbp+0FFD8]
       mov       edx,31
       mov       r8d,1
       call      qword ptr [67A8]; System.Runtime.CompilerServices.DefaultInterpolatedStringHandler..ctor(Int32, Int32)
       mov       ecx,1341
       mov       rdx,7FF83A874B88
       call      qword ptr [7138]; Precode of System.String.StrCns(UInt32, IntPtr)
       mov       [rbp+0FFC0],rax
       mov       rdx,[rbp+0FFC0]
       lea       rcx,[rbp+0FFD8]
       call      qword ptr [6C58]; System.Runtime.CompilerServices.DefaultInterpolatedStringHandler.AppendLiteral(System.String)
       lea       rcx,[rbp+0FFD8]
       mov       edx,9
       call      qword ptr [6AF0]; System.Runtime.CompilerServices.DefaultInterpolatedStringHandler.AppendFormatted[[System.Int32, System.Private.CoreLib]](Int32)
       mov       ecx,369
       mov       rdx,7FF83A874B88
       call      qword ptr [7138]; Precode of System.String.StrCns(UInt32, IntPtr)
       mov       [rbp+0FFB8],rax
       mov       rdx,[rbp+0FFB8]
       lea       rcx,[rbp+0FFD8]
       call      qword ptr [6C58]; System.Runtime.CompilerServices.DefaultInterpolatedStringHandler.AppendLiteral(System.String)
       mov       rcx,offset MT_System.ArgumentOutOfRangeException
       call      0000000000005240
       mov       [rbp+0FFC8],rax
       mov       ecx,1333
       mov       rdx,7FF83A874B88
       call      qword ptr [7138]; Precode of System.String.StrCns(UInt32, IntPtr)
       mov       [rbp+0FFB0],rax
       lea       rcx,[rbp+0FFD8]
       call      qword ptr [67D8]; System.Runtime.CompilerServices.DefaultInterpolatedStringHandler.ToStringAndClear()
       mov       [rbp+0FFA8],rax
       mov       rdx,[rbp+0FFB0]
       mov       r9,[rbp+0FFA8]
       mov       r8,[rbp+0FFD0]
       mov       rcx,[rbp+0FFC8]
       call      qword ptr [0C108]; Precode of System.ArgumentOutOfRangeException..ctor(System.String, System.Object, System.String)
       mov       rcx,[rbp+0FFC8]
       call      000000000000B8A0
       int       3
M20_L00:
       add       rsp,80
       pop       rbp
       ret
; Total bytes of code 296
```
```assembly
; Tedd.Voxtree.DenseVoxel.Validate(Tedd.Voxtree.DenseVoxelLayout)
       push      rbp
       sub       rsp,30
       lea       rbp,[rsp+30]
       xor       eax,eax
       mov       [rbp+0FFF8],rax
       mov       [rbp+0FFF0],rax
       mov       [rbp+10],ecx
       cmp       dword ptr [rbp+10],0
       je        short 0000000000002DA6
       cmp       dword ptr [rbp+10],1
       je        short 0000000000002D97
       mov       rcx,offset MT_System.ArgumentOutOfRangeException
       call      0000000000005240
       mov       [rbp+0FFF8],rax
       mov       ecx,4B5
       mov       rdx,7FF83A874B88
       call      qword ptr [7138]; Precode of System.String.StrCns(UInt32, IntPtr)
       mov       [rbp+0FFF0],rax
       mov       rdx,[rbp+0FFF0]
       mov       rcx,[rbp+0FFF8]
       call      qword ptr [0D338]; Precode of System.ArgumentOutOfRangeException..ctor(System.String)
       mov       rcx,[rbp+0FFF8]
       call      000000000000B8A0
       int       3
M21_L00:
       mov       rcx,7FF83A937EF0
       call      0000000000008420
M21_L01:
       mov       rcx,7FF83A937EF4
       call      0000000000008420
       nop
       add       rsp,30
       pop       rbp
       ret
; Total bytes of code 140
```
```assembly
; Tedd.Voxtree.DenseVoxel.Index(Int32, Int32, Int32, Int32, Tedd.Voxtree.DenseVoxelLayout)
       push      rbp
       sub       rsp,20
       lea       rbp,[rsp+20]
       mov       [rbp+10],ecx
       mov       [rbp+18],edx
       mov       [rbp+20],r8d
       mov       [rbp+28],r9d
       cmp       dword ptr [rbp+30],0
       je        short 00000000000037E4
       mov       rcx,7FF83A938060
       call      0000000000008420
       mov       ecx,[rbp+10]
       mov       edx,[rbp+18]
       mov       r8d,[rbp+20]
       call      qword ptr [0E928]; Tedd.MortonEncoding.Encode(UInt32, UInt32, UInt32)
       nop
       add       rsp,20
       pop       rbp
       ret
M22_L00:
       mov       rcx,7FF83A938064
       call      0000000000008420
       mov       eax,[rbp+10]
       imul      eax,[rbp+28]
       add       eax,[rbp+18]
       imul      eax,[rbp+28]
       add       eax,[rbp+20]
       add       rsp,20
       pop       rbp
       ret
; Total bytes of code 106
```
```assembly
; Tedd.Voxtree.OctreeChunk.get_ChannelCount()
       mov       rax,[rcx+8]
       mov       eax,[rax+8]
       ret
; Total bytes of code 8
```
```assembly
; Tedd.Voxtree.OctreeSpan..ctor(System.ReadOnlySpan`1<Byte>, Int32, Tedd.Voxtree.StorageKind)
       push      rbp
       mov       rbp,rsp
       mov       [rbp+10],rcx
       mov       [rbp+18],rdx
       mov       [rbp+20],r8d
       mov       [rbp+28],r9d
       mov       rax,[rbp+18]
       mov       rcx,[rbp+10]
       vmovdqu   xmm0,xmmword ptr [rax]
       vmovdqu   xmmword ptr [rcx],xmm0
       mov       rax,[rbp+10]
       mov       ecx,[rbp+20]
       mov       [rax+10],ecx
       mov       rax,[rbp+10]
       mov       ecx,[rbp+28]
       mov       [rax+14],cl
       pop       rbp
       ret
; Total bytes of code 58
```
```assembly
; System.Runtime.CompilerServices.DefaultInterpolatedStringHandler..ctor(Int32, Int32)
       push      rdi
       push      rsi
       push      rbx
       sub       rsp,20
       mov       rbx,rcx
       mov       esi,edx
       mov       edi,r8d
       xor       eax,eax
       mov       [rbx],rax
       call      qword ptr [0A098]
       mov       rcx,[rax]
       imul      edx,edi,0B
       add       edx,esi
       mov       eax,100
       cmp       edx,100
       cmovle    edx,eax
       cmp       [rcx],ecx
       call      qword ptr [98B8]; Precode of System.Buffers.SharedArrayPool`1[[System.Char, System.Private.CoreLib]].Rent(Int32)
       mov       [rbx+8],rax
       test      rax,rax
       je        short 000000000000C4E0
       lea       rcx,[rax+10]
       mov       eax,[rax+8]
M25_L00:
       mov       [rbx+18],rcx
       mov       [rbx+20],eax
       xor       eax,eax
       mov       [rbx+10],eax
       mov       byte ptr [rbx+14],0
       add       rsp,20
       pop       rbx
       pop       rsi
       pop       rdi
       ret
M25_L01:
       xor       ecx,ecx
       xor       eax,eax
       jmp       short 000000000000C4C8
; Total bytes of code 102
```
```assembly
; System.Runtime.CompilerServices.DefaultInterpolatedStringHandler.AppendLiteral(System.String)
       push      rdi
       push      rsi
       push      rbx
       sub       rsp,20
       mov       rbx,rcx
       mov       rsi,rdx
       lea       r8,[rbx+18]
       mov       edx,[rbx+10]
       mov       ecx,[r8+8]
       cmp       edx,ecx
       ja        short 0000000000001DFB
       mov       r8,[r8]
       mov       eax,edx
       lea       rax,[r8+rax*2]
       sub       ecx,edx
       mov       edi,[rsi+8]
       cmp       edi,ecx
       ja        short 0000000000001E02
       mov       r8d,edi
       add       r8,r8
       lea       rdx,[rsi+0C]
       mov       rcx,rax
       call      qword ptr [5818]; System.SpanHelpers.Memmove(Byte ByRef, Byte ByRef, UIntPtr)
       mov       rcx,7FF83A7F7088
       call      0000000000008420
       add       [rbx+10],edi
       add       rsp,20
       pop       rbx
       pop       rsi
       pop       rdi
       ret
M26_L00:
       call      qword ptr [7C18]; Precode of System.ThrowHelper.ThrowArgumentOutOfRangeException()
       int       3
M26_L01:
       mov       rcx,7FF83A7F708C
       call      0000000000008420
       mov       rcx,rbx
       mov       rdx,rsi
       add       rsp,20
       pop       rbx
       pop       rsi
       pop       rdi
       jmp       qword ptr [67C0]; Precode of System.Runtime.CompilerServices.DefaultInterpolatedStringHandler.GrowThenCopyString(System.String)
; Total bytes of code 132
```
```assembly
; System.Runtime.CompilerServices.DefaultInterpolatedStringHandler.AppendFormatted[[System.Int32, System.Private.CoreLib]](Int32)
       push      rdi
       push      rsi
       push      rbp
       push      rbx
       sub       rsp,58
       xorps     xmm4,xmm4
       movaps    [rsp+30],xmm4
       movaps    [rsp+40],xmm4
       mov       rbx,rcx
       mov       esi,edx
       cmp       byte ptr [rbx+14],0
       jne       short 000000000000F15B
M27_L00:
       lea       rdx,[rbx+18]
       mov       r8d,[rbx+10]
       mov       edi,[rdx+8]
       cmp       r8d,edi
       ja        near ptr 000000000000F1D8
       mov       rdx,[rdx]
       mov       ecx,r8d
       lea       rbp,[rdx+rcx*2]
       sub       edi,r8d
       mov       rcx,[rbx]
       test      esi,esi
       jl        short 000000000000F173
       mov       [rsp+40],rbp
       mov       [rsp+48],edi
       lea       rdx,[rsp+40]
       lea       r8,[rsp+50]
       mov       ecx,esi
       call      qword ptr [0CF8]; Precode of System.Number.TryUInt32ToDecStr[[System.Char, System.Private.CoreLib]](UInt32, System.Span`1<Char>, Int32 ByRef)
M27_L01:
       test      eax,eax
       jne       short 000000000000F152
       mov       rcx,rbx
       call      qword ptr [4FF8]
       jmp       short 000000000000F100
M27_L02:
       mov       eax,[rsp+50]
       add       [rbx+10],eax
       jmp       short 000000000000F169
M27_L03:
       mov       rcx,rbx
       mov       edx,esi
       xor       r8d,r8d
       call      qword ptr [1B50]
M27_L04:
       nop
       add       rsp,58
       pop       rbx
       pop       rbp
       pop       rsi
       pop       rdi
       ret
M27_L05:
       test      rcx,rcx
       je        short 000000000000F180
       call      qword ptr [1260]; Precode of System.Globalization.NumberFormatInfo.<GetInstance>g__GetProviderNonNull|58_0(System.IFormatProvider)
       jmp       short 000000000000F186
M27_L06:
       call      qword ptr [1248]; Precode of System.Globalization.NumberFormatInfo.get_CurrentInfo()
M27_L07:
       mov       r8,[rax+28]
       test      r8,r8
       jne       short 000000000000F197
       xor       r9d,r9d
       xor       r8d,r8d
       jmp       short 000000000000F19F
M27_L08:
       lea       r9,[r8+0C]
       mov       r8d,[r8+8]
M27_L09:
       mov       [rsp+30],r9
       mov       [rsp+38],r8d
       mov       [rsp+40],rbp
       mov       [rsp+48],edi
       lea       r8,[rsp+50]
       mov       [rsp+20],r8
       lea       r8,[rsp+30]
       lea       r9,[rsp+40]
       mov       ecx,esi
       mov       edx,0FFFFFFFF
       call      qword ptr [0CE0]
       jmp       near ptr 000000000000F143
M27_L10:
       call      qword ptr [0F2B8]
       int       3
; Total bytes of code 255
```
```assembly
; System.Runtime.CompilerServices.DefaultInterpolatedStringHandler.ToStringAndClear()
       push      rdi
       push      rsi
       push      rbp
       push      rbx
       sub       rsp,38
       xor       eax,eax
       mov       [rsp+28],rax
       mov       rbx,rcx
       lea       rsi,[rbx+18]
       mov       rcx,rsi
       mov       eax,[rbx+10]
       cmp       eax,[rcx+8]
       ja        short 000000000000C6F7
       mov       rcx,[rcx]
       mov       [rsp+28],rcx
       mov       [rsp+30],eax
       lea       rcx,[rsp+28]
       call      qword ptr [0BB28]; Precode of System.String.Ctor(System.ReadOnlySpan`1<Char>)
       mov       rdi,rax
       mov       rbp,[rbx+8]
       xor       eax,eax
       mov       [rbx+8],rax
       mov       [rsi],rax
       mov       [rsi+8],rax
       mov       [rbx+10],eax
       test      rbp,rbp
       je        short 000000000000C6EB
       call      qword ptr [0A098]
       mov       rcx,[rax]
       mov       rdx,rbp
       xor       r8d,r8d
       cmp       [rcx],ecx
       call      qword ptr [98C0]; Precode of System.Buffers.SharedArrayPool`1[[System.Char, System.Private.CoreLib]].Return(Char[], Boolean)
M28_L00:
       mov       rax,rdi
       add       rsp,38
       pop       rbx
       pop       rbp
       pop       rsi
       pop       rdi
       ret
M28_L01:
       call      qword ptr [0F2B8]
       int       3
; Total bytes of code 126
```
```assembly
; Tedd.MortonEncoding.Encode(UInt32, UInt32, UInt32)
       push      rbp
       mov       rbp,rsp
       mov       [rbp+10],ecx
       mov       [rbp+18],edx
       mov       [rbp+20],r8d
       mov       eax,[rbp+20]
       mov       ecx,24924924
       pdep      eax,eax,ecx
       mov       ecx,[rbp+18]
       mov       edx,12492492
       pdep      ecx,ecx,edx
       or        eax,ecx
       mov       ecx,[rbp+10]
       mov       edx,9249249
       pdep      ecx,ecx,edx
       or        eax,ecx
       pop       rbp
       ret
; Total bytes of code 59
```
**Method was not JITted yet.**
Tedd.Voxtree.OctreeThrowHelper.ThrowInvalidView()
Tedd.Voxtree.OctreeThrowHelper.ThrowCoordinate(System.String, Int32)
Tedd.Voxtree.OctreeThrowHelper.ThrowMalformed()
System.String.StrCns(UInt32, IntPtr)
System.ObjectDisposedException..ctor(System.String)
System.ArgumentOutOfRangeException..ctor(System.String)
System.ThrowHelper.ThrowArgumentOutOfRangeException()
System.Buffers.Binary.BinaryPrimitives.ReadUInt32LittleEndian(System.ReadOnlySpan`1<Byte>)
System.InvalidOperationException..ctor(System.String)
System.ArgumentOutOfRangeException..ctor(System.String, System.Object, System.String)

## .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v3 (Job: Job-GJBZFV(IterationCount=7, IterationTime=150ms, LaunchCount=1, WarmupCount=3))

```assembly
; Tedd.Voxtree.Benchmark.Tests.DeferredChunkReads.DeferredHits()
       push      r15
       push      r14
       push      r13
       push      r12
       push      rdi
       push      rsi
       push      rbp
       push      rbx
       sub       rsp,78
       vxorps    xmm4,xmm4,xmm4
       vmovdqu   ymmword ptr [rsp+40],ymm4
       vmovdqa   xmmword ptr [rsp+60],xmm4
       mov       rbx,rcx
       mov       rsi,[rbx+20]
       xor       edi,edi
       xor       ebp,ebp
       jmp       short 000000000000B846
M00_L00:
       xor       r9d,r9d
M00_L01:
       test      r9d,r9d
       jl        near ptr 000000000000BA65
       mov       r10,[rsp+38]
       mov       rcx,[r10+20]
       mov       eax,[rsp+74]
       mov       edx,eax
       imul      edx,[r10+2C]
       mov       r8d,r9d
       sar       r8d,6
       add       edx,r8d
       cmp       edx,[rcx+8]
       jae       near ptr 000000000000BC1C
       mov       rcx,[rcx+rdx*8+10]
       bt        rcx,r9
       jae       near ptr 000000000000BA69
       mov       rcx,[r10+8]
       cmp       eax,[rcx+8]
       jae       near ptr 000000000000BC1C
       mov       edx,eax
       mov       rcx,[rcx+rdx*8+10]
       cmp       r9d,[rcx+8]
       jae       near ptr 000000000000BC1C
       mov       edx,r9d
       mov       r10d,[rcx+rdx*4+10]
M00_L02:
       add       edi,r10d
       inc       ebp
       cmp       ebp,100
       jge       near ptr 000000000000B92D
M00_L03:
       cmp       ebp,[rsi+8]
       jae       near ptr 000000000000BC1C
       mov       r14d,[rsi+rbp*4+10]
       mov       r15,[rbx+18]
       mov       r13d,r14d
       sar       r13d,0A
       mov       r12d,r14d
       sar       r12d,5
       and       r12d,1F
       mov       eax,ebp
       and       eax,1
       mov       [rsp+74],eax
       and       r14d,1F
       cmp       byte ptr [r15+24],0
       jne       near ptr 000000000000BB61
       mov       rdx,[r15+8]
       mov       rcx,[rdx+8]
       cmp       [rcx+8],eax
       jbe       near ptr 000000000000BB9D
       mov       edx,[rdx+10]
       mov       ecx,edx
       and       ecx,1F
       mov       r8d,1
       shlx      r8d,r8d,ecx
       cmp       r13d,r8d
       jae       near ptr 000000000000BBD9
       cmp       r12d,r8d
       jae       near ptr 000000000000BBD9
       cmp       r14d,r8d
       jae       near ptr 000000000000BBD9
       add       edx,edx
       shlx      edx,r13d,edx
       shlx      ecx,r12d,ecx
       or        edx,ecx
       or        edx,r14d
       cmp       qword ptr [r15+10],0
       jne       short 000000000000B943
       mov       r10,[r15+18]
       test      r10,r10
       je        near ptr 000000000000B968
       mov       [rsp+38],r10
       mov       ecx,[r10+30]
       test      ecx,ecx
       je        short 000000000000B922
       mov       r8,[r10+10]
       test      r8,r8
       je        short 000000000000B971
       cmp       ecx,1
       jne       near ptr 000000000000B9A5
       cmp       dword ptr [r8+8],0
       jbe       near ptr 000000000000BC1C
       movzx     ecx,word ptr [r8+10]
       cmp       ecx,edx
       je        near ptr 000000000000B7CD
       mov       r10,[rsp+38]
M00_L04:
       mov       r9d,0FFFFFFFF
       jmp       near ptr 000000000000B7D0
M00_L05:
       mov       eax,edi
       vzeroupper
       add       rsp,78
       pop       rbx
       pop       rbp
       pop       rsi
       pop       rdi
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       ret
M00_L06:
       mov       eax,[rsp+74]
       mov       [rsp+20],r14d
       mov       rcx,[r15+10]
       mov       edx,eax
       mov       r8d,r13d
       mov       r9d,r12d
       cmp       [rcx],ecx
       call      qword ptr [0E700]; Tedd.Voxtree.HotOctreeChunk.get_Item(Int32, Int32, Int32, Int32)
       mov       r10d,eax
       jmp       near ptr 000000000000B835
M00_L07:
       mov       eax,[rsp+74]
       jmp       near ptr 000000000000BA69
M00_L08:
       mov       r10,[rsp+38]
       mov       r8,[r10+18]
       mov       r9d,ecx
       test      r8,r8
       je        near ptr 000000000000BC15
       cmp       [r8+8],r9d
       jb        near ptr 000000000000BC15
       lea       rcx,[r8+10]
       mov       r8d,r9d
       call      qword ptr [52D8]; Precode of System.SpanHelpers.NonPackedIndexOfValueType[[System.Int32, System.Private.CoreLib],[System.SpanHelpers+DontNegate`1[[System.Int32, System.Private.CoreLib]], System.Private.CoreLib]](Int32 ByRef, Int32, Int32)
       mov       r9d,eax
       jmp       near ptr 000000000000B7D0
M00_L09:
       cmp       ecx,20
       jg        short 000000000000BA1E
       add       ecx,0F
       and       ecx,0FFFFFFF0
       cmp       [r8+8],ecx
       jb        near ptr 000000000000BC15
       add       r8,10
       mov       r9d,ecx
       add       r9,r9
       shr       r9,5
       cmp       r9,7FFFFFFF
       ja        near ptr 000000000000BC22
       vmovd     xmm0,edx
       vpbroadcastw ymm0,xmm0
       xor       edx,edx
       jmp       short 000000000000B9F8
M00_L10:
       mov       ecx,edx
       shl       rcx,5
       vpcmpeqw  ymm1,ymm0,[r8+rcx]
       vpmovmskb ecx,ymm1
       test      ecx,ecx
       jne       short 000000000000BA07
       inc       edx
M00_L11:
       cmp       edx,r9d
       jl        short 000000000000B9E2
       mov       r10,[rsp+38]
       jmp       near ptr 000000000000B922
M00_L12:
       mov       r9d,edx
       shl       r9d,4
       xor       edx,edx
       tzcnt     edx,ecx
       sar       edx,1
       add       r9d,edx
       jmp       near ptr 000000000000B7D0
M00_L13:
       mov       r9d,ecx
       cmp       [r8+8],r9d
       jb        near ptr 000000000000BC15
       lea       rcx,[r8+10]
       movzx     edx,dx
       movsx     rdx,dx
       movzx     r8d,dx
       dec       r8d
       cmp       r8d,0FE
       jae       short 000000000000BA54
       mov       r8d,r9d
       call      qword ptr [0C378]; System.PackedSpanHelpers.IndexOf[[System.SpanHelpers+DontNegate`1[[System.Int16, System.Private.CoreLib]], System.Private.CoreLib],[System.PackedSpanHelpers+NopTransform, System.Private.CoreLib]](Int16 ByRef, Int16, Int32)
       mov       r9d,eax
       jmp       short 000000000000BA60
M00_L14:
       mov       r8d,r9d
       call      qword ptr [61D8]
       mov       r9d,eax
M00_L15:
       jmp       near ptr 000000000000B7D0
M00_L16:
       mov       eax,[rsp+74]
M00_L17:
       mov       rcx,[r15+8]
       lea       rdx,[rsp+58]
       mov       r8d,eax
       cmp       [rcx],ecx
       call      qword ptr [0DAB8]; Tedd.Voxtree.OctreeChunk.GetChannel(Int32)
       xor       ecx,ecx
       mov       [rsp+50],ecx
       mov       edx,[rsp+68]
       cmp       dword ptr [rsp+60],0
       jne       short 000000000000BA9C
       call      qword ptr [0E790]; Precode of Tedd.Voxtree.OctreeThrowHelper.ThrowInvalidView()
       mov       r10d,eax
       jmp       near ptr 000000000000BB5C
M00_L18:
       mov       ecx,1
       shlx      ecx,ecx,edx
       cmp       r13d,ecx
       jb        short 000000000000BAC6
       mov       edx,r13d
       mov       rcx,16400552B18
       call      qword ptr [0E7A8]; Precode of Tedd.Voxtree.OctreeThrowHelper.ThrowCoordinate(System.String, Int32)
       mov       r10d,eax
       jmp       near ptr 000000000000BB5C
M00_L19:
       mov       ecx,1
       shlx      ecx,ecx,edx
       cmp       r12d,ecx
       jb        short 000000000000BAED
       mov       edx,r12d
       mov       rcx,164005622F8
       call      qword ptr [0E7A8]; Precode of Tedd.Voxtree.OctreeThrowHelper.ThrowCoordinate(System.String, Int32)
       mov       r10d,eax
       jmp       short 000000000000BB5C
M00_L20:
       mov       ecx,1
       shlx      ecx,ecx,edx
       cmp       r14d,ecx
       jb        short 000000000000BB14
       mov       edx,r14d
       mov       rcx,16400562310
       call      qword ptr [0E7A8]; Precode of Tedd.Voxtree.OctreeThrowHelper.ThrowCoordinate(System.String, Int32)
       mov       r10d,eax
       jmp       short 000000000000BB5C
M00_L21:
       vmovdqu   xmm0,xmmword ptr [rsp+58]
       vmovdqu   xmmword ptr [rsp+40],xmm0
       mov       [rsp+20],r12d
       mov       [rsp+28],r14d
       lea       rcx,[rsp+50]
       mov       [rsp+30],rcx
       lea       rcx,[rsp+40]
       movzx     r8d,byte ptr [rsp+6C]
       mov       r9d,r13d
       call      qword ptr [0E7C0]; Tedd.Voxtree.OctreeCodec.TryGetUnchecked(System.ReadOnlySpan`1<Byte>, Int32, Tedd.Voxtree.StorageKind, Int32, Int32, Int32, UInt32 ByRef)
       test      eax,eax
       jne       short 000000000000BB57
       call      qword ptr [0E7D8]; Precode of Tedd.Voxtree.OctreeThrowHelper.ThrowMalformed()
       mov       r10d,eax
       jmp       short 000000000000BB5C
M00_L22:
       mov       r10d,[rsp+50]
M00_L23:
       jmp       near ptr 000000000000B835
M00_L24:
       mov       rcx,offset MT_System.ObjectDisposedException
       call      0000000000005240
       mov       rbx,rax
       mov       ecx,3F5
       mov       rdx,7FF83A882920
       call      qword ptr [7258]; Precode of System.String.StrCns(UInt32, IntPtr)
       mov       rdx,rax
       mov       rcx,rbx
       call      qword ptr [7A80]; Precode of System.ObjectDisposedException..ctor(System.String)
       mov       rcx,rbx
       call      000000000000B8A0
       int       3
M00_L25:
       mov       rcx,offset MT_System.ArgumentOutOfRangeException
       call      0000000000005240
       mov       rbx,rax
       mov       ecx,3E1
       mov       rdx,7FF83A882920
       call      qword ptr [7258]; Precode of System.String.StrCns(UInt32, IntPtr)
       mov       rdx,rax
       mov       rcx,rbx
       call      qword ptr [0D1A0]; Precode of System.ArgumentOutOfRangeException..ctor(System.String)
       mov       rcx,rbx
       call      000000000000B8A0
       int       3
M00_L26:
       mov       rcx,offset MT_System.ArgumentOutOfRangeException
       call      0000000000005240
       mov       rbx,rax
       mov       ecx,3F1
       mov       rdx,7FF83A882920
       call      qword ptr [7258]; Precode of System.String.StrCns(UInt32, IntPtr)
       mov       rdx,rax
       mov       rcx,rbx
       call      qword ptr [0D1A0]; Precode of System.ArgumentOutOfRangeException..ctor(System.String)
       mov       rcx,rbx
       call      000000000000B8A0
       int       3
M00_L27:
       call      qword ptr [7C18]; Precode of System.ThrowHelper.ThrowArgumentOutOfRangeException()
       int       3
M00_L28:
       call      0000000000001788
       int       3
M00_L29:
       call      0000000000001770
       int       3
; Total bytes of code 1160
```
```assembly
; Tedd.Voxtree.HotOctreeChunk.get_Item(Int32, Int32, Int32, Int32)
       push      rbp
       sub       rsp,40
       lea       rbp,[rsp+40]
       xor       eax,eax
       mov       [rbp+0FFF0],rax
       mov       [rbp+0FFF8],rax
       mov       [rbp+10],rcx
       mov       [rbp+18],edx
       mov       [rbp+20],r8d
       mov       [rbp+28],r9d
       lea       rdx,[rbp+0FFF0]
       mov       rcx,[rbp+10]
       mov       r8d,[rbp+18]
       call      qword ptr [0E628]; Tedd.Voxtree.HotOctreeChunk.GetChannelSpan(Int32)
       mov       rcx,[rbp+10]
       call      qword ptr [0E640]; Tedd.Voxtree.HotOctreeChunk.get_Levels()
       mov       [rbp+0FFE8],eax
       mov       dword ptr [rsp+20],1
       mov       r9d,[rbp+0FFE8]
       mov       edx,[rbp+28]
       mov       r8d,[rbp+30]
       mov       ecx,[rbp+20]
       call      qword ptr [0E658]; Tedd.Voxtree.DenseVoxel.GetIndex(Int32, Int32, Int32, Int32, Tedd.Voxtree.DenseVoxelLayout)
       mov       [rbp+0FFEC],eax
       mov       eax,[rbp+0FFF8]
       cmp       [rbp+0FFEC],eax
       jae       short 0000000000008599
       mov       eax,[rbp+0FFEC]
       mov       rcx,[rbp+0FFF0]
       mov       eax,[rcx+rax*4]
       add       rsp,40
       pop       rbp
       ret
M01_L00:
       call      0000000000001788
       int       3
; Total bytes of code 127
```
```assembly
; System.SpanHelpers.NonPackedIndexOfValueType[[System.Int32, System.Private.CoreLib],[System.SpanHelpers+DontNegate`1[[System.Int32, System.Private.CoreLib]], System.Private.CoreLib]](Int32 ByRef, Int32, Int32)
       cmp       r8d,4
       jl        near ptr 0000000000000E5A
       movd      xmm0,edx
       pshufd    xmm0,xmm0,0
       mov       rdx,rcx
       lea       eax,[r8+0FFFC]
       cdqe
       shl       rax,2
       lea       r10,[rdx+rax]
       movups    xmm1,[rcx]
       pcmpeqd   xmm1,xmm0
       ptest     xmm1,xmm1
       je        short 0000000000000E13
M02_L00:
       movmskps  eax,xmm1
       bsf       r8d,eax
       mov       r10d,20
       test      eax,eax
       cmove     r8d,r10d
       mov       rax,rdx
       sub       rax,rcx
       shr       rax,2
       add       eax,r8d
M02_L01:
       ret
M02_L02:
       add       rdx,10
       cmp       rdx,r10
       jbe       near ptr 0000000000000F43
       mov       ecx,r8d
       test      cl,3
       je        near ptr 0000000000000F5A
       movups    xmm1,[r10]
       pcmpeqd   xmm1,xmm0
       ptest     xmm1,xmm1
       je        near ptr 0000000000000F5A
       movmskps  edx,xmm1
       bsf       r8d,edx
       mov       ecx,20
       test      edx,edx
       cmove     r8d,ecx
       shr       rax,2
       add       eax,r8d
       jmp       short 0000000000000E12
M02_L03:
       xor       r10d,r10d
       cmp       r8d,8
       jge       short 0000000000000E8D
M02_L04:
       cmp       r8d,4
       jge       short 0000000000000EDC
M02_L05:
       test      r8d,r8d
       jle       near ptr 0000000000000F5A
M02_L06:
       dec       r8d
       cmp       [rcx+r10*4],edx
       je        short 0000000000000E88
       inc       r10
       test      r8d,r8d
       jg        short 0000000000000E72
       jmp       near ptr 0000000000000F5A
M02_L07:
       mov       eax,r10d
       jmp       short 0000000000000E12
M02_L08:
       add       r8d,0FFFFFFF8
       cmp       [rcx+r10*4],edx
       je        short 0000000000000E88
       cmp       [rcx+r10*4+4],edx
       je        near ptr 0000000000000F3A
       cmp       [rcx+r10*4+8],edx
       je        near ptr 0000000000000F31
       cmp       [rcx+r10*4+0C],edx
       je        short 0000000000000F28
       cmp       [rcx+r10*4+10],edx
       je        short 0000000000000F1F
       cmp       [rcx+r10*4+14],edx
       je        short 0000000000000F16
       cmp       [rcx+r10*4+18],edx
       je        short 0000000000000F0D
       cmp       [rcx+r10*4+1C],edx
       je        short 0000000000000F04
       add       r10,8
       cmp       r8d,8
       jge       short 0000000000000E8D
       jmp       short 0000000000000E63
M02_L09:
       add       r8d,0FFFFFFFC
       cmp       [rcx+r10*4],edx
       je        short 0000000000000E88
       cmp       [rcx+r10*4+4],edx
       je        short 0000000000000F3A
       cmp       [rcx+r10*4+8],edx
       je        short 0000000000000F31
       cmp       [rcx+r10*4+0C],edx
       je        short 0000000000000F28
       add       r10,4
       jmp       near ptr 0000000000000E69
M02_L10:
       lea       eax,[r10+7]
       jmp       near ptr 0000000000000E12
M02_L11:
       lea       eax,[r10+6]
       jmp       near ptr 0000000000000E12
M02_L12:
       lea       eax,[r10+5]
       jmp       near ptr 0000000000000E12
M02_L13:
       lea       eax,[r10+4]
       jmp       near ptr 0000000000000E12
M02_L14:
       lea       eax,[r10+3]
       jmp       near ptr 0000000000000E12
M02_L15:
       lea       eax,[r10+2]
       jmp       near ptr 0000000000000E12
M02_L16:
       lea       eax,[r10+1]
       jmp       near ptr 0000000000000E12
M02_L17:
       movups    xmm1,[rdx]
       pcmpeqd   xmm1,xmm0
       ptest     xmm1,xmm1
       jne       near ptr 0000000000000DF2
       jmp       near ptr 0000000000000E13
M02_L18:
       mov       eax,0FFFFFFFF
       ret
; Total bytes of code 416
```
```assembly
; System.PackedSpanHelpers.IndexOf[[System.SpanHelpers+DontNegate`1[[System.Int16, System.Private.CoreLib]], System.Private.CoreLib],[System.PackedSpanHelpers+NopTransform, System.Private.CoreLib]](Int16 ByRef, Int16, Int32)
       push      r14
       push      rdi
       push      rsi
       push      rbp
       push      rbx
       sub       rsp,50
       vmovaps   [rsp+40],xmm6
       vmovaps   [rsp+30],xmm7
       vmovaps   [rsp+20],xmm8
       mov       rsi,rcx
       mov       edi,edx
       mov       ebx,r8d
       cmp       ebx,8
       jl        near ptr 000000000000D4FC
       mov       rbp,rsi
       cmp       ebx,10
       jle       near ptr 000000000000D479
       vmovd     xmm6,edi
       vpbroadcastb ymm6,xmm6
       cmp       ebx,20
       jle       near ptr 000000000000D3B4
       lea       ecx,[rbx+0FFE0]
       movsxd    rcx,ecx
       lea       rdi,[rbp+rcx*2]
       vmovups   ymm0,[rsi]
       vpackuswb ymm0,ymm0,[rsi+20]
       vpcmpeqb  ymm7,ymm0,ymm6
       vptest    ymm7,ymm7
       jne       short 000000000000D363
M03_L00:
       add       rbp,40
       cmp       rbp,rdi
       jae       short 000000000000D399
       mov       rcx,7FF83A4DA048
       vextractf128 xmm8,ymm6,1
       call      0000000000008420
       vmovups   ymm0,[rbp]
       vpackuswb ymm0,ymm0,[rbp+20]
       vinsertf128 ymm6,ymm6,xmm8,1
       vpcmpeqb  ymm7,ymm0,ymm6
       vptest    ymm7,ymm7
       je        short 000000000000D32A
M03_L01:
       mov       rcx,7FF83A4DA03C
       vextractf128 xmm8,ymm7,1
       call      0000000000008420
       mov       rax,rbp
       sub       rax,rsi
       shr       rax,1
       vinsertf128 ymm7,ymm7,xmm8,1
       vpermq    ymm0,ymm7,0D8
       vpmovmskb ecx,ymm0
       tzcnt     ecx,ecx
       add       eax,ecx
       jmp       short 000000000000D3FC
M03_L02:
       mov       rcx,7FF83A4DA044
       vextractf128 xmm8,ymm6,1
       call      0000000000008420
       vinsertf128 ymm6,ymm6,xmm8,1
M03_L03:
       add       ebx,0FFFFFFF0
       movsxd    rcx,ebx
       lea       rbx,[rsi+rcx*2]
       cmp       rbp,rbx
       ja        short 000000000000D41C
       mov       rdi,rbp
M03_L04:
       vmovups   ymm0,[rdi]
       vpackuswb ymm0,ymm0,[rbx]
       vpcmpeqb  ymm6,ymm0,ymm6
       vptest    ymm6,ymm6
       jne       short 000000000000D43C
       mov       rcx,7FF83A4DA054
       call      0000000000008420
M03_L05:
       mov       rcx,7FF83A4DA064
       call      0000000000008420
       mov       eax,0FFFFFFFF
M03_L06:
       vzeroupper
       vmovaps   xmm6,[rsp+40]
       vmovaps   xmm7,[rsp+30]
       vmovaps   xmm8,[rsp+20]
       add       rsp,50
       pop       rbx
       pop       rbp
       pop       rsi
       pop       rdi
       pop       r14
       ret
M03_L07:
       mov       rcx,7FF83A4DA04C
       vextractf128 xmm8,ymm6,1
       call      0000000000008420
       mov       rdi,rbx
       vinsertf128 ymm6,ymm6,xmm8,1
       jmp       short 000000000000D3C6
M03_L08:
       mov       rcx,7FF83A4DA050
       vextractf128 xmm7,ymm6,1
       call      0000000000008420
       vinsertf128 ymm6,ymm6,xmm7,1
       vpermq    ymm0,ymm6,0D8
       vpmovmskb ecx,ymm0
       tzcnt     ecx,ecx
       cmp       ecx,10
       jge       near ptr 000000000000D650
M03_L09:
       sub       rdi,rsi
       shr       rdi,1
       lea       eax,[rdi+rcx]
       jmp       short 000000000000D3FC
M03_L10:
       mov       rcx,7FF83A4DA040
       call      0000000000008420
       vmovd     xmm6,edi
       vpbroadcastb xmm6,xmm6
       lea       ecx,[rbx+0FFF8]
       movsxd    rcx,ecx
       lea       rbx,[rsi+rcx*2]
       cmp       rsi,rbx
       ja        near ptr 000000000000D65B
       mov       rdi,rsi
M03_L11:
       vmovups   xmm0,[rdi]
       vpackuswb xmm0,xmm0,[rbx]
       vpcmpeqb  xmm6,xmm0,xmm6
       vptest    xmm6,xmm6
       jne       short 000000000000D4CE
       mov       rcx,7FF83A4DA060
       call      0000000000008420
       jmp       near ptr 000000000000D3E8
M03_L12:
       mov       rcx,7FF83A4DA05C
       call      0000000000008420
       vpmovmskb ecx,xmm6
       tzcnt     ecx,ecx
       cmp       ecx,8
       jge       near ptr 000000000000D672
M03_L13:
       sub       rdi,rsi
       shr       rdi,1
       lea       eax,[rdi+rcx]
       jmp       near ptr 000000000000D3FC
M03_L14:
       xor       ebp,ebp
       cmp       ebx,4
       jl        short 000000000000D555
       add       ebx,0FFFFFFFC
       movsx     rcx,word ptr [rsi]
       movsx     r14,di
       cmp       ecx,r14d
       je        near ptr 000000000000D59E
       movsx     rcx,word ptr [rsi+2]
       cmp       ecx,r14d
       je        near ptr 000000000000D5CF
       movsx     rcx,word ptr [rsi+4]
       cmp       ecx,r14d
       je        near ptr 000000000000D603
       movsx     rcx,word ptr [rsi+6]
       cmp       ecx,r14d
       je        near ptr 000000000000D637
       mov       rcx,7FF83A4DA030
       call      0000000000008420
       mov       ebp,4
M03_L15:
       test      ebx,ebx
       jle       near ptr 000000000000D3E8
       movsx     r14,di
M03_L16:
       dec       ebx
       movsx     rcx,word ptr [rsi+rbp*2]
       cmp       ecx,r14d
       je        short 000000000000D588
       mov       rcx,7FF83A4DA038
       call      0000000000008420
       inc       rbp
       test      ebx,ebx
       jg        short 000000000000D561
       jmp       near ptr 000000000000D3E8
M03_L17:
       mov       rcx,7FF83A4DA034
       call      0000000000008420
       mov       eax,ebp
       jmp       near ptr 000000000000D3FC
M03_L18:
       mov       rcx,7FF83A4DA020
       call      0000000000008420
       xor       eax,eax
       vzeroupper
       vmovaps   xmm6,[rsp+40]
       vmovaps   xmm7,[rsp+30]
       vmovaps   xmm8,[rsp+20]
       add       rsp,50
       pop       rbx
       pop       rbp
       pop       rsi
       pop       rdi
       pop       r14
       ret
M03_L19:
       mov       rcx,7FF83A4DA024
       call      0000000000008420
       mov       eax,1
       vzeroupper
       vmovaps   xmm6,[rsp+40]
       vmovaps   xmm7,[rsp+30]
       vmovaps   xmm8,[rsp+20]
       add       rsp,50
       pop       rbx
       pop       rbp
       pop       rsi
       pop       rdi
       pop       r14
       ret
M03_L20:
       mov       rcx,7FF83A4DA028
       call      0000000000008420
       mov       eax,2
       vzeroupper
       vmovaps   xmm6,[rsp+40]
       vmovaps   xmm7,[rsp+30]
       vmovaps   xmm8,[rsp+20]
       add       rsp,50
       pop       rbx
       pop       rbp
       pop       rsi
       pop       rdi
       pop       r14
       ret
M03_L21:
       mov       rcx,7FF83A4DA02C
       call      0000000000008420
       mov       eax,3
       jmp       near ptr 000000000000D3FC
M03_L22:
       mov       rdi,rbx
       add       ecx,0FFFFFFF0
       jmp       near ptr 000000000000D46E
M03_L23:
       mov       rcx,7FF83A4DA058
       call      0000000000008420
       mov       rdi,rbx
       jmp       near ptr 000000000000D4A7
M03_L24:
       mov       rdi,rbx
       add       ecx,0FFFFFFF8
       jmp       near ptr 000000000000D4EE
; Total bytes of code 957
```
```assembly
; Tedd.Voxtree.OctreeChunk.GetChannel(Int32)
       push      rbp
       sub       rsp,70
       lea       rbp,[rsp+70]
       xor       eax,eax
       mov       [rbp+0FFB8],rax
       vxorps    xmm4,xmm4,xmm4
       vmovdqu   ymmword ptr [rbp+0FFC0],ymm4
       vmovdqu   ymmword ptr [rbp+0FFE0],ymm4
       mov       [rbp+10],rcx
       mov       [rbp+18],rdx
       mov       [rbp+20],r8d
       lea       rdx,[rbp+0FFE0]
       mov       rcx,[rbp+10]
       mov       r8d,[rbp+20]
       call      qword ptr [0DB30]; Tedd.Voxtree.OctreeChunk.GetChannelData(Int32)
       lea       rdx,[rbp+0FFF0]
       lea       rcx,[rbp+0FFE0]
       call      qword ptr [0DAD0]; System.ReadOnlyMemory`1[[System.Byte, System.Private.CoreLib]].get_Span()
       mov       rcx,[rbp+10]
       call      qword ptr [0DA28]; Tedd.Voxtree.OctreeChunk.get_Levels()
       mov       [rbp+0FFDC],eax
       vmovdqu   xmm0,xmmword ptr [rbp+0FFF0]
       vmovdqu   xmmword ptr [rbp+0FFC8],xmm0
       vmovdqu   xmm0,xmmword ptr [rbp+0FFF0]
       vmovdqu   xmmword ptr [rbp+0FFB8],xmm0
       lea       rcx,[rbp+0FFB8]
       call      qword ptr [0D830]; Tedd.Voxtree.OctreeCodec.GetStorageKindUnchecked(System.ReadOnlySpan`1<Byte>)
       mov       [rbp+0FFB4],eax
       mov       r9d,[rbp+0FFB4]
       lea       rdx,[rbp+0FFC8]
       mov       r8d,[rbp+0FFDC]
       mov       rcx,[rbp+18]
       call      qword ptr [0DB48]; Tedd.Voxtree.OctreeSpan.CreateTrusted(System.ReadOnlySpan`1<Byte>, Int32, Tedd.Voxtree.StorageKind)
       mov       rax,[rbp+18]
       add       rsp,70
       pop       rbp
       ret
; Total bytes of code 152
```
```assembly
; Tedd.Voxtree.OctreeCodec.TryGetUnchecked(System.ReadOnlySpan`1<Byte>, Int32, Tedd.Voxtree.StorageKind, Int32, Int32, Int32, UInt32 ByRef)
       push      rbp
       sub       rsp,130
       lea       rbp,[rsp+130]
       vxorps    xmm4,xmm4,xmm4
       vmovdqa   xmmword ptr [rbp+0FEF0],xmm4
       mov       rax,0FFFFFFFFFF40
M05_L00:
       vmovdqa   xmmword ptr [rbp+rax+0FFC0],xmm4
       vmovdqa   xmmword ptr [rbp+rax+0FFD0],xmm4
       vmovdqa   xmmword ptr [rbp+rax+0FFE0],xmm4
       add       rax,30
       jne       short 00000000000095E6
       mov       [rbp+0FFC0],rax
       mov       [rbp+10],rcx
       mov       [rbp+18],edx
       mov       [rbp+20],r8d
       mov       [rbp+28],r9d
       mov       dword ptr [rbp+0FF38],3E8
       mov       rax,[rbp+40]
       xor       ecx,ecx
       mov       [rax],ecx
       mov       eax,1
       mov       ecx,[rbp+18]
       shlx      eax,eax,ecx
       mov       [rbp+0FFC4],eax
       movzx     eax,byte ptr [rbp+20]
       cmp       eax,1
       jne       short 00000000000096AA
       mov       dword ptr [rbp+0FFA0],2
       mov       rax,[rbp+10]
       vmovdqu   xmm0,xmmword ptr [rax]
       vmovdqu   xmmword ptr [rbp+0FF20],xmm0
       lea       rcx,[rbp+0FF20]
       lea       rdx,[rbp+0FFA0]
       mov       r8,[rbp+40]
       call      qword ptr [0D5C0]; Tedd.Voxtree.OctreeCodec.TryReadVarUInt(System.ReadOnlySpan`1<Byte>, Int32 ByRef, UInt32 ByRef)
       test      eax,eax
       je        short 0000000000009696
       mov       rcx,7FF83A8A5868
       call      0000000000008420
       mov       eax,[rbp+0FFA0]
       mov       rcx,[rbp+10]
       cmp       eax,[rcx+8]
       sete      al
       movzx     eax,al
       mov       [rbp+0FF34],eax
       jmp       near ptr 0000000000009AB2
M05_L01:
       mov       rcx,7FF83A8A586C
       call      0000000000008420
       jmp       near ptr 0000000000009AA7
M05_L02:
       movzx     eax,byte ptr [rbp+20]
       cmp       eax,2
       jne       short 000000000000972C
       mov       rcx,7FF83A8A5870
       call      0000000000008420
       mov       eax,[rbp+28]
       imul      eax,[rbp+0FFC4]
       imul      eax,[rbp+0FFC4]
       mov       ecx,[rbp+30]
       imul      ecx,[rbp+0FFC4]
       add       eax,ecx
       add       eax,[rbp+38]
       mov       [rbp+0FF9C],eax
       mov       eax,[rbp+0FF9C]
       lea       eax,[rax*4+2]
       mov       [rbp+0FF98],eax
       lea       rdx,[rbp+0FF40]
       mov       rcx,[rbp+10]
       mov       r8d,[rbp+0FF98]
       mov       r9d,4
       call      qword ptr [6208]; System.ReadOnlySpan`1[[System.Byte, System.Private.CoreLib]].Slice(Int32, Int32)
       vmovdqu   xmm0,xmmword ptr [rbp+0FF40]
       vmovdqu   xmmword ptr [rbp+0FF10],xmm0
       lea       rcx,[rbp+0FF10]
       call      qword ptr [0E7F0]; Precode of System.Buffers.Binary.BinaryPrimitives.ReadUInt32LittleEndian(System.ReadOnlySpan`1<Byte>)
       mov       rcx,[rbp+40]
       mov       [rcx],eax
       jmp       near ptr 00000000000099E7
M05_L03:
       cmp       dword ptr [rbp+18],0
       je        short 000000000000974B
       mov       rax,[rbp+10]
       cmp       dword ptr [rax+8],0C
       jge       short 000000000000975F
       mov       rcx,7FF83A8A5874
       call      0000000000008420
M05_L04:
       mov       rcx,7FF83A8A5878
       call      0000000000008420
       jmp       near ptr 0000000000009AA7
M05_L05:
       mov       rax,[rbp+10]
       mov       [rbp+0FF90],rax
       lea       rdx,[rbp+0FFB0]
       mov       rax,[rbp+0FF90]
       mov       eax,[rax+8]
       lea       r9d,[rax+0FFFF]
       mov       rcx,[rbp+0FF90]
       xor       r8d,r8d
       call      qword ptr [6208]; System.ReadOnlySpan`1[[System.Byte, System.Private.CoreLib]].Slice(Int32, Int32)
       mov       rax,[rbp+10]
       mov       eax,[rax+8]
       dec       eax
       mov       [rbp+0FF54],eax
       mov       rax,[rbp+10]
       mov       eax,[rax+8]
       cmp       [rbp+0FF54],eax
       jae       near ptr 0000000000009AC2
       mov       rax,[rbp+10]
       mov       rax,[rax]
       mov       ecx,[rbp+0FF54]
       movzx     eax,byte ptr [rax+rcx]
       mov       [rbp+0FFAC],eax
       mov       eax,[rbp+0FFB8]
       sub       eax,[rbp+0FFAC]
       mov       [rbp+0FFA8],eax
       cmp       dword ptr [rbp+0FFAC],9
       jl        short 00000000000097DD
       cmp       dword ptr [rbp+0FFAC],29
       jle       short 00000000000097E6
       mov       rcx,7FF83A8A587C
       call      0000000000008420
M05_L06:
       mov       dword ptr [rbp+0FF8C],1
       jmp       short 00000000000097FA
M05_L07:
       mov       rcx,7FF83A8A5880
       call      0000000000008420
       xor       eax,eax
       mov       [rbp+0FF8C],eax
M05_L08:
       cmp       dword ptr [rbp+0FF8C],0
       jne       short 0000000000009815
       cmp       dword ptr [rbp+0FFA8],2
       jge       short 0000000000009829
       mov       rcx,7FF83A8A5884
       call      0000000000008420
M05_L09:
       mov       rcx,7FF83A8A5888
       call      0000000000008420
       jmp       near ptr 0000000000009AA7
M05_L10:
       mov       eax,[rbp+18]
       dec       eax
       mov       [rbp+0FF88],eax
       jmp       near ptr 0000000000009A66
M05_L11:
       mov       eax,[rbp+0FFA8]
       mov       [rbp+0FF84],eax
       mov       eax,[rbp+0FF84]
       cmp       eax,[rbp+0FFB8]
       jb        short 0000000000009858
       mov       rcx,7FF83A8A588C
       call      0000000000008420
       jmp       near ptr 0000000000009AA7
M05_L12:
       mov       eax,[rbp+0FF84]
       mov       [rbp+0FF78],eax
       mov       eax,[rbp+0FF78]
       mov       [rbp+0FF50],eax
       mov       eax,[rbp+0FF78]
       inc       eax
       mov       [rbp+0FF78],eax
       mov       eax,[rbp+0FFB8]
       cmp       [rbp+0FF50],eax
       jae       near ptr 0000000000009AC2
       mov       eax,[rbp+0FF50]
       mov       rcx,[rbp+0FFB0]
       movzx     eax,byte ptr [rcx+rax]
       mov       [rbp+0FF74],eax
       mov       eax,[rbp+0FF88]
       sarx      eax,[rbp+28],eax
       and       eax,1
       shl       eax,2
       mov       ecx,[rbp+0FF88]
       sarx      ecx,[rbp+30],ecx
       and       ecx,1
       add       ecx,ecx
       or        eax,ecx
       mov       ecx,[rbp+0FF88]
       sarx      ecx,[rbp+38],ecx
       and       ecx,1
       or        eax,ecx
       mov       [rbp+0FF70],eax
       xor       eax,eax
       mov       [rbp+0FF64],eax
       jmp       short 0000000000009938
M05_L13:
       vmovdqu   xmm0,xmmword ptr [rbp+0FFB0]
       vmovdqu   xmmword ptr [rbp+0FF00],xmm0
       lea       rcx,[rbp+0FF00]
       lea       r8,[rbp+0FF58]
       lea       rdx,[rbp+0FF78]
       call      qword ptr [0D5C0]; Tedd.Voxtree.OctreeCodec.TryReadVarUInt(System.ReadOnlySpan`1<Byte>, Int32 ByRef, UInt32 ByRef)
       test      eax,eax
       jne       short 000000000000991B
       mov       rcx,7FF83A8A5890
       call      0000000000008420
       jmp       near ptr 0000000000009AA7
M05_L14:
       mov       rcx,7FF83A8A5894
       call      0000000000008420
       mov       eax,[rbp+0FF64]
       inc       eax
       mov       [rbp+0FF64],eax
M05_L15:
       mov       eax,[rbp+0FF38]
       dec       eax
       mov       [rbp+0FF38],eax
       cmp       dword ptr [rbp+0FF38],0
       jg        short 0000000000009960
       lea       rcx,[rbp+0FF38]
       mov       edx,125
       call      0000000000003990
M05_L16:
       mov       eax,[rbp+0FF64]
       cmp       eax,[rbp+0FF70]
       jl        near ptr 00000000000098DB
       vmovdqu   xmm0,xmmword ptr [rbp+0FFB0]
       vmovdqu   xmmword ptr [rbp+0FEF0],xmm0
       lea       rcx,[rbp+0FEF0]
       lea       r8,[rbp+0FF68]
       lea       rdx,[rbp+0FF78]
       call      qword ptr [0D5C0]; Tedd.Voxtree.OctreeCodec.TryReadVarUInt(System.ReadOnlySpan`1<Byte>, Int32 ByRef, UInt32 ByRef)
       test      eax,eax
       jne       short 00000000000099B2
       mov       rcx,7FF83A8A5898
       call      0000000000008420
       jmp       near ptr 0000000000009AA7
M05_L17:
       mov       eax,1
       mov       ecx,[rbp+0FF70]
       shlx      eax,eax,ecx
       and       eax,[rbp+0FF74]
       test      eax,eax
       je        short 00000000000099F5
       mov       rcx,7FF83A8A589C
       call      0000000000008420
       mov       rax,[rbp+40]
       mov       ecx,[rbp+0FF68]
       mov       [rax],ecx
M05_L18:
       mov       eax,1
       add       rsp,130
       pop       rbp
       ret
M05_L19:
       cmp       dword ptr [rbp+0FF88],0
       je        short 0000000000009A21
       cmp       dword ptr [rbp+0FF68],0
       je        short 0000000000009A32
       mov       eax,[rbp+0FF84]
       add       eax,0FFFFFFFE
       cmp       [rbp+0FF68],eax
       jbe       short 0000000000009A43
       mov       rcx,7FF83A8A58A0
       call      0000000000008420
M05_L20:
       mov       rcx,7FF83A8A58A4
       call      0000000000008420
       jmp       short 0000000000009AA7
M05_L21:
       mov       rcx,7FF83A8A58A8
       call      0000000000008420
       jmp       short 0000000000009A21
M05_L22:
       mov       rcx,7FF83A8A58AC
       call      0000000000008420
       mov       eax,[rbp+0FF84]
       sub       eax,[rbp+0FF68]
       mov       [rbp+0FFA8],eax
       mov       eax,[rbp+0FF88]
       dec       eax
       mov       [rbp+0FF88],eax
M05_L23:
       mov       eax,[rbp+0FF38]
       dec       eax
       mov       [rbp+0FF38],eax
       cmp       dword ptr [rbp+0FF38],0
       jg        short 0000000000009A8E
       lea       rcx,[rbp+0FF38]
       mov       edx,16A
       call      0000000000003990
M05_L24:
       cmp       dword ptr [rbp+0FF88],0
       jge       near ptr 0000000000009836
       mov       rcx,7FF83A8A58B0
       call      0000000000008420
M05_L25:
       xor       eax,eax
       add       rsp,130
       pop       rbp
       ret
M05_L26:
       movzx     eax,byte ptr [rbp+0FF34]
       add       rsp,130
       pop       rbp
       ret
M05_L27:
       call      0000000000001788
       int       3
; Total bytes of code 1288
```
```assembly
; Tedd.Voxtree.HotOctreeChunk.GetChannelSpan(Int32)
       push      rbp
       sub       rsp,50
       lea       rbp,[rsp+50]
       xor       eax,eax
       mov       [rbp+0FFD8],rax
       vxorps    xmm4,xmm4,xmm4
       vmovdqu   ymmword ptr [rbp+0FFE0],ymm4
       mov       [rbp+10],rcx
       mov       [rbp+18],rdx
       mov       [rbp+20],r8d
       mov       rcx,[rbp+10]
       call      qword ptr [0E688]; Tedd.Voxtree.HotOctreeChunk.GetValues()
       mov       [rbp+0FFF0],rax
       mov       rax,[rbp+0FFF0]
       mov       [rbp+0FFE8],rax
       mov       rcx,[rbp+10]
       call      qword ptr [0E6A0]; Tedd.Voxtree.HotOctreeChunk.get_ChannelCount()
       cmp       eax,[rbp+20]
       ja        short 00000000000081BE
       mov       rcx,offset MT_System.ArgumentOutOfRangeException
       call      0000000000005240
       mov       [rbp+0FFE0],rax
       mov       ecx,3E1
       mov       rdx,7FF83A882920
       call      qword ptr [7258]; Precode of System.String.StrCns(UInt32, IntPtr)
       mov       [rbp+0FFD8],rax
       mov       rdx,[rbp+0FFD8]
       mov       rcx,[rbp+0FFE0]
       call      qword ptr [0D1A0]; Precode of System.ArgumentOutOfRangeException..ctor(System.String)
       mov       rcx,[rbp+0FFE0]
       call      000000000000B8A0
       int       3
M06_L00:
       mov       rcx,[rbp+10]
       call      qword ptr [0E640]; Tedd.Voxtree.HotOctreeChunk.get_Levels()
       mov       ecx,eax
       call      qword ptr [0D188]; Tedd.Voxtree.OctreeCodec.GetVoxelCount(Int32)
       mov       [rbp+0FFFC],eax
       mov       eax,[rbp+20]
       mov       r8d,eax
       imul      r8d,[rbp+0FFFC]
       mov       rcx,[rbp+18]
       mov       rdx,[rbp+0FFE8]
       mov       r9d,[rbp+0FFFC]
       call      qword ptr [0E670]; System.MemoryExtensions.AsSpan[[System.UInt32, System.Private.CoreLib]](UInt32[], Int32, Int32)
       mov       rax,[rbp+18]
       add       rsp,50
       pop       rbp
       ret
; Total bytes of code 202
```
```assembly
; Tedd.Voxtree.HotOctreeChunk.get_Levels()
       push      rbp
       mov       rbp,rsp
       mov       [rbp+10],rcx
       mov       rax,[rbp+10]
       mov       eax,[rax+20]
       pop       rbp
       ret
; Total bytes of code 17
```
```assembly
; Tedd.Voxtree.DenseVoxel.GetIndex(Int32, Int32, Int32, Int32, Tedd.Voxtree.DenseVoxelLayout)
       push      rbp
       sub       rsp,40
       lea       rbp,[rsp+40]
       vxorps    xmm4,xmm4,xmm4
       vmovdqu   xmmword ptr [rbp+0FFE8],xmm4
       xor       eax,eax
       mov       [rbp+0FFF8],rax
       mov       [rbp+10],ecx
       mov       [rbp+18],edx
       mov       [rbp+20],r8d
       mov       [rbp+28],r9d
       mov       ecx,[rbp+28]
       call      qword ptr [0D170]; Tedd.Voxtree.OctreeCodec.ValidateLevels(Int32)
       mov       ecx,[rbp+30]
       call      qword ptr [0D068]; Tedd.Voxtree.DenseVoxel.Validate(Tedd.Voxtree.DenseVoxelLayout)
       mov       eax,1
       mov       ecx,[rbp+28]
       shlx      eax,eax,ecx
       mov       [rbp+0FFFC],eax
       mov       eax,[rbp+10]
       cmp       eax,[rbp+0FFFC]
       jae       short 00000000000083B0
       mov       eax,[rbp+18]
       cmp       eax,[rbp+0FFFC]
       jae       short 00000000000083F4
       mov       eax,[rbp+20]
       cmp       eax,[rbp+0FFFC]
       jb        short 0000000000008405
       mov       rcx,7FF83A971458
       call      0000000000008420
M08_L00:
       mov       rcx,offset MT_System.ArgumentOutOfRangeException
       call      0000000000005240
       mov       [rbp+0FFF0],rax
       mov       ecx,3F1
       mov       rdx,7FF83A882920
       call      qword ptr [7258]; Precode of System.String.StrCns(UInt32, IntPtr)
       mov       [rbp+0FFE8],rax
       mov       rdx,[rbp+0FFE8]
       mov       rcx,[rbp+0FFF0]
       call      qword ptr [0D1A0]; Precode of System.ArgumentOutOfRangeException..ctor(System.String)
       mov       rcx,[rbp+0FFF0]
       call      000000000000B8A0
       int       3
M08_L01:
       mov       rcx,7FF83A97145C
       call      0000000000008420
       jmp       short 00000000000083B0
M08_L02:
       mov       rcx,7FF83A971460
       call      0000000000008420
       mov       eax,[rbp+30]
       mov       [rsp+20],eax
       mov       ecx,[rbp+10]
       mov       edx,[rbp+18]
       mov       r8d,[rbp+20]
       mov       r9d,[rbp+0FFFC]
       call      qword ptr [0E6B8]; Tedd.Voxtree.DenseVoxel.Index(Int32, Int32, Int32, Int32, Tedd.Voxtree.DenseVoxelLayout)
       nop
       add       rsp,40
       pop       rbp
       ret
; Total bytes of code 246
```
```assembly
; Tedd.Voxtree.OctreeChunk.GetChannelData(Int32)
       push      rbp
       sub       rsp,30
       lea       rbp,[rsp+30]
       xor       eax,eax
       mov       [rbp+0FFF8],rax
       mov       [rbp+0FFF0],rax
       mov       [rbp+10],rcx
       mov       [rbp+18],rdx
       mov       [rbp+20],r8d
       mov       rcx,[rbp+10]
       call      qword ptr [0DA40]; Tedd.Voxtree.OctreeChunk.get_ChannelCount()
       cmp       eax,[rbp+20]
       ja        short 0000000000009313
       mov       rcx,offset MT_System.ArgumentOutOfRangeException
       call      0000000000005240
       mov       [rbp+0FFF8],rax
       mov       ecx,3E1
       mov       rdx,7FF83A882920
       call      qword ptr [7258]; Precode of System.String.StrCns(UInt32, IntPtr)
       mov       [rbp+0FFF0],rax
       mov       rdx,[rbp+0FFF0]
       mov       rcx,[rbp+0FFF8]
       call      qword ptr [0D1A0]; Precode of System.ArgumentOutOfRangeException..ctor(System.String)
       mov       rcx,[rbp+0FFF8]
       call      000000000000B8A0
       int       3
M09_L00:
       mov       rax,[rbp+10]
       mov       rax,[rax+8]
       mov       ecx,[rbp+20]
       cmp       ecx,[rax+8]
       jae       short 0000000000009344
       mov       edx,ecx
       imul      rdx,10
       lea       rax,[rax+rdx+10]
       mov       rcx,[rbp+18]
       vmovdqu   xmm0,xmmword ptr [rax]
       vmovdqu   xmmword ptr [rcx],xmm0
       mov       rax,[rbp+18]
       add       rsp,30
       pop       rbp
       ret
M09_L01:
       call      0000000000001788
       int       3
; Total bytes of code 170
```
```assembly
; System.ReadOnlyMemory`1[[System.Byte, System.Private.CoreLib]].get_Span()
       push      r14
       push      rdi
       push      rsi
       push      rbp
       push      rbx
       sub       rsp,30
       xor       eax,eax
       mov       [rsp+20],rax
       mov       rsi,rcx
       mov       rbx,rdx
       xor       edi,edi
       xor       ebp,ebp
       mov       r14,[rsi]
       test      r14,r14
       je        short 0000000000009115
       mov       rcx,[r14]
       test      dword ptr [rcx],80000000
       je        short 0000000000009138
       lea       rdi,[r14+10]
       mov       ebp,[r14+8]
M10_L00:
       mov       ecx,[rsi+8]
       and       ecx,7FFFFFFF
       mov       r14d,ecx
       mov       esi,[rsi+0C]
       mov       ecx,esi
       add       rcx,r14
       mov       eax,ebp
       cmp       rcx,rax
       ja        short 0000000000009179
       mov       rcx,7FF83A971704
       call      0000000000008420
       add       rdi,r14
       mov       ebp,esi
M10_L01:
       mov       rcx,7FF83A971708
       call      0000000000008420
       mov       [rbx],rdi
       mov       [rbx+8],ebp
       mov       rax,rbx
       add       rsp,30
       pop       rbx
       pop       rbp
       pop       rsi
       pop       rdi
       pop       r14
       ret
M10_L02:
       mov       rcx,7FF83A9715F0
       call      0000000000008420
       mov       rcx,r14
       mov       rdx,7FF83A9715F8
       call      0000000000004AB0
       mov       rcx,r14
       lea       rdx,[rsp+20]
       mov       rax,[r14]
       mov       rax,[rax+40]
       call      qword ptr [rax+28]
       mov       ebp,[rsp+28]
       mov       rdi,[rsp+20]
       jmp       near ptr 00000000000090E6
M10_L03:
       mov       rcx,7FF83A971700
       call      0000000000008420
       call      qword ptr [7C18]; Precode of System.ThrowHelper.ThrowArgumentOutOfRangeException()
       int       3
; Total bytes of code 223
```
```assembly
; Tedd.Voxtree.OctreeChunk.get_Levels()
       mov       eax,[rcx+10]
       ret
; Total bytes of code 4
```
```assembly
; Tedd.Voxtree.OctreeCodec.GetStorageKindUnchecked(System.ReadOnlySpan`1<Byte>)
       push      rbp
       sub       rsp,20
       lea       rbp,[rsp+20]
       mov       [rbp+10],rcx
       mov       rax,[rbp+10]
       cmp       dword ptr [rax+8],1
       jbe       short 000000000000908C
       mov       rax,[rbp+10]
       mov       rax,[rax]
       movzx     eax,byte ptr [rax+1]
       and       eax,3
       add       rsp,20
       pop       rbp
       ret
M12_L00:
       call      0000000000001788
       int       3
; Total bytes of code 50
```
```assembly
; Tedd.Voxtree.OctreeSpan.CreateTrusted(System.ReadOnlySpan`1<Byte>, Int32, Tedd.Voxtree.StorageKind)
       push      rbp
       sub       rsp,50
       lea       rbp,[rsp+50]
       xor       eax,eax
       mov       [rbp+0FFD8],rax
       vxorps    xmm4,xmm4,xmm4
       vmovdqu   ymmword ptr [rbp+0FFE0],ymm4
       mov       [rbp+10],rcx
       mov       [rbp+18],rdx
       mov       [rbp+20],r8d
       mov       [rbp+28],r9d
       mov       rax,[rbp+18]
       vmovdqu   xmm0,xmmword ptr [rax]
       vmovdqu   xmmword ptr [rbp+0FFD8],xmm0
       lea       rdx,[rbp+0FFD8]
       movzx     r9d,byte ptr [rbp+28]
       lea       rcx,[rbp+0FFE8]
       mov       r8d,[rbp+20]
       call      qword ptr [0DB60]; Tedd.Voxtree.OctreeSpan..ctor(System.ReadOnlySpan`1<Byte>, Int32, Tedd.Voxtree.StorageKind)
       mov       rax,[rbp+10]
       vmovdqu   xmm0,xmmword ptr [rbp+0FFE8]
       vmovdqu   xmmword ptr [rax],xmm0
       mov       rcx,[rbp+0FFF8]
       mov       [rax+10],rcx
       mov       rax,[rbp+10]
       add       rsp,50
       pop       rbp
       ret
; Total bytes of code 108
```
```assembly
; Tedd.Voxtree.OctreeCodec.TryReadVarUInt(System.ReadOnlySpan`1<Byte>, Int32 ByRef, UInt32 ByRef)
       push      rbp
       sub       rsp,80
       lea       rbp,[rsp+80]
       vxorps    xmm4,xmm4,xmm4
       vmovdqu   xmmword ptr [rbp+0FFB8],xmm4
       mov       [rbp+10],rcx
       mov       [rbp+18],rdx
       mov       [rbp+20],r8
       mov       dword ptr [rbp+0FFB0],3E8
       mov       rax,[rbp+20]
       xor       ecx,ecx
       mov       [rax],ecx
       mov       rax,[rbp+18]
       mov       eax,[rax]
       mov       [rbp+0FFC4],eax
       xor       eax,eax
       mov       [rbp+0FFC0],eax
       jmp       near ptr 0000000000007639
M14_L00:
       mov       rax,[rbp+18]
       mov       eax,[rax]
       mov       rcx,[rbp+10]
       cmp       eax,[rcx+8]
       jb        short 000000000000754A
       mov       rcx,7FF83A88DDD8
       call      0000000000008420
       jmp       near ptr 000000000000766E
M14_L01:
       mov       rax,[rbp+18]
       mov       eax,[rax]
       mov       [rbp+0FFB8],eax
       mov       eax,[rbp+0FFB8]
       inc       eax
       mov       rcx,[rbp+18]
       mov       [rcx],eax
       mov       rax,[rbp+10]
       mov       eax,[rax+8]
       cmp       [rbp+0FFB8],eax
       jae       near ptr 0000000000007686
       mov       rax,[rbp+10]
       mov       rax,[rax]
       mov       ecx,[rbp+0FFB8]
       movzx     eax,byte ptr [rax+rcx]
       mov       [rbp+0FFBC],eax
       cmp       dword ptr [rbp+0FFC0],1C
       jne       short 00000000000075B4
       mov       eax,[rbp+0FFBC]
       and       eax,0F0
       test      eax,eax
       je        short 00000000000075A5
       mov       rcx,7FF83A88DDDC
       call      0000000000008420
       jmp       near ptr 000000000000766E
M14_L02:
       mov       rcx,7FF83A88DDE0
       call      0000000000008420
M14_L03:
       mov       eax,[rbp+0FFBC]
       and       eax,7F
       mov       ecx,[rbp+0FFC0]
       shlx      eax,eax,ecx
       mov       rcx,[rbp+20]
       or        [rcx],eax
       mov       eax,[rbp+0FFBC]
       and       eax,80
       test      eax,eax
       jne       short 0000000000007621
       mov       rax,[rbp+18]
       mov       eax,[rax]
       sub       eax,[rbp+0FFC4]
       cmp       eax,1
       je        short 0000000000007604
       mov       rcx,7FF83A88DDE4
       call      0000000000008420
       mov       eax,[rbp+0FFBC]
       and       eax,7F
       test      eax,eax
       setne     al
       movzx     eax,al
       mov       [rbp+0FFAC],eax
       jmp       short 0000000000007679
M14_L04:
       mov       rcx,7FF83A88DDE8
       call      0000000000008420
       mov       eax,1
       add       rsp,80
       pop       rbp
       ret
M14_L05:
       mov       rcx,7FF83A88DDEC
       call      0000000000008420
       mov       eax,[rbp+0FFC0]
       add       eax,7
       mov       [rbp+0FFC0],eax
M14_L06:
       mov       eax,[rbp+0FFB0]
       dec       eax
       mov       [rbp+0FFB0],eax
       cmp       dword ptr [rbp+0FFB0],0
       jg        short 0000000000007655
       lea       rcx,[rbp+0FFB0]
       mov       edx,65
       call      0000000000003990
M14_L07:
       cmp       dword ptr [rbp+0FFC0],1C
       jle       near ptr 0000000000007527
       mov       rcx,7FF83A88DDF0
       call      0000000000008420
M14_L08:
       xor       eax,eax
       add       rsp,80
       pop       rbp
       ret
M14_L09:
       movzx     eax,byte ptr [rbp+0FFAC]
       add       rsp,80
       pop       rbp
       ret
M14_L10:
       call      0000000000001788
       int       3
; Total bytes of code 428
```
```assembly
; System.ReadOnlySpan`1[[System.Byte, System.Private.CoreLib]].Slice(Int32, Int32)
       push      rdi
       push      rsi
       push      rbp
       push      rbx
       sub       rsp,28
       mov       rsi,rcx
       mov       rbx,rdx
       mov       edi,r8d
       mov       ebp,r9d
       mov       ecx,edi
       mov       eax,ebp
       add       rcx,rax
       mov       eax,[rsi+8]
       cmp       rcx,rax
       ja        short 0000000000009029
       mov       rcx,7FF83A97159C
       call      0000000000008420
       mov       eax,edi
       add       rax,[rsi]
       mov       [rbx],rax
       mov       [rbx+8],ebp
       mov       rax,rbx
       add       rsp,28
       pop       rbx
       pop       rbp
       pop       rsi
       pop       rdi
       ret
M15_L00:
       mov       rcx,7FF83A971598
       call      0000000000008420
       call      qword ptr [7C18]; Precode of System.ThrowHelper.ThrowArgumentOutOfRangeException()
       int       3
; Total bytes of code 95
```
```assembly
; Tedd.Voxtree.HotOctreeChunk.GetValues()
       push      rbp
       sub       rsp,40
       lea       rbp,[rsp+40]
       vxorps    xmm4,xmm4,xmm4
       vmovdqu   ymmword ptr [rbp+0FFE0],ymm4
       mov       [rbp+10],rcx
       mov       rax,[rbp+10]
       mov       rax,[rax+8]
       mov       [rbp+0FFF8],rax
       mov       rax,[rbp+0FFF8]
       mov       [rbp+0FFF0],rax
       cmp       qword ptr [rbp+0FFF8],0
       jne       short 0000000000008286
       mov       rcx,offset MT_System.InvalidOperationException
       call      0000000000005240
       mov       [rbp+0FFE8],rax
       mov       ecx,9F3
       mov       rdx,7FF83A882920
       call      qword ptr [7258]; Precode of System.String.StrCns(UInt32, IntPtr)
       mov       [rbp+0FFE0],rax
       mov       rdx,[rbp+0FFE0]
       mov       rcx,[rbp+0FFE8]
       call      qword ptr [65C8]; Precode of System.InvalidOperationException..ctor(System.String)
       mov       rcx,[rbp+0FFE8]
       call      000000000000B8A0
       int       3
M16_L00:
       mov       rax,[rbp+0FFF0]
       add       rsp,40
       pop       rbp
       ret
; Total bytes of code 128
```
```assembly
; Tedd.Voxtree.HotOctreeChunk.get_ChannelCount()
       push      rbp
       mov       rbp,rsp
       mov       [rbp+10],rcx
       mov       rax,[rbp+10]
       mov       eax,[rax+24]
       pop       rbp
       ret
; Total bytes of code 17
```
```assembly
; Tedd.Voxtree.OctreeCodec.GetVoxelCount(Int32)
       push      rbp
       mov       rbp,rsp
       mov       [rbp+10],ecx
       mov       eax,1
       mov       ecx,[rbp+10]
       lea       ecx,[rcx+rcx*2]
       shlx      eax,eax,ecx
       pop       rbp
       ret
; Total bytes of code 25
```
```assembly
; System.MemoryExtensions.AsSpan[[System.UInt32, System.Private.CoreLib]](UInt32[], Int32, Int32)
       sub       rsp,28
       test      rdx,rdx
       je        short 000000000000830F
       mov       r8d,r8d
       mov       eax,r9d
       add       rax,r8
       mov       r10d,[rdx+8]
       cmp       rax,r10
       ja        short 000000000000831B
       lea       rax,[rdx+r8*4+10]
M19_L00:
       mov       [rcx],rax
       mov       [rcx+8],r9d
       mov       rax,rcx
       add       rsp,28
       ret
M19_L01:
       or        r8d,r9d
       jne       short 000000000000831B
       xor       eax,eax
       xor       r9d,r9d
       jmp       short 0000000000008300
M19_L02:
       call      qword ptr [7C18]; Precode of System.ThrowHelper.ThrowArgumentOutOfRangeException()
       int       3
; Total bytes of code 66
```
```assembly
; Tedd.Voxtree.OctreeCodec.ValidateLevels(Int32)
       push      rbp
       sub       rsp,80
       lea       rbp,[rsp+80]
       xor       eax,eax
       mov       [rbp+0FFA8],rax
       vxorps    xmm4,xmm4,xmm4
       vmovdqu   ymmword ptr [rbp+0FFB0],ymm4
       vmovdqu   ymmword ptr [rbp+0FFD0],ymm4
       vmovdqa   xmmword ptr [rbp+0FFF0],xmm4
       mov       [rbp+10],ecx
       cmp       dword ptr [rbp+10],9
       jbe       near ptr 0000000000007FDF
       mov       rcx,offset MT_System.Int32
       call      0000000000005240
       mov       [rbp+0FFD0],rax
       mov       rax,[rbp+0FFD0]
       mov       ecx,[rbp+10]
       mov       [rax+8],ecx
       lea       rcx,[rbp+0FFD8]
       mov       edx,31
       mov       r8d,1
       call      qword ptr [68C8]; System.Runtime.CompilerServices.DefaultInterpolatedStringHandler..ctor(Int32, Int32)
       mov       ecx,1341
       mov       rdx,7FF83A882920
       call      qword ptr [7258]; Precode of System.String.StrCns(UInt32, IntPtr)
       mov       [rbp+0FFC0],rax
       mov       rdx,[rbp+0FFC0]
       lea       rcx,[rbp+0FFD8]
       call      qword ptr [6C10]; System.Runtime.CompilerServices.DefaultInterpolatedStringHandler.AppendLiteral(System.String)
       lea       rcx,[rbp+0FFD8]
       mov       edx,9
       call      qword ptr [6AD8]; System.Runtime.CompilerServices.DefaultInterpolatedStringHandler.AppendFormatted[[System.Int32, System.Private.CoreLib]](Int32)
       mov       ecx,369
       mov       rdx,7FF83A882920
       call      qword ptr [7258]; Precode of System.String.StrCns(UInt32, IntPtr)
       mov       [rbp+0FFB8],rax
       mov       rdx,[rbp+0FFB8]
       lea       rcx,[rbp+0FFD8]
       call      qword ptr [6C10]; System.Runtime.CompilerServices.DefaultInterpolatedStringHandler.AppendLiteral(System.String)
       mov       rcx,offset MT_System.ArgumentOutOfRangeException
       call      0000000000005240
       mov       [rbp+0FFC8],rax
       mov       ecx,1333
       mov       rdx,7FF83A882920
       call      qword ptr [7258]; Precode of System.String.StrCns(UInt32, IntPtr)
       mov       [rbp+0FFB0],rax
       lea       rcx,[rbp+0FFD8]
       call      qword ptr [68F8]; System.Runtime.CompilerServices.DefaultInterpolatedStringHandler.ToStringAndClear()
       mov       [rbp+0FFA8],rax
       mov       rdx,[rbp+0FFB0]
       mov       r9,[rbp+0FFA8]
       mov       r8,[rbp+0FFD0]
       mov       rcx,[rbp+0FFC8]
       call      qword ptr [7B10]; Precode of System.ArgumentOutOfRangeException..ctor(System.String, System.Object, System.String)
       mov       rcx,[rbp+0FFC8]
       call      000000000000B8A0
       int       3
M20_L00:
       add       rsp,80
       pop       rbp
       ret
; Total bytes of code 296
```
```assembly
; Tedd.Voxtree.DenseVoxel.Validate(Tedd.Voxtree.DenseVoxelLayout)
       push      rbp
       sub       rsp,30
       lea       rbp,[rsp+30]
       xor       eax,eax
       mov       [rbp+0FFF8],rax
       mov       [rbp+0FFF0],rax
       mov       [rbp+10],ecx
       cmp       dword ptr [rbp+10],0
       je        short 0000000000008076
       cmp       dword ptr [rbp+10],1
       je        short 0000000000008067
       mov       rcx,offset MT_System.ArgumentOutOfRangeException
       call      0000000000005240
       mov       [rbp+0FFF8],rax
       mov       ecx,4B5
       mov       rdx,7FF83A882920
       call      qword ptr [7258]; Precode of System.String.StrCns(UInt32, IntPtr)
       mov       [rbp+0FFF0],rax
       mov       rdx,[rbp+0FFF0]
       mov       rcx,[rbp+0FFF8]
       call      qword ptr [0D1A0]; Precode of System.ArgumentOutOfRangeException..ctor(System.String)
       mov       rcx,[rbp+0FFF8]
       call      000000000000B8A0
       int       3
M21_L00:
       mov       rcx,7FF83A971420
       call      0000000000008420
M21_L01:
       mov       rcx,7FF83A971424
       call      0000000000008420
       nop
       add       rsp,30
       pop       rbp
       ret
; Total bytes of code 140
```
```assembly
; Tedd.Voxtree.DenseVoxel.Index(Int32, Int32, Int32, Int32, Tedd.Voxtree.DenseVoxelLayout)
       push      rbp
       sub       rsp,20
       lea       rbp,[rsp+20]
       mov       [rbp+10],ecx
       mov       [rbp+18],edx
       mov       [rbp+20],r8d
       mov       [rbp+28],r9d
       cmp       dword ptr [rbp+30],0
       je        short 0000000000008494
       mov       rcx,7FF83A971498
       call      0000000000008420
       mov       ecx,[rbp+10]
       mov       edx,[rbp+18]
       mov       r8d,[rbp+20]
       call      qword ptr [0E6D0]; Tedd.MortonEncoding.Encode(UInt32, UInt32, UInt32)
       nop
       add       rsp,20
       pop       rbp
       ret
M22_L00:
       mov       rcx,7FF83A97149C
       call      0000000000008420
       mov       eax,[rbp+10]
       imul      eax,[rbp+28]
       add       eax,[rbp+18]
       imul      eax,[rbp+28]
       add       eax,[rbp+20]
       add       rsp,20
       pop       rbp
       ret
; Total bytes of code 106
```
```assembly
; Tedd.Voxtree.OctreeChunk.get_ChannelCount()
       mov       rax,[rcx+8]
       mov       eax,[rax+8]
       ret
; Total bytes of code 8
```
```assembly
; Tedd.Voxtree.OctreeSpan..ctor(System.ReadOnlySpan`1<Byte>, Int32, Tedd.Voxtree.StorageKind)
       push      rbp
       mov       rbp,rsp
       mov       [rbp+10],rcx
       mov       [rbp+18],rdx
       mov       [rbp+20],r8d
       mov       [rbp+28],r9d
       mov       rax,[rbp+18]
       mov       rcx,[rbp+10]
       vmovdqu   xmm0,xmmword ptr [rax]
       vmovdqu   xmmword ptr [rcx],xmm0
       mov       rax,[rbp+10]
       mov       ecx,[rbp+20]
       mov       [rax+10],ecx
       mov       rax,[rbp+10]
       mov       ecx,[rbp+28]
       mov       [rax+14],cl
       pop       rbp
       ret
; Total bytes of code 58
```
```assembly
; System.Runtime.CompilerServices.DefaultInterpolatedStringHandler..ctor(Int32, Int32)
       push      rdi
       push      rsi
       push      rbx
       sub       rsp,20
       mov       rbx,rcx
       mov       esi,edx
       mov       edi,r8d
       xor       eax,eax
       mov       [rbx],rax
       call      qword ptr [0A098]
       mov       rcx,[rax]
       imul      edx,edi,0B
       add       edx,esi
       mov       eax,100
       cmp       edx,100
       cmovle    edx,eax
       cmp       [rcx],ecx
       call      qword ptr [98B8]; Precode of System.Runtime.InteropServices.MemoryMarshal.CreateSpan[[System.Double, System.Private.CoreLib]](Double ByRef, Int32)
       mov       [rbx+8],rax
       test      rax,rax
       je        short 000000000000C4E0
       lea       rcx,[rax+10]
       mov       eax,[rax+8]
M25_L00:
       mov       [rbx+18],rcx
       mov       [rbx+20],eax
       xor       eax,eax
       mov       [rbx+10],eax
       mov       byte ptr [rbx+14],0
       add       rsp,20
       pop       rbx
       pop       rsi
       pop       rdi
       ret
M25_L01:
       xor       ecx,ecx
       xor       eax,eax
       jmp       short 000000000000C4C8
; Total bytes of code 102
```
```assembly
; System.Runtime.CompilerServices.DefaultInterpolatedStringHandler.AppendLiteral(System.String)
       push      rdi
       push      rsi
       push      rbx
       sub       rsp,20
       mov       rbx,rcx
       mov       rsi,rdx
       lea       r8,[rbx+18]
       mov       edx,[rbx+10]
       mov       ecx,[r8+8]
       cmp       edx,ecx
       ja        short 0000000000004EDB
       mov       r8,[r8]
       mov       eax,edx
       lea       rax,[r8+rax*2]
       sub       ecx,edx
       mov       edi,[rsi+8]
       cmp       edi,ecx
       ja        short 0000000000004EE2
       mov       r8d,edi
       add       r8,r8
       lea       rdx,[rsi+0C]
       mov       rcx,rax
       call      qword ptr [5818]; System.SpanHelpers.Memmove(Byte ByRef, Byte ByRef, UIntPtr)
       mov       rcx,7FF83A837978
       call      0000000000008420
       add       [rbx+10],edi
       add       rsp,20
       pop       rbx
       pop       rsi
       pop       rdi
       ret
M26_L00:
       call      qword ptr [7C18]; Precode of System.ThrowHelper.ThrowArgumentOutOfRangeException()
       int       3
M26_L01:
       mov       rcx,7FF83A83797C
       call      0000000000008420
       mov       rcx,rbx
       mov       rdx,rsi
       add       rsp,20
       pop       rbx
       pop       rsi
       pop       rdi
       jmp       qword ptr [68E0]; Precode of System.Runtime.CompilerServices.DefaultInterpolatedStringHandler.GrowThenCopyString(System.String)
; Total bytes of code 132
```
```assembly
; System.Runtime.CompilerServices.DefaultInterpolatedStringHandler.AppendFormatted[[System.Int32, System.Private.CoreLib]](Int32)
       push      rdi
       push      rsi
       push      rbp
       push      rbx
       sub       rsp,58
       xorps     xmm4,xmm4
       movaps    [rsp+30],xmm4
       movaps    [rsp+40],xmm4
       mov       rbx,rcx
       mov       esi,edx
       cmp       byte ptr [rbx+14],0
       jne       short 000000000000F15B
M27_L00:
       lea       rdx,[rbx+18]
       mov       r8d,[rbx+10]
       mov       edi,[rdx+8]
       cmp       r8d,edi
       ja        near ptr 000000000000F1D8
       mov       rdx,[rdx]
       mov       ecx,r8d
       lea       rbp,[rdx+rcx*2]
       sub       edi,r8d
       mov       rcx,[rbx]
       test      esi,esi
       jl        short 000000000000F173
       mov       [rsp+40],rbp
       mov       [rsp+48],edi
       lea       rdx,[rsp+40]
       lea       r8,[rsp+50]
       mov       ecx,esi
       call      qword ptr [0CF8]; Precode of System.Number.TryUInt32ToDecStr[[System.Char, System.Private.CoreLib]](UInt32, System.Span`1<Char>, Int32 ByRef)
M27_L01:
       test      eax,eax
       jne       short 000000000000F152
       mov       rcx,rbx
       call      qword ptr [4FF8]
       jmp       short 000000000000F100
M27_L02:
       mov       eax,[rsp+50]
       add       [rbx+10],eax
       jmp       short 000000000000F169
M27_L03:
       mov       rcx,rbx
       mov       edx,esi
       xor       r8d,r8d
       call      qword ptr [1B50]
M27_L04:
       nop
       add       rsp,58
       pop       rbx
       pop       rbp
       pop       rsi
       pop       rdi
       ret
M27_L05:
       test      rcx,rcx
       je        short 000000000000F180
       call      qword ptr [1260]; Precode of System.Globalization.NumberFormatInfo.<GetInstance>g__GetProviderNonNull|58_0(System.IFormatProvider)
       jmp       short 000000000000F186
M27_L06:
       call      qword ptr [1248]; Precode of System.Globalization.NumberFormatInfo.get_CurrentInfo()
M27_L07:
       mov       r8,[rax+28]
       test      r8,r8
       jne       short 000000000000F197
       xor       r9d,r9d
       xor       r8d,r8d
       jmp       short 000000000000F19F
M27_L08:
       lea       r9,[r8+0C]
       mov       r8d,[r8+8]
M27_L09:
       mov       [rsp+30],r9
       mov       [rsp+38],r8d
       mov       [rsp+40],rbp
       mov       [rsp+48],edi
       lea       r8,[rsp+50]
       mov       [rsp+20],r8
       lea       r8,[rsp+30]
       lea       r9,[rsp+40]
       mov       ecx,esi
       mov       edx,0FFFFFFFF
       call      qword ptr [0CE0]
       jmp       near ptr 000000000000F143
M27_L10:
       call      qword ptr [0F2B8]
       int       3
; Total bytes of code 255
```
```assembly
; System.Runtime.CompilerServices.DefaultInterpolatedStringHandler.ToStringAndClear()
       push      rdi
       push      rsi
       push      rbp
       push      rbx
       sub       rsp,38
       xor       eax,eax
       mov       [rsp+28],rax
       mov       rbx,rcx
       lea       rsi,[rbx+18]
       mov       rcx,rsi
       mov       eax,[rbx+10]
       cmp       eax,[rcx+8]
       ja        short 000000000000C6F7
       mov       rcx,[rcx]
       mov       [rsp+28],rcx
       mov       [rsp+30],eax
       lea       rcx,[rsp+28]
       call      qword ptr [0BB28]; Precode of System.String.Ctor(System.ReadOnlySpan`1<Char>)
       mov       rdi,rax
       mov       rbp,[rbx+8]
       xor       eax,eax
       mov       [rbx+8],rax
       mov       [rsi],rax
       mov       [rsi+8],rax
       mov       [rbx+10],eax
       test      rbp,rbp
       je        short 000000000000C6EB
       call      qword ptr [0A098]
       mov       rcx,[rax]
       mov       rdx,rbp
       xor       r8d,r8d
       cmp       [rcx],ecx
       call      qword ptr [98C0]; Precode of System.Collections.Generic.SegmentedArrayBuilder`1[[System.Double, System.Private.CoreLib]]..ctor(System.Span`1<Double>)
M28_L00:
       mov       rax,rdi
       add       rsp,38
       pop       rbx
       pop       rbp
       pop       rsi
       pop       rdi
       ret
M28_L01:
       call      qword ptr [0F2B8]
       int       3
; Total bytes of code 126
```
```assembly
; Tedd.MortonEncoding.Encode(UInt32, UInt32, UInt32)
       push      rbp
       mov       rbp,rsp
       mov       [rbp+10],ecx
       mov       [rbp+18],edx
       mov       [rbp+20],r8d
       mov       eax,[rbp+20]
       mov       ecx,24924924
       pdep      eax,eax,ecx
       mov       ecx,[rbp+18]
       mov       edx,12492492
       pdep      ecx,ecx,edx
       or        eax,ecx
       mov       ecx,[rbp+10]
       mov       edx,9249249
       pdep      ecx,ecx,edx
       or        eax,ecx
       pop       rbp
       ret
; Total bytes of code 59
```
**Method was not JITted yet.**
Tedd.Voxtree.OctreeThrowHelper.ThrowInvalidView()
Tedd.Voxtree.OctreeThrowHelper.ThrowCoordinate(System.String, Int32)
Tedd.Voxtree.OctreeThrowHelper.ThrowMalformed()
System.String.StrCns(UInt32, IntPtr)
System.ObjectDisposedException..ctor(System.String)
System.ArgumentOutOfRangeException..ctor(System.String)
System.ThrowHelper.ThrowArgumentOutOfRangeException()
System.Buffers.Binary.BinaryPrimitives.ReadUInt32LittleEndian(System.ReadOnlySpan`1<Byte>)
System.InvalidOperationException..ctor(System.String)
System.ArgumentOutOfRangeException..ctor(System.String, System.Object, System.String)

## .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v3 (Job: Job-GJBZFV(IterationCount=7, IterationTime=150ms, LaunchCount=1, WarmupCount=3))

```assembly
; Tedd.Voxtree.Benchmark.Tests.DeferredChunkReads.DeferredHits()
       push      r15
       push      r14
       push      r13
       push      r12
       push      rdi
       push      rsi
       push      rbp
       push      rbx
       sub       rsp,78
       vxorps    xmm4,xmm4,xmm4
       vmovdqu   ymmword ptr [rsp+40],ymm4
       vmovdqa   xmmword ptr [rsp+60],xmm4
       mov       rbx,rcx
       mov       rsi,[rbx+20]
       xor       edi,edi
       xor       ebp,ebp
       jmp       near ptr 0000000000009F59
       nop
M00_L00:
       mov       r11d,edx
       shl       r11d,4
       tzcnt     r9d,r9d
       sar       r9d,1
       add       r9d,r11d
M00_L01:
       test      r9d,r9d
       jl        near ptr 000000000000A17A
       mov       r10,[rsp+38]
       mov       rcx,[r10+20]
       mov       eax,[rsp+74]
       mov       edx,eax
       imul      edx,[r10+2C]
       mov       r8d,r9d
       sar       r8d,6
       add       edx,r8d
       cmp       edx,[rcx+8]
       jae       near ptr 000000000000A331
       mov       rcx,[rcx+rdx*8+10]
       bt        rcx,r9
       jae       near ptr 000000000000A17E
       mov       rcx,[r10+8]
       cmp       eax,[rcx+8]
       jae       near ptr 000000000000A331
       mov       edx,eax
       mov       rcx,[rcx+rdx*8+10]
       cmp       r9d,[rcx+8]
       jae       near ptr 000000000000A331
       mov       edx,r9d
       mov       r10d,[rcx+rdx*4+10]
M00_L02:
       add       edi,r10d
       inc       ebp
       cmp       ebp,100
       jge       near ptr 000000000000A0BB
M00_L03:
       cmp       ebp,[rsi+8]
       jae       near ptr 000000000000A331
       mov       r14d,[rsi+rbp*4+10]
       mov       r15,[rbx+18]
       mov       r13d,r14d
       sar       r13d,0A
       mov       r12d,r14d
       sar       r12d,5
       and       r12d,1F
       mov       eax,ebp
       and       eax,1
       mov       [rsp+74],eax
       and       r14d,1F
       cmp       byte ptr [r15+24],0
       jne       near ptr 000000000000A276
       mov       rdx,[r15+8]
       mov       rcx,[rdx+8]
       cmp       [rcx+8],eax
       jbe       near ptr 000000000000A2B2
       mov       edx,[rdx+10]
       mov       ecx,edx
       and       ecx,1F
       mov       r8d,1
       shlx      r8d,r8d,ecx
       cmp       r13d,r8d
       jae       near ptr 000000000000A2EE
       cmp       r12d,r8d
       jae       near ptr 000000000000A2EE
       cmp       r14d,r8d
       jae       near ptr 000000000000A2EE
       add       edx,edx
       shlx      edx,r13d,edx
       shlx      ecx,r12d,ecx
       or        edx,ecx
       or        edx,r14d
       cmp       qword ptr [r15+10],0
       jne       near ptr 000000000000A0D1
       mov       r10,[r15+18]
       test      r10,r10
       je        near ptr 000000000000A0F6
       mov       [rsp+38],r10
       mov       ecx,[r10+30]
       test      ecx,ecx
       je        near ptr 000000000000A08C
       mov       r8,[r10+10]
       test      r8,r8
       je        near ptr 000000000000A0FF
       cmp       ecx,1
       je        short 000000000000A097
       cmp       ecx,20
       jg        near ptr 000000000000A133
       add       ecx,0F
       and       ecx,0FFFFFFF0
       cmp       [r8+8],ecx
       jb        near ptr 000000000000A32A
       add       r8,10
       add       rcx,rcx
       shr       rcx,5
       cmp       rcx,7FFFFFFF
       ja        near ptr 000000000000A337
       vmovd     xmm0,edx
       vpbroadcastw ymm0,xmm0
       xor       edx,edx
       test      ecx,ecx
       jle       short 000000000000A087
M00_L04:
       mov       r9,rdx
       shl       r9,5
       vpcmpeqw  ymm1,ymm0,[r8+r9]
       vpmovmskb r9d,ymm1
       test      r9d,r9d
       jne       near ptr 0000000000009ED1
       inc       edx
       cmp       edx,ecx
       jl        short 000000000000A060
       mov       r10,[rsp+38]
       jmp       short 000000000000A08C
M00_L05:
       mov       r10,[rsp+38]
M00_L06:
       mov       r9d,0FFFFFFFF
       jmp       near ptr 0000000000009EE3
M00_L07:
       cmp       dword ptr [r8+8],0
       jbe       near ptr 000000000000A331
       movzx     r9d,word ptr [r8+10]
       cmp       r9d,edx
       je        short 000000000000A0B3
       mov       r10,[rsp+38]
       jmp       short 000000000000A08C
M00_L08:
       xor       r9d,r9d
       jmp       near ptr 0000000000009EE3
M00_L09:
       mov       eax,edi
       vzeroupper
       add       rsp,78
       pop       rbx
       pop       rbp
       pop       rsi
       pop       rdi
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       ret
M00_L10:
       mov       eax,[rsp+74]
       mov       [rsp+20],r14d
       mov       rcx,[r15+10]
       mov       edx,eax
       mov       r8d,r13d
       mov       r9d,r12d
       cmp       [rcx],ecx
       call      qword ptr [0E760]; Tedd.Voxtree.HotOctreeChunk.get_Item(Int32, Int32, Int32, Int32)
       mov       r10d,eax
       jmp       near ptr 0000000000009F48
M00_L11:
       mov       eax,[rsp+74]
       jmp       near ptr 000000000000A17E
M00_L12:
       mov       r10,[rsp+38]
       mov       r8,[r10+18]
       mov       r9d,ecx
       test      r8,r8
       je        near ptr 000000000000A32A
       cmp       [r8+8],r9d
       jb        near ptr 000000000000A32A
       lea       rcx,[r8+10]
       mov       r8d,r9d
       call      qword ptr [4E28]; Precode of System.SpanHelpers.NonPackedIndexOfValueType[[System.Int32, System.Private.CoreLib],[System.SpanHelpers+DontNegate`1[[System.Int32, System.Private.CoreLib]], System.Private.CoreLib]](Int32 ByRef, Int32, Int32)
       mov       r9d,eax
       jmp       near ptr 0000000000009EE3
M00_L13:
       mov       r9d,ecx
       cmp       [r8+8],r9d
       jb        near ptr 000000000000A32A
       lea       rcx,[r8+10]
       movzx     edx,dx
       movsx     rdx,dx
       movzx     r8d,dx
       dec       r8d
       cmp       r8d,0FE
       jae       short 000000000000A169
       mov       r8d,r9d
       call      qword ptr [0C378]; System.PackedSpanHelpers.IndexOf[[System.SpanHelpers+DontNegate`1[[System.Int16, System.Private.CoreLib]], System.Private.CoreLib],[System.PackedSpanHelpers+NopTransform, System.Private.CoreLib]](Int16 ByRef, Int16, Int32)
       mov       r9d,eax
       jmp       short 000000000000A175
M00_L14:
       mov       r8d,r9d
       call      qword ptr [6220]
       mov       r9d,eax
M00_L15:
       jmp       near ptr 0000000000009EE3
M00_L16:
       mov       eax,[rsp+74]
M00_L17:
       mov       rcx,[r15+8]
       lea       rdx,[rsp+58]
       mov       r8d,eax
       cmp       [rcx],ecx
       call      qword ptr [0D9C8]; Tedd.Voxtree.OctreeChunk.GetChannel(Int32)
       xor       ecx,ecx
       mov       [rsp+50],ecx
       mov       edx,[rsp+68]
       cmp       dword ptr [rsp+60],0
       jne       short 000000000000A1B1
       call      qword ptr [0E7F0]; Precode of Tedd.Voxtree.OctreeThrowHelper.ThrowInvalidView()
       mov       r10d,eax
       jmp       near ptr 000000000000A271
M00_L18:
       mov       ecx,1
       shlx      ecx,ecx,edx
       cmp       r13d,ecx
       jb        short 000000000000A1DB
       mov       edx,r13d
       mov       rcx,1F7003D2B18
       call      qword ptr [0E808]; Precode of Tedd.Voxtree.OctreeThrowHelper.ThrowCoordinate(System.String, Int32)
       mov       r10d,eax
       jmp       near ptr 000000000000A271
M00_L19:
       mov       ecx,1
       shlx      ecx,ecx,edx
       cmp       r12d,ecx
       jb        short 000000000000A202
       mov       edx,r12d
       mov       rcx,1F7003E22F8
       call      qword ptr [0E808]; Precode of Tedd.Voxtree.OctreeThrowHelper.ThrowCoordinate(System.String, Int32)
       mov       r10d,eax
       jmp       short 000000000000A271
M00_L20:
       mov       ecx,1
       shlx      ecx,ecx,edx
       cmp       r14d,ecx
       jb        short 000000000000A229
       mov       edx,r14d
       mov       rcx,1F7003E2310
       call      qword ptr [0E808]; Precode of Tedd.Voxtree.OctreeThrowHelper.ThrowCoordinate(System.String, Int32)
       mov       r10d,eax
       jmp       short 000000000000A271
M00_L21:
       vmovdqu   xmm0,xmmword ptr [rsp+58]
       vmovdqu   xmmword ptr [rsp+40],xmm0
       mov       [rsp+20],r12d
       mov       [rsp+28],r14d
       lea       rcx,[rsp+50]
       mov       [rsp+30],rcx
       lea       rcx,[rsp+40]
       movzx     r8d,byte ptr [rsp+6C]
       mov       r9d,r13d
       call      qword ptr [0E820]; Tedd.Voxtree.OctreeCodec.TryGetUnchecked(System.ReadOnlySpan`1<Byte>, Int32, Tedd.Voxtree.StorageKind, Int32, Int32, Int32, UInt32 ByRef)
       test      eax,eax
       jne       short 000000000000A26C
       call      qword ptr [0E838]; Precode of Tedd.Voxtree.OctreeThrowHelper.ThrowMalformed()
       mov       r10d,eax
       jmp       short 000000000000A271
M00_L22:
       mov       r10d,[rsp+50]
M00_L23:
       jmp       near ptr 0000000000009F48
M00_L24:
       mov       rcx,offset MT_System.ObjectDisposedException
       call      0000000000005240
       mov       rbx,rax
       mov       ecx,3F5
       mov       rdx,7FF83A864600
       call      qword ptr [7270]; Precode of System.String.StrCns(UInt32, IntPtr)
       mov       rdx,rax
       mov       rcx,rbx
       call      qword ptr [7BD0]; Precode of System.ObjectDisposedException..ctor(System.String)
       mov       rcx,rbx
       call      000000000000B8A0
       int       3
M00_L25:
       mov       rcx,offset MT_System.ArgumentOutOfRangeException
       call      0000000000005240
       mov       rbx,rax
       mov       ecx,3E1
       mov       rdx,7FF83A864600
       call      qword ptr [7270]; Precode of System.String.StrCns(UInt32, IntPtr)
       mov       rdx,rax
       mov       rcx,rbx
       call      qword ptr [0D1E8]; Precode of System.ArgumentOutOfRangeException..ctor(System.String)
       mov       rcx,rbx
       call      000000000000B8A0
       int       3
M00_L26:
       mov       rcx,offset MT_System.ArgumentOutOfRangeException
       call      0000000000005240
       mov       rbx,rax
       mov       ecx,3F1
       mov       rdx,7FF83A864600
       call      qword ptr [7270]; Precode of System.String.StrCns(UInt32, IntPtr)
       mov       rdx,rax
       mov       rcx,rbx
       call      qword ptr [0D1E8]; Precode of System.ArgumentOutOfRangeException..ctor(System.String)
       mov       rcx,rbx
       call      000000000000B8A0
       int       3
M00_L27:
       call      qword ptr [7C18]; Precode of System.ThrowHelper.ThrowArgumentOutOfRangeException()
       int       3
M00_L28:
       call      0000000000001788
       int       3
M00_L29:
       call      0000000000001770
       int       3
; Total bytes of code 1181
```
```assembly
; Tedd.Voxtree.HotOctreeChunk.get_Item(Int32, Int32, Int32, Int32)
       push      rbp
       sub       rsp,40
       lea       rbp,[rsp+40]
       xor       eax,eax
       mov       [rbp+0FFF0],rax
       mov       [rbp+0FFF8],rax
       mov       [rbp+10],rcx
       mov       [rbp+18],edx
       mov       [rbp+20],r8d
       mov       [rbp+28],r9d
       lea       rdx,[rbp+0FFF0]
       mov       rcx,[rbp+10]
       mov       r8d,[rbp+18]
       call      qword ptr [0E538]; Tedd.Voxtree.HotOctreeChunk.GetChannelSpan(Int32)
       mov       rcx,[rbp+10]
       call      qword ptr [0E550]; Tedd.Voxtree.HotOctreeChunk.get_Levels()
       mov       [rbp+0FFE8],eax
       mov       dword ptr [rsp+20],1
       mov       r9d,[rbp+0FFE8]
       mov       edx,[rbp+28]
       mov       r8d,[rbp+30]
       mov       ecx,[rbp+20]
       call      qword ptr [0E568]; Tedd.Voxtree.DenseVoxel.GetIndex(Int32, Int32, Int32, Int32, Tedd.Voxtree.DenseVoxelLayout)
       mov       [rbp+0FFEC],eax
       mov       eax,[rbp+0FFF8]
       cmp       [rbp+0FFEC],eax
       jae       short 0000000000007099
       mov       eax,[rbp+0FFEC]
       mov       rcx,[rbp+0FFF0]
       mov       eax,[rcx+rax*4]
       add       rsp,40
       pop       rbp
       ret
M01_L00:
       call      0000000000001788
       int       3
; Total bytes of code 127
```
```assembly
; System.SpanHelpers.NonPackedIndexOfValueType[[System.Int32, System.Private.CoreLib],[System.SpanHelpers+DontNegate`1[[System.Int32, System.Private.CoreLib]], System.Private.CoreLib]](Int32 ByRef, Int32, Int32)
       cmp       r8d,4
       jl        near ptr 0000000000000E5A
       movd      xmm0,edx
       pshufd    xmm0,xmm0,0
       mov       rdx,rcx
       lea       eax,[r8+0FFFC]
       cdqe
       shl       rax,2
       lea       r10,[rdx+rax]
       movups    xmm1,[rcx]
       pcmpeqd   xmm1,xmm0
       ptest     xmm1,xmm1
       je        short 0000000000000E13
M02_L00:
       movmskps  eax,xmm1
       bsf       r8d,eax
       mov       r10d,20
       test      eax,eax
       cmove     r8d,r10d
       mov       rax,rdx
       sub       rax,rcx
       shr       rax,2
       add       eax,r8d
M02_L01:
       ret
M02_L02:
       add       rdx,10
       cmp       rdx,r10
       jbe       near ptr 0000000000000F43
       mov       ecx,r8d
       test      cl,3
       je        near ptr 0000000000000F5A
       movups    xmm1,[r10]
       pcmpeqd   xmm1,xmm0
       ptest     xmm1,xmm1
       je        near ptr 0000000000000F5A
       movmskps  edx,xmm1
       bsf       r8d,edx
       mov       ecx,20
       test      edx,edx
       cmove     r8d,ecx
       shr       rax,2
       add       eax,r8d
       jmp       short 0000000000000E12
M02_L03:
       xor       r10d,r10d
       cmp       r8d,8
       jge       short 0000000000000E8D
M02_L04:
       cmp       r8d,4
       jge       short 0000000000000EDC
M02_L05:
       test      r8d,r8d
       jle       near ptr 0000000000000F5A
M02_L06:
       dec       r8d
       cmp       [rcx+r10*4],edx
       je        short 0000000000000E88
       inc       r10
       test      r8d,r8d
       jg        short 0000000000000E72
       jmp       near ptr 0000000000000F5A
M02_L07:
       mov       eax,r10d
       jmp       short 0000000000000E12
M02_L08:
       add       r8d,0FFFFFFF8
       cmp       [rcx+r10*4],edx
       je        short 0000000000000E88
       cmp       [rcx+r10*4+4],edx
       je        near ptr 0000000000000F3A
       cmp       [rcx+r10*4+8],edx
       je        near ptr 0000000000000F31
       cmp       [rcx+r10*4+0C],edx
       je        short 0000000000000F28
       cmp       [rcx+r10*4+10],edx
       je        short 0000000000000F1F
       cmp       [rcx+r10*4+14],edx
       je        short 0000000000000F16
       cmp       [rcx+r10*4+18],edx
       je        short 0000000000000F0D
       cmp       [rcx+r10*4+1C],edx
       je        short 0000000000000F04
       add       r10,8
       cmp       r8d,8
       jge       short 0000000000000E8D
       jmp       short 0000000000000E63
M02_L09:
       add       r8d,0FFFFFFFC
       cmp       [rcx+r10*4],edx
       je        short 0000000000000E88
       cmp       [rcx+r10*4+4],edx
       je        short 0000000000000F3A
       cmp       [rcx+r10*4+8],edx
       je        short 0000000000000F31
       cmp       [rcx+r10*4+0C],edx
       je        short 0000000000000F28
       add       r10,4
       jmp       near ptr 0000000000000E69
M02_L10:
       lea       eax,[r10+7]
       jmp       near ptr 0000000000000E12
M02_L11:
       lea       eax,[r10+6]
       jmp       near ptr 0000000000000E12
M02_L12:
       lea       eax,[r10+5]
       jmp       near ptr 0000000000000E12
M02_L13:
       lea       eax,[r10+4]
       jmp       near ptr 0000000000000E12
M02_L14:
       lea       eax,[r10+3]
       jmp       near ptr 0000000000000E12
M02_L15:
       lea       eax,[r10+2]
       jmp       near ptr 0000000000000E12
M02_L16:
       lea       eax,[r10+1]
       jmp       near ptr 0000000000000E12
M02_L17:
       movups    xmm1,[rdx]
       pcmpeqd   xmm1,xmm0
       ptest     xmm1,xmm1
       jne       near ptr 0000000000000DF2
       jmp       near ptr 0000000000000E13
M02_L18:
       mov       eax,0FFFFFFFF
       ret
; Total bytes of code 416
```
```assembly
; System.PackedSpanHelpers.IndexOf[[System.SpanHelpers+DontNegate`1[[System.Int16, System.Private.CoreLib]], System.Private.CoreLib],[System.PackedSpanHelpers+NopTransform, System.Private.CoreLib]](Int16 ByRef, Int16, Int32)
       push      r14
       push      rdi
       push      rsi
       push      rbp
       push      rbx
       sub       rsp,50
       vmovaps   [rsp+40],xmm6
       vmovaps   [rsp+30],xmm7
       vmovaps   [rsp+20],xmm8
       mov       rsi,rcx
       mov       edi,edx
       mov       ebx,r8d
       cmp       ebx,8
       jl        near ptr 000000000000D4FC
       mov       rbp,rsi
       cmp       ebx,10
       jle       near ptr 000000000000D479
       vmovd     xmm6,edi
       vpbroadcastb ymm6,xmm6
       cmp       ebx,20
       jle       near ptr 000000000000D3B4
       lea       ecx,[rbx+0FFE0]
       movsxd    rcx,ecx
       lea       rdi,[rbp+rcx*2]
       vmovups   ymm0,[rsi]
       vpackuswb ymm0,ymm0,[rsi+20]
       vpcmpeqb  ymm7,ymm0,ymm6
       vptest    ymm7,ymm7
       jne       short 000000000000D363
M03_L00:
       add       rbp,40
       cmp       rbp,rdi
       jae       short 000000000000D399
       mov       rcx,7FF83A4B8EB0
       vextractf128 xmm8,ymm6,1
       call      0000000000008420
       vmovups   ymm0,[rbp]
       vpackuswb ymm0,ymm0,[rbp+20]
       vinsertf128 ymm6,ymm6,xmm8,1
       vpcmpeqb  ymm7,ymm0,ymm6
       vptest    ymm7,ymm7
       je        short 000000000000D32A
M03_L01:
       mov       rcx,7FF83A4B8EA4
       vextractf128 xmm8,ymm7,1
       call      0000000000008420
       mov       rax,rbp
       sub       rax,rsi
       shr       rax,1
       vinsertf128 ymm7,ymm7,xmm8,1
       vpermq    ymm0,ymm7,0D8
       vpmovmskb ecx,ymm0
       tzcnt     ecx,ecx
       add       eax,ecx
       jmp       short 000000000000D3FC
M03_L02:
       mov       rcx,7FF83A4B8EAC
       vextractf128 xmm8,ymm6,1
       call      0000000000008420
       vinsertf128 ymm6,ymm6,xmm8,1
M03_L03:
       add       ebx,0FFFFFFF0
       movsxd    rcx,ebx
       lea       rbx,[rsi+rcx*2]
       cmp       rbp,rbx
       ja        short 000000000000D41C
       mov       rdi,rbp
M03_L04:
       vmovups   ymm0,[rdi]
       vpackuswb ymm0,ymm0,[rbx]
       vpcmpeqb  ymm6,ymm0,ymm6
       vptest    ymm6,ymm6
       jne       short 000000000000D43C
       mov       rcx,7FF83A4B8EBC
       call      0000000000008420
M03_L05:
       mov       rcx,7FF83A4B8ECC
       call      0000000000008420
       mov       eax,0FFFFFFFF
M03_L06:
       vzeroupper
       vmovaps   xmm6,[rsp+40]
       vmovaps   xmm7,[rsp+30]
       vmovaps   xmm8,[rsp+20]
       add       rsp,50
       pop       rbx
       pop       rbp
       pop       rsi
       pop       rdi
       pop       r14
       ret
M03_L07:
       mov       rcx,7FF83A4B8EB4
       vextractf128 xmm8,ymm6,1
       call      0000000000008420
       mov       rdi,rbx
       vinsertf128 ymm6,ymm6,xmm8,1
       jmp       short 000000000000D3C6
M03_L08:
       mov       rcx,7FF83A4B8EB8
       vextractf128 xmm7,ymm6,1
       call      0000000000008420
       vinsertf128 ymm6,ymm6,xmm7,1
       vpermq    ymm0,ymm6,0D8
       vpmovmskb ecx,ymm0
       tzcnt     ecx,ecx
       cmp       ecx,10
       jge       near ptr 000000000000D650
M03_L09:
       sub       rdi,rsi
       shr       rdi,1
       lea       eax,[rdi+rcx]
       jmp       short 000000000000D3FC
M03_L10:
       mov       rcx,7FF83A4B8EA8
       call      0000000000008420
       vmovd     xmm6,edi
       vpbroadcastb xmm6,xmm6
       lea       ecx,[rbx+0FFF8]
       movsxd    rcx,ecx
       lea       rbx,[rsi+rcx*2]
       cmp       rsi,rbx
       ja        near ptr 000000000000D65B
       mov       rdi,rsi
M03_L11:
       vmovups   xmm0,[rdi]
       vpackuswb xmm0,xmm0,[rbx]
       vpcmpeqb  xmm6,xmm0,xmm6
       vptest    xmm6,xmm6
       jne       short 000000000000D4CE
       mov       rcx,7FF83A4B8EC8
       call      0000000000008420
       jmp       near ptr 000000000000D3E8
M03_L12:
       mov       rcx,7FF83A4B8EC4
       call      0000000000008420
       vpmovmskb ecx,xmm6
       tzcnt     ecx,ecx
       cmp       ecx,8
       jge       near ptr 000000000000D672
M03_L13:
       sub       rdi,rsi
       shr       rdi,1
       lea       eax,[rdi+rcx]
       jmp       near ptr 000000000000D3FC
M03_L14:
       xor       ebp,ebp
       cmp       ebx,4
       jl        short 000000000000D555
       add       ebx,0FFFFFFFC
       movsx     rcx,word ptr [rsi]
       movsx     r14,di
       cmp       ecx,r14d
       je        near ptr 000000000000D59E
       movsx     rcx,word ptr [rsi+2]
       cmp       ecx,r14d
       je        near ptr 000000000000D5CF
       movsx     rcx,word ptr [rsi+4]
       cmp       ecx,r14d
       je        near ptr 000000000000D603
       movsx     rcx,word ptr [rsi+6]
       cmp       ecx,r14d
       je        near ptr 000000000000D637
       mov       rcx,7FF83A4B8E98
       call      0000000000008420
       mov       ebp,4
M03_L15:
       test      ebx,ebx
       jle       near ptr 000000000000D3E8
       movsx     r14,di
M03_L16:
       dec       ebx
       movsx     rcx,word ptr [rsi+rbp*2]
       cmp       ecx,r14d
       je        short 000000000000D588
       mov       rcx,7FF83A4B8EA0
       call      0000000000008420
       inc       rbp
       test      ebx,ebx
       jg        short 000000000000D561
       jmp       near ptr 000000000000D3E8
M03_L17:
       mov       rcx,7FF83A4B8E9C
       call      0000000000008420
       mov       eax,ebp
       jmp       near ptr 000000000000D3FC
M03_L18:
       mov       rcx,7FF83A4B8E88
       call      0000000000008420
       xor       eax,eax
       vzeroupper
       vmovaps   xmm6,[rsp+40]
       vmovaps   xmm7,[rsp+30]
       vmovaps   xmm8,[rsp+20]
       add       rsp,50
       pop       rbx
       pop       rbp
       pop       rsi
       pop       rdi
       pop       r14
       ret
M03_L19:
       mov       rcx,7FF83A4B8E8C
       call      0000000000008420
       mov       eax,1
       vzeroupper
       vmovaps   xmm6,[rsp+40]
       vmovaps   xmm7,[rsp+30]
       vmovaps   xmm8,[rsp+20]
       add       rsp,50
       pop       rbx
       pop       rbp
       pop       rsi
       pop       rdi
       pop       r14
       ret
M03_L20:
       mov       rcx,7FF83A4B8E90
       call      0000000000008420
       mov       eax,2
       vzeroupper
       vmovaps   xmm6,[rsp+40]
       vmovaps   xmm7,[rsp+30]
       vmovaps   xmm8,[rsp+20]
       add       rsp,50
       pop       rbx
       pop       rbp
       pop       rsi
       pop       rdi
       pop       r14
       ret
M03_L21:
       mov       rcx,7FF83A4B8E94
       call      0000000000008420
       mov       eax,3
       jmp       near ptr 000000000000D3FC
M03_L22:
       mov       rdi,rbx
       add       ecx,0FFFFFFF0
       jmp       near ptr 000000000000D46E
M03_L23:
       mov       rcx,7FF83A4B8EC0
       call      0000000000008420
       mov       rdi,rbx
       jmp       near ptr 000000000000D4A7
M03_L24:
       mov       rdi,rbx
       add       ecx,0FFFFFFF8
       jmp       near ptr 000000000000D4EE
; Total bytes of code 957
```
```assembly
; Tedd.Voxtree.OctreeChunk.GetChannel(Int32)
       push      rbp
       sub       rsp,70
       lea       rbp,[rsp+70]
       xor       eax,eax
       mov       [rbp+0FFB8],rax
       vxorps    xmm4,xmm4,xmm4
       vmovdqu   ymmword ptr [rbp+0FFC0],ymm4
       vmovdqu   ymmword ptr [rbp+0FFE0],ymm4
       mov       [rbp+10],rcx
       mov       [rbp+18],rdx
       mov       [rbp+20],r8d
       lea       rdx,[rbp+0FFE0]
       mov       rcx,[rbp+10]
       mov       r8d,[rbp+20]
       call      qword ptr [0DA28]; Tedd.Voxtree.OctreeChunk.GetChannelData(Int32)
       lea       rdx,[rbp+0FFF0]
       lea       rcx,[rbp+0FFE0]
       call      qword ptr [0D9F8]; System.ReadOnlyMemory`1[[System.Byte, System.Private.CoreLib]].get_Span()
       mov       rcx,[rbp+10]
       call      qword ptr [0D920]; Tedd.Voxtree.OctreeChunk.get_Levels()
       mov       [rbp+0FFDC],eax
       vmovdqu   xmm0,xmmword ptr [rbp+0FFF0]
       vmovdqu   xmmword ptr [rbp+0FFC8],xmm0
       vmovdqu   xmm0,xmmword ptr [rbp+0FFF0]
       vmovdqu   xmmword ptr [rbp+0FFB8],xmm0
       lea       rcx,[rbp+0FFB8]
       call      qword ptr [0D7B8]; Tedd.Voxtree.OctreeCodec.GetStorageKindUnchecked(System.ReadOnlySpan`1<Byte>)
       mov       [rbp+0FFB4],eax
       mov       r9d,[rbp+0FFB4]
       lea       rdx,[rbp+0FFC8]
       mov       r8d,[rbp+0FFDC]
       mov       rcx,[rbp+18]
       call      qword ptr [0DA40]; Tedd.Voxtree.OctreeSpan.CreateTrusted(System.ReadOnlySpan`1<Byte>, Int32, Tedd.Voxtree.StorageKind)
       mov       rax,[rbp+18]
       add       rsp,70
       pop       rbp
       ret
; Total bytes of code 152
```
```assembly
; Tedd.Voxtree.OctreeCodec.TryGetUnchecked(System.ReadOnlySpan`1<Byte>, Int32, Tedd.Voxtree.StorageKind, Int32, Int32, Int32, UInt32 ByRef)
       push      rbp
       sub       rsp,130
       lea       rbp,[rsp+130]
       vxorps    xmm4,xmm4,xmm4
       vmovdqa   xmmword ptr [rbp+0FEF0],xmm4
       mov       rax,0FFFFFFFFFF40
M05_L00:
       vmovdqa   xmmword ptr [rbp+rax+0FFC0],xmm4
       vmovdqa   xmmword ptr [rbp+rax+0FFD0],xmm4
       vmovdqa   xmmword ptr [rbp+rax+0FFE0],xmm4
       add       rax,30
       jne       short 0000000000007B16
       mov       [rbp+0FFC0],rax
       mov       [rbp+10],rcx
       mov       [rbp+18],edx
       mov       [rbp+20],r8d
       mov       [rbp+28],r9d
       mov       dword ptr [rbp+0FF38],3E8
       mov       rax,[rbp+40]
       xor       ecx,ecx
       mov       [rax],ecx
       mov       eax,1
       mov       ecx,[rbp+18]
       shlx      eax,eax,ecx
       mov       [rbp+0FFC4],eax
       movzx     eax,byte ptr [rbp+20]
       cmp       eax,1
       jne       short 0000000000007BDA
       mov       dword ptr [rbp+0FFA0],2
       mov       rax,[rbp+10]
       vmovdqu   xmm0,xmmword ptr [rax]
       vmovdqu   xmmword ptr [rbp+0FF20],xmm0
       lea       rcx,[rbp+0FF20]
       lea       rdx,[rbp+0FFA0]
       mov       r8,[rbp+40]
       call      qword ptr [0D5D8]; Tedd.Voxtree.OctreeCodec.TryReadVarUInt(System.ReadOnlySpan`1<Byte>, Int32 ByRef, UInt32 ByRef)
       test      eax,eax
       je        short 0000000000007BC6
       mov       rcx,7FF83A886138
       call      0000000000008420
       mov       eax,[rbp+0FFA0]
       mov       rcx,[rbp+10]
       cmp       eax,[rcx+8]
       sete      al
       movzx     eax,al
       mov       [rbp+0FF34],eax
       jmp       near ptr 0000000000007FE2
M05_L01:
       mov       rcx,7FF83A88613C
       call      0000000000008420
       jmp       near ptr 0000000000007FD7
M05_L02:
       movzx     eax,byte ptr [rbp+20]
       cmp       eax,2
       jne       short 0000000000007C5C
       mov       rcx,7FF83A886140
       call      0000000000008420
       mov       eax,[rbp+28]
       imul      eax,[rbp+0FFC4]
       imul      eax,[rbp+0FFC4]
       mov       ecx,[rbp+30]
       imul      ecx,[rbp+0FFC4]
       add       eax,ecx
       add       eax,[rbp+38]
       mov       [rbp+0FF9C],eax
       mov       eax,[rbp+0FF9C]
       lea       eax,[rax*4+2]
       mov       [rbp+0FF98],eax
       lea       rdx,[rbp+0FF40]
       mov       rcx,[rbp+10]
       mov       r8d,[rbp+0FF98]
       mov       r9d,4
       call      qword ptr [6238]; System.ReadOnlySpan`1[[System.Byte, System.Private.CoreLib]].Slice(Int32, Int32)
       vmovdqu   xmm0,xmmword ptr [rbp+0FF40]
       vmovdqu   xmmword ptr [rbp+0FF10],xmm0
       lea       rcx,[rbp+0FF10]
       call      qword ptr [0E850]; Precode of System.Buffers.Binary.BinaryPrimitives.ReadUInt32LittleEndian(System.ReadOnlySpan`1<Byte>)
       mov       rcx,[rbp+40]
       mov       [rcx],eax
       jmp       near ptr 0000000000007F17
M05_L03:
       cmp       dword ptr [rbp+18],0
       je        short 0000000000007C7B
       mov       rax,[rbp+10]
       cmp       dword ptr [rax+8],0C
       jge       short 0000000000007C8F
       mov       rcx,7FF83A886144
       call      0000000000008420
M05_L04:
       mov       rcx,7FF83A886148
       call      0000000000008420
       jmp       near ptr 0000000000007FD7
M05_L05:
       mov       rax,[rbp+10]
       mov       [rbp+0FF90],rax
       lea       rdx,[rbp+0FFB0]
       mov       rax,[rbp+0FF90]
       mov       eax,[rax+8]
       lea       r9d,[rax+0FFFF]
       mov       rcx,[rbp+0FF90]
       xor       r8d,r8d
       call      qword ptr [6238]; System.ReadOnlySpan`1[[System.Byte, System.Private.CoreLib]].Slice(Int32, Int32)
       mov       rax,[rbp+10]
       mov       eax,[rax+8]
       dec       eax
       mov       [rbp+0FF54],eax
       mov       rax,[rbp+10]
       mov       eax,[rax+8]
       cmp       [rbp+0FF54],eax
       jae       near ptr 0000000000007FF2
       mov       rax,[rbp+10]
       mov       rax,[rax]
       mov       ecx,[rbp+0FF54]
       movzx     eax,byte ptr [rax+rcx]
       mov       [rbp+0FFAC],eax
       mov       eax,[rbp+0FFB8]
       sub       eax,[rbp+0FFAC]
       mov       [rbp+0FFA8],eax
       cmp       dword ptr [rbp+0FFAC],9
       jl        short 0000000000007D0D
       cmp       dword ptr [rbp+0FFAC],29
       jle       short 0000000000007D16
       mov       rcx,7FF83A88614C
       call      0000000000008420
M05_L06:
       mov       dword ptr [rbp+0FF8C],1
       jmp       short 0000000000007D2A
M05_L07:
       mov       rcx,7FF83A886150
       call      0000000000008420
       xor       eax,eax
       mov       [rbp+0FF8C],eax
M05_L08:
       cmp       dword ptr [rbp+0FF8C],0
       jne       short 0000000000007D45
       cmp       dword ptr [rbp+0FFA8],2
       jge       short 0000000000007D59
       mov       rcx,7FF83A886154
       call      0000000000008420
M05_L09:
       mov       rcx,7FF83A886158
       call      0000000000008420
       jmp       near ptr 0000000000007FD7
M05_L10:
       mov       eax,[rbp+18]
       dec       eax
       mov       [rbp+0FF88],eax
       jmp       near ptr 0000000000007F96
M05_L11:
       mov       eax,[rbp+0FFA8]
       mov       [rbp+0FF84],eax
       mov       eax,[rbp+0FF84]
       cmp       eax,[rbp+0FFB8]
       jb        short 0000000000007D88
       mov       rcx,7FF83A88615C
       call      0000000000008420
       jmp       near ptr 0000000000007FD7
M05_L12:
       mov       eax,[rbp+0FF84]
       mov       [rbp+0FF78],eax
       mov       eax,[rbp+0FF78]
       mov       [rbp+0FF50],eax
       mov       eax,[rbp+0FF78]
       inc       eax
       mov       [rbp+0FF78],eax
       mov       eax,[rbp+0FFB8]
       cmp       [rbp+0FF50],eax
       jae       near ptr 0000000000007FF2
       mov       eax,[rbp+0FF50]
       mov       rcx,[rbp+0FFB0]
       movzx     eax,byte ptr [rcx+rax]
       mov       [rbp+0FF74],eax
       mov       eax,[rbp+0FF88]
       sarx      eax,[rbp+28],eax
       and       eax,1
       shl       eax,2
       mov       ecx,[rbp+0FF88]
       sarx      ecx,[rbp+30],ecx
       and       ecx,1
       add       ecx,ecx
       or        eax,ecx
       mov       ecx,[rbp+0FF88]
       sarx      ecx,[rbp+38],ecx
       and       ecx,1
       or        eax,ecx
       mov       [rbp+0FF70],eax
       xor       eax,eax
       mov       [rbp+0FF64],eax
       jmp       short 0000000000007E68
M05_L13:
       vmovdqu   xmm0,xmmword ptr [rbp+0FFB0]
       vmovdqu   xmmword ptr [rbp+0FF00],xmm0
       lea       rcx,[rbp+0FF00]
       lea       r8,[rbp+0FF58]
       lea       rdx,[rbp+0FF78]
       call      qword ptr [0D5D8]; Tedd.Voxtree.OctreeCodec.TryReadVarUInt(System.ReadOnlySpan`1<Byte>, Int32 ByRef, UInt32 ByRef)
       test      eax,eax
       jne       short 0000000000007E4B
       mov       rcx,7FF83A886160
       call      0000000000008420
       jmp       near ptr 0000000000007FD7
M05_L14:
       mov       rcx,7FF83A886164
       call      0000000000008420
       mov       eax,[rbp+0FF64]
       inc       eax
       mov       [rbp+0FF64],eax
M05_L15:
       mov       eax,[rbp+0FF38]
       dec       eax
       mov       [rbp+0FF38],eax
       cmp       dword ptr [rbp+0FF38],0
       jg        short 0000000000007E90
       lea       rcx,[rbp+0FF38]
       mov       edx,125
       call      0000000000003990
M05_L16:
       mov       eax,[rbp+0FF64]
       cmp       eax,[rbp+0FF70]
       jl        near ptr 0000000000007E0B
       vmovdqu   xmm0,xmmword ptr [rbp+0FFB0]
       vmovdqu   xmmword ptr [rbp+0FEF0],xmm0
       lea       rcx,[rbp+0FEF0]
       lea       r8,[rbp+0FF68]
       lea       rdx,[rbp+0FF78]
       call      qword ptr [0D5D8]; Tedd.Voxtree.OctreeCodec.TryReadVarUInt(System.ReadOnlySpan`1<Byte>, Int32 ByRef, UInt32 ByRef)
       test      eax,eax
       jne       short 0000000000007EE2
       mov       rcx,7FF83A886168
       call      0000000000008420
       jmp       near ptr 0000000000007FD7
M05_L17:
       mov       eax,1
       mov       ecx,[rbp+0FF70]
       shlx      eax,eax,ecx
       and       eax,[rbp+0FF74]
       test      eax,eax
       je        short 0000000000007F25
       mov       rcx,7FF83A88616C
       call      0000000000008420
       mov       rax,[rbp+40]
       mov       ecx,[rbp+0FF68]
       mov       [rax],ecx
M05_L18:
       mov       eax,1
       add       rsp,130
       pop       rbp
       ret
M05_L19:
       cmp       dword ptr [rbp+0FF88],0
       je        short 0000000000007F51
       cmp       dword ptr [rbp+0FF68],0
       je        short 0000000000007F62
       mov       eax,[rbp+0FF84]
       add       eax,0FFFFFFFE
       cmp       [rbp+0FF68],eax
       jbe       short 0000000000007F73
       mov       rcx,7FF83A886170
       call      0000000000008420
M05_L20:
       mov       rcx,7FF83A886174
       call      0000000000008420
       jmp       short 0000000000007FD7
M05_L21:
       mov       rcx,7FF83A886178
       call      0000000000008420
       jmp       short 0000000000007F51
M05_L22:
       mov       rcx,7FF83A88617C
       call      0000000000008420
       mov       eax,[rbp+0FF84]
       sub       eax,[rbp+0FF68]
       mov       [rbp+0FFA8],eax
       mov       eax,[rbp+0FF88]
       dec       eax
       mov       [rbp+0FF88],eax
M05_L23:
       mov       eax,[rbp+0FF38]
       dec       eax
       mov       [rbp+0FF38],eax
       cmp       dword ptr [rbp+0FF38],0
       jg        short 0000000000007FBE
       lea       rcx,[rbp+0FF38]
       mov       edx,16A
       call      0000000000003990
M05_L24:
       cmp       dword ptr [rbp+0FF88],0
       jge       near ptr 0000000000007D66
       mov       rcx,7FF83A886180
       call      0000000000008420
M05_L25:
       xor       eax,eax
       add       rsp,130
       pop       rbp
       ret
M05_L26:
       movzx     eax,byte ptr [rbp+0FF34]
       add       rsp,130
       pop       rbp
       ret
M05_L27:
       call      0000000000001788
       int       3
; Total bytes of code 1288
```
```assembly
; Tedd.Voxtree.HotOctreeChunk.GetChannelSpan(Int32)
       push      rbp
       sub       rsp,50
       lea       rbp,[rsp+50]
       xor       eax,eax
       mov       [rbp+0FFD8],rax
       vxorps    xmm4,xmm4,xmm4
       vmovdqu   ymmword ptr [rbp+0FFE0],ymm4
       mov       [rbp+10],rcx
       mov       [rbp+18],rdx
       mov       [rbp+20],r8d
       mov       rcx,[rbp+10]
       call      qword ptr [0E598]; Tedd.Voxtree.HotOctreeChunk.GetValues()
       mov       [rbp+0FFF0],rax
       mov       rax,[rbp+0FFF0]
       mov       [rbp+0FFE8],rax
       mov       rcx,[rbp+10]
       call      qword ptr [0E5B0]; Tedd.Voxtree.HotOctreeChunk.get_ChannelCount()
       cmp       eax,[rbp+20]
       ja        short 000000000000685E
       mov       rcx,offset MT_System.ArgumentOutOfRangeException
       call      0000000000005240
       mov       [rbp+0FFE0],rax
       mov       ecx,3E1
       mov       rdx,7FF83A864600
       call      qword ptr [7270]; Precode of System.String.StrCns(UInt32, IntPtr)
       mov       [rbp+0FFD8],rax
       mov       rdx,[rbp+0FFD8]
       mov       rcx,[rbp+0FFE0]
       call      qword ptr [0D1E8]; Precode of System.ArgumentOutOfRangeException..ctor(System.String)
       mov       rcx,[rbp+0FFE0]
       call      000000000000B8A0
       int       3
M06_L00:
       mov       rcx,[rbp+10]
       call      qword ptr [0E550]; Tedd.Voxtree.HotOctreeChunk.get_Levels()
       mov       ecx,eax
       call      qword ptr [0D1B8]; Tedd.Voxtree.OctreeCodec.GetVoxelCount(Int32)
       mov       [rbp+0FFFC],eax
       mov       eax,[rbp+20]
       mov       r8d,eax
       imul      r8d,[rbp+0FFFC]
       mov       rcx,[rbp+18]
       mov       rdx,[rbp+0FFE8]
       mov       r9d,[rbp+0FFFC]
       call      qword ptr [0E580]; System.MemoryExtensions.AsSpan[[System.UInt32, System.Private.CoreLib]](UInt32[], Int32, Int32)
       mov       rax,[rbp+18]
       add       rsp,50
       pop       rbp
       ret
; Total bytes of code 202
```
```assembly
; Tedd.Voxtree.HotOctreeChunk.get_Levels()
       push      rbp
       mov       rbp,rsp
       mov       [rbp+10],rcx
       mov       rax,[rbp+10]
       mov       eax,[rax+20]
       pop       rbp
       ret
; Total bytes of code 17
```
```assembly
; Tedd.Voxtree.DenseVoxel.GetIndex(Int32, Int32, Int32, Int32, Tedd.Voxtree.DenseVoxelLayout)
       push      rbp
       sub       rsp,40
       lea       rbp,[rsp+40]
       vxorps    xmm4,xmm4,xmm4
       vmovdqu   xmmword ptr [rbp+0FFE8],xmm4
       xor       eax,eax
       mov       [rbp+0FFF8],rax
       mov       [rbp+10],ecx
       mov       [rbp+18],edx
       mov       [rbp+20],r8d
       mov       [rbp+28],r9d
       mov       ecx,[rbp+28]
       call      qword ptr [0D1A0]; Tedd.Voxtree.OctreeCodec.ValidateLevels(Int32)
       mov       ecx,[rbp+30]
       call      qword ptr [0D098]; Tedd.Voxtree.DenseVoxel.Validate(Tedd.Voxtree.DenseVoxelLayout)
       mov       eax,1
       mov       ecx,[rbp+28]
       shlx      eax,eax,ecx
       mov       [rbp+0FFFC],eax
       mov       eax,[rbp+10]
       cmp       eax,[rbp+0FFFC]
       jae       short 0000000000006A50
       mov       eax,[rbp+18]
       cmp       eax,[rbp+0FFFC]
       jae       short 0000000000006A94
       mov       eax,[rbp+20]
       cmp       eax,[rbp+0FFFC]
       jb        short 0000000000006AA5
       mov       rcx,7FF83A92EAC0
       call      0000000000008420
M08_L00:
       mov       rcx,offset MT_System.ArgumentOutOfRangeException
       call      0000000000005240
       mov       [rbp+0FFF0],rax
       mov       ecx,3F1
       mov       rdx,7FF83A864600
       call      qword ptr [7270]; Precode of System.String.StrCns(UInt32, IntPtr)
       mov       [rbp+0FFE8],rax
       mov       rdx,[rbp+0FFE8]
       mov       rcx,[rbp+0FFF0]
       call      qword ptr [0D1E8]; Precode of System.ArgumentOutOfRangeException..ctor(System.String)
       mov       rcx,[rbp+0FFF0]
       call      000000000000B8A0
       int       3
M08_L01:
       mov       rcx,7FF83A92EAC4
       call      0000000000008420
       jmp       short 0000000000006A50
M08_L02:
       mov       rcx,7FF83A92EAC8
       call      0000000000008420
       mov       eax,[rbp+30]
       mov       [rsp+20],eax
       mov       ecx,[rbp+10]
       mov       edx,[rbp+18]
       mov       r8d,[rbp+20]
       mov       r9d,[rbp+0FFFC]
       call      qword ptr [0E5C8]; Tedd.Voxtree.DenseVoxel.Index(Int32, Int32, Int32, Int32, Tedd.Voxtree.DenseVoxelLayout)
       nop
       add       rsp,40
       pop       rbp
       ret
; Total bytes of code 246
```
```assembly
; Tedd.Voxtree.OctreeChunk.GetChannelData(Int32)
       push      rbp
       sub       rsp,30
       lea       rbp,[rsp+30]
       xor       eax,eax
       mov       [rbp+0FFF8],rax
       mov       [rbp+0FFF0],rax
       mov       [rbp+10],rcx
       mov       [rbp+18],rdx
       mov       [rbp+20],r8d
       mov       rcx,[rbp+10]
       call      qword ptr [0D938]; Tedd.Voxtree.OctreeChunk.get_ChannelCount()
       cmp       eax,[rbp+20]
       ja        short 0000000000007843
       mov       rcx,offset MT_System.ArgumentOutOfRangeException
       call      0000000000005240
       mov       [rbp+0FFF8],rax
       mov       ecx,3E1
       mov       rdx,7FF83A864600
       call      qword ptr [7270]; Precode of System.String.StrCns(UInt32, IntPtr)
       mov       [rbp+0FFF0],rax
       mov       rdx,[rbp+0FFF0]
       mov       rcx,[rbp+0FFF8]
       call      qword ptr [0D1E8]; Precode of System.ArgumentOutOfRangeException..ctor(System.String)
       mov       rcx,[rbp+0FFF8]
       call      000000000000B8A0
       int       3
M09_L00:
       mov       rax,[rbp+10]
       mov       rax,[rax+8]
       mov       ecx,[rbp+20]
       cmp       ecx,[rax+8]
       jae       short 0000000000007874
       mov       edx,ecx
       imul      rdx,10
       lea       rax,[rax+rdx+10]
       mov       rcx,[rbp+18]
       vmovdqu   xmm0,xmmword ptr [rax]
       vmovdqu   xmmword ptr [rcx],xmm0
       mov       rax,[rbp+18]
       add       rsp,30
       pop       rbp
       ret
M09_L01:
       call      0000000000001788
       int       3
; Total bytes of code 170
```
```assembly
; System.ReadOnlyMemory`1[[System.Byte, System.Private.CoreLib]].get_Span()
       push      r14
       push      rdi
       push      rsi
       push      rbp
       push      rbx
       sub       rsp,30
       xor       eax,eax
       mov       [rsp+20],rax
       mov       rsi,rcx
       mov       rbx,rdx
       xor       edi,edi
       xor       ebp,ebp
       mov       r14,[rsi]
       test      r14,r14
       je        short 0000000000007485
       mov       rcx,[r14]
       test      dword ptr [rcx],80000000
       je        short 00000000000074A8
       lea       rdi,[r14+10]
       mov       ebp,[r14+8]
M10_L00:
       mov       ecx,[rsi+8]
       and       ecx,7FFFFFFF
       mov       r14d,ecx
       mov       esi,[rsi+0C]
       mov       ecx,esi
       add       rcx,r14
       mov       eax,ebp
       cmp       rcx,rax
       ja        short 00000000000074E9
       mov       rcx,7FF83A92EF2C
       call      0000000000008420
       add       rdi,r14
       mov       ebp,esi
M10_L01:
       mov       rcx,7FF83A92EF30
       call      0000000000008420
       mov       [rbx],rdi
       mov       [rbx+8],ebp
       mov       rax,rbx
       add       rsp,30
       pop       rbx
       pop       rbp
       pop       rsi
       pop       rdi
       pop       r14
       ret
M10_L02:
       mov       rcx,7FF83A92EE18
       call      0000000000008420
       mov       rcx,r14
       mov       rdx,7FF83A92EE20
       call      0000000000004AB0
       mov       rcx,r14
       lea       rdx,[rsp+20]
       mov       rax,[r14]
       mov       rax,[rax+40]
       call      qword ptr [rax+28]
       mov       ebp,[rsp+28]
       mov       rdi,[rsp+20]
       jmp       near ptr 0000000000007456
M10_L03:
       mov       rcx,7FF83A92EF28
       call      0000000000008420
       call      qword ptr [7C18]; Precode of System.ThrowHelper.ThrowArgumentOutOfRangeException()
       int       3
; Total bytes of code 223
```
```assembly
; Tedd.Voxtree.OctreeChunk.get_Levels()
       mov       eax,[rcx+10]
       ret
; Total bytes of code 4
```
```assembly
; Tedd.Voxtree.OctreeCodec.GetStorageKindUnchecked(System.ReadOnlySpan`1<Byte>)
       push      rbp
       sub       rsp,20
       lea       rbp,[rsp+20]
       mov       [rbp+10],rcx
       mov       rax,[rbp+10]
       cmp       dword ptr [rax+8],1
       jbe       short 00000000000073FC
       mov       rax,[rbp+10]
       mov       rax,[rax]
       movzx     eax,byte ptr [rax+1]
       and       eax,3
       add       rsp,20
       pop       rbp
       ret
M12_L00:
       call      0000000000001788
       int       3
; Total bytes of code 50
```
```assembly
; Tedd.Voxtree.OctreeSpan.CreateTrusted(System.ReadOnlySpan`1<Byte>, Int32, Tedd.Voxtree.StorageKind)
       push      rbp
       sub       rsp,50
       lea       rbp,[rsp+50]
       xor       eax,eax
       mov       [rbp+0FFD8],rax
       vxorps    xmm4,xmm4,xmm4
       vmovdqu   ymmword ptr [rbp+0FFE0],ymm4
       mov       [rbp+10],rcx
       mov       [rbp+18],rdx
       mov       [rbp+20],r8d
       mov       [rbp+28],r9d
       mov       rax,[rbp+18]
       vmovdqu   xmm0,xmmword ptr [rax]
       vmovdqu   xmmword ptr [rbp+0FFD8],xmm0
       lea       rdx,[rbp+0FFD8]
       movzx     r9d,byte ptr [rbp+28]
       lea       rcx,[rbp+0FFE8]
       mov       r8d,[rbp+20]
       call      qword ptr [0DA58]; Tedd.Voxtree.OctreeSpan..ctor(System.ReadOnlySpan`1<Byte>, Int32, Tedd.Voxtree.StorageKind)
       mov       rax,[rbp+10]
       vmovdqu   xmm0,xmmword ptr [rbp+0FFE8]
       vmovdqu   xmmword ptr [rax],xmm0
       mov       rcx,[rbp+0FFF8]
       mov       [rax+10],rcx
       mov       rax,[rbp+10]
       add       rsp,50
       pop       rbp
       ret
; Total bytes of code 108
```
```assembly
; Tedd.Voxtree.OctreeCodec.TryReadVarUInt(System.ReadOnlySpan`1<Byte>, Int32 ByRef, UInt32 ByRef)
       push      rbp
       sub       rsp,80
       lea       rbp,[rsp+80]
       vxorps    xmm4,xmm4,xmm4
       vmovdqu   xmmword ptr [rbp+0FFB8],xmm4
       mov       [rbp+10],rcx
       mov       [rbp+18],rdx
       mov       [rbp+20],r8
       mov       dword ptr [rbp+0FFB0],3E8
       mov       rax,[rbp+20]
       xor       ecx,ecx
       mov       [rax],ecx
       mov       rax,[rbp+18]
       mov       eax,[rax]
       mov       [rbp+0FFC4],eax
       xor       eax,eax
       mov       [rbp+0FFC0],eax
       jmp       near ptr 00000000000076B9
M14_L00:
       mov       rax,[rbp+18]
       mov       eax,[rax]
       mov       rcx,[rbp+10]
       cmp       eax,[rcx+8]
       jb        short 00000000000075CA
       mov       rcx,7FF83A86C7B0
       call      0000000000008420
       jmp       near ptr 00000000000076EE
M14_L01:
       mov       rax,[rbp+18]
       mov       eax,[rax]
       mov       [rbp+0FFB8],eax
       mov       eax,[rbp+0FFB8]
       inc       eax
       mov       rcx,[rbp+18]
       mov       [rcx],eax
       mov       rax,[rbp+10]
       mov       eax,[rax+8]
       cmp       [rbp+0FFB8],eax
       jae       near ptr 0000000000007706
       mov       rax,[rbp+10]
       mov       rax,[rax]
       mov       ecx,[rbp+0FFB8]
       movzx     eax,byte ptr [rax+rcx]
       mov       [rbp+0FFBC],eax
       cmp       dword ptr [rbp+0FFC0],1C
       jne       short 0000000000007634
       mov       eax,[rbp+0FFBC]
       and       eax,0F0
       test      eax,eax
       je        short 0000000000007625
       mov       rcx,7FF83A86C7B4
       call      0000000000008420
       jmp       near ptr 00000000000076EE
M14_L02:
       mov       rcx,7FF83A86C7B8
       call      0000000000008420
M14_L03:
       mov       eax,[rbp+0FFBC]
       and       eax,7F
       mov       ecx,[rbp+0FFC0]
       shlx      eax,eax,ecx
       mov       rcx,[rbp+20]
       or        [rcx],eax
       mov       eax,[rbp+0FFBC]
       and       eax,80
       test      eax,eax
       jne       short 00000000000076A1
       mov       rax,[rbp+18]
       mov       eax,[rax]
       sub       eax,[rbp+0FFC4]
       cmp       eax,1
       je        short 0000000000007684
       mov       rcx,7FF83A86C7BC
       call      0000000000008420
       mov       eax,[rbp+0FFBC]
       and       eax,7F
       test      eax,eax
       setne     al
       movzx     eax,al
       mov       [rbp+0FFAC],eax
       jmp       short 00000000000076F9
M14_L04:
       mov       rcx,7FF83A86C7C0
       call      0000000000008420
       mov       eax,1
       add       rsp,80
       pop       rbp
       ret
M14_L05:
       mov       rcx,7FF83A86C7C4
       call      0000000000008420
       mov       eax,[rbp+0FFC0]
       add       eax,7
       mov       [rbp+0FFC0],eax
M14_L06:
       mov       eax,[rbp+0FFB0]
       dec       eax
       mov       [rbp+0FFB0],eax
       cmp       dword ptr [rbp+0FFB0],0
       jg        short 00000000000076D5
       lea       rcx,[rbp+0FFB0]
       mov       edx,65
       call      0000000000003990
M14_L07:
       cmp       dword ptr [rbp+0FFC0],1C
       jle       near ptr 00000000000075A7
       mov       rcx,7FF83A86C7C8
       call      0000000000008420
M14_L08:
       xor       eax,eax
       add       rsp,80
       pop       rbp
       ret
M14_L09:
       movzx     eax,byte ptr [rbp+0FFAC]
       add       rsp,80
       pop       rbp
       ret
M14_L10:
       call      0000000000001788
       int       3
; Total bytes of code 428
```
```assembly
; System.ReadOnlySpan`1[[System.Byte, System.Private.CoreLib]].Slice(Int32, Int32)
       sub       rsp,28
       mov       eax,r8d
       mov       r8d,r9d
       add       r8,rax
       mov       r10d,[rcx+8]
       cmp       r8,r10
       ja        short 0000000000006388
       add       rax,[rcx]
       mov       [rdx],rax
       mov       [rdx+8],r9d
       mov       rax,rdx
       add       rsp,28
       ret
M15_L00:
       call      qword ptr [0F2B8]
       int       3
; Total bytes of code 47
```
```assembly
; Tedd.Voxtree.HotOctreeChunk.GetValues()
       push      rbp
       sub       rsp,40
       lea       rbp,[rsp+40]
       vxorps    xmm4,xmm4,xmm4
       vmovdqu   ymmword ptr [rbp+0FFE0],ymm4
       mov       [rbp+10],rcx
       mov       rax,[rbp+10]
       mov       rax,[rax+8]
       mov       [rbp+0FFF8],rax
       mov       rax,[rbp+0FFF8]
       mov       [rbp+0FFF0],rax
       cmp       qword ptr [rbp+0FFF8],0
       jne       short 0000000000006926
       mov       rcx,offset MT_System.InvalidOperationException
       call      0000000000005240
       mov       [rbp+0FFE8],rax
       mov       ecx,9F3
       mov       rdx,7FF83A864600
       call      qword ptr [7270]; Precode of System.String.StrCns(UInt32, IntPtr)
       mov       [rbp+0FFE0],rax
       mov       rdx,[rbp+0FFE0]
       mov       rcx,[rbp+0FFE8]
       call      qword ptr [6658]; Precode of System.InvalidOperationException..ctor(System.String)
       mov       rcx,[rbp+0FFE8]
       call      000000000000B8A0
       int       3
M16_L00:
       mov       rax,[rbp+0FFF0]
       add       rsp,40
       pop       rbp
       ret
; Total bytes of code 128
```
```assembly
; Tedd.Voxtree.HotOctreeChunk.get_ChannelCount()
       push      rbp
       mov       rbp,rsp
       mov       [rbp+10],rcx
       mov       rax,[rbp+10]
       mov       eax,[rax+24]
       pop       rbp
       ret
; Total bytes of code 17
```
```assembly
; Tedd.Voxtree.OctreeCodec.GetVoxelCount(Int32)
       push      rbp
       mov       rbp,rsp
       mov       [rbp+10],ecx
       mov       eax,1
       mov       ecx,[rbp+10]
       lea       ecx,[rcx+rcx*2]
       shlx      eax,eax,ecx
       pop       rbp
       ret
; Total bytes of code 25
```
```assembly
; System.MemoryExtensions.AsSpan[[System.UInt32, System.Private.CoreLib]](UInt32[], Int32, Int32)
       sub       rsp,28
       test      rdx,rdx
       je        short 00000000000069AF
       mov       r8d,r8d
       mov       eax,r9d
       add       rax,r8
       mov       r10d,[rdx+8]
       cmp       rax,r10
       ja        short 00000000000069BB
       lea       rax,[rdx+r8*4+10]
M19_L00:
       mov       [rcx],rax
       mov       [rcx+8],r9d
       mov       rax,rcx
       add       rsp,28
       ret
M19_L01:
       or        r8d,r9d
       jne       short 00000000000069BB
       xor       eax,eax
       xor       r9d,r9d
       jmp       short 00000000000069A0
M19_L02:
       call      qword ptr [7C18]; Precode of System.ThrowHelper.ThrowArgumentOutOfRangeException()
       int       3
; Total bytes of code 66
```
```assembly
; Tedd.Voxtree.OctreeCodec.ValidateLevels(Int32)
       push      rbp
       sub       rsp,80
       lea       rbp,[rsp+80]
       xor       eax,eax
       mov       [rbp+0FFA8],rax
       vxorps    xmm4,xmm4,xmm4
       vmovdqu   ymmword ptr [rbp+0FFB0],ymm4
       vmovdqu   ymmword ptr [rbp+0FFD0],ymm4
       vmovdqa   xmmword ptr [rbp+0FFF0],xmm4
       mov       [rbp+10],ecx
       cmp       dword ptr [rbp+10],9
       jbe       near ptr 0000000000005C2F
       mov       rcx,offset MT_System.Int32
       call      0000000000005240
       mov       [rbp+0FFD0],rax
       mov       rax,[rbp+0FFD0]
       mov       ecx,[rbp+10]
       mov       [rax+8],ecx
       lea       rcx,[rbp+0FFD8]
       mov       edx,31
       mov       r8d,1
       call      qword ptr [67F0]; System.Runtime.CompilerServices.DefaultInterpolatedStringHandler..ctor(Int32, Int32)
       mov       ecx,1341
       mov       rdx,7FF83A864600
       call      qword ptr [7270]; Precode of System.String.StrCns(UInt32, IntPtr)
       mov       [rbp+0FFC0],rax
       mov       rdx,[rbp+0FFC0]
       lea       rcx,[rbp+0FFD8]
       call      qword ptr [6C28]; System.Runtime.CompilerServices.DefaultInterpolatedStringHandler.AppendLiteral(System.String)
       lea       rcx,[rbp+0FFD8]
       mov       edx,9
       call      qword ptr [6AD8]; System.Runtime.CompilerServices.DefaultInterpolatedStringHandler.AppendFormatted[[System.Int32, System.Private.CoreLib]](Int32)
       mov       ecx,369
       mov       rdx,7FF83A864600
       call      qword ptr [7270]; Precode of System.String.StrCns(UInt32, IntPtr)
       mov       [rbp+0FFB8],rax
       mov       rdx,[rbp+0FFB8]
       lea       rcx,[rbp+0FFD8]
       call      qword ptr [6C28]; System.Runtime.CompilerServices.DefaultInterpolatedStringHandler.AppendLiteral(System.String)
       mov       rcx,offset MT_System.ArgumentOutOfRangeException
       call      0000000000005240
       mov       [rbp+0FFC8],rax
       mov       ecx,1333
       mov       rdx,7FF83A864600
       call      qword ptr [7270]; Precode of System.String.StrCns(UInt32, IntPtr)
       mov       [rbp+0FFB0],rax
       lea       rcx,[rbp+0FFD8]
       call      qword ptr [6820]; System.Runtime.CompilerServices.DefaultInterpolatedStringHandler.ToStringAndClear()
       mov       [rbp+0FFA8],rax
       mov       rdx,[rbp+0FFB0]
       mov       r9,[rbp+0FFA8]
       mov       r8,[rbp+0FFD0]
       mov       rcx,[rbp+0FFC8]
       call      qword ptr [7ED0]; Precode of System.ArgumentOutOfRangeException..ctor(System.String, System.Object, System.String)
       mov       rcx,[rbp+0FFC8]
       call      000000000000B8A0
       int       3
M20_L00:
       add       rsp,80
       pop       rbp
       ret
; Total bytes of code 296
```
```assembly
; Tedd.Voxtree.DenseVoxel.Validate(Tedd.Voxtree.DenseVoxelLayout)
       push      rbp
       sub       rsp,30
       lea       rbp,[rsp+30]
       xor       eax,eax
       mov       [rbp+0FFF8],rax
       mov       [rbp+0FFF0],rax
       mov       [rbp+10],ecx
       cmp       dword ptr [rbp+10],0
       je        short 0000000000005CC6
       cmp       dword ptr [rbp+10],1
       je        short 0000000000005CB7
       mov       rcx,offset MT_System.ArgumentOutOfRangeException
       call      0000000000005240
       mov       [rbp+0FFF8],rax
       mov       ecx,4B5
       mov       rdx,7FF83A864600
       call      qword ptr [7270]; Precode of System.String.StrCns(UInt32, IntPtr)
       mov       [rbp+0FFF0],rax
       mov       rdx,[rbp+0FFF0]
       mov       rcx,[rbp+0FFF8]
       call      qword ptr [0D1E8]; Precode of System.ArgumentOutOfRangeException..ctor(System.String)
       mov       rcx,[rbp+0FFF8]
       call      000000000000B8A0
       int       3
M21_L00:
       mov       rcx,7FF83A92E860
       call      0000000000008420
M21_L01:
       mov       rcx,7FF83A92E864
       call      0000000000008420
       nop
       add       rsp,30
       pop       rbp
       ret
; Total bytes of code 140
```
```assembly
; Tedd.Voxtree.DenseVoxel.Index(Int32, Int32, Int32, Int32, Tedd.Voxtree.DenseVoxelLayout)
       push      rbp
       sub       rsp,20
       lea       rbp,[rsp+20]
       mov       [rbp+10],ecx
       mov       [rbp+18],edx
       mov       [rbp+20],r8d
       mov       [rbp+28],r9d
       cmp       dword ptr [rbp+30],0
       je        short 0000000000006B34
       mov       rcx,7FF83A92EB00
       call      0000000000008420
       mov       ecx,[rbp+10]
       mov       edx,[rbp+18]
       mov       r8d,[rbp+20]
       call      qword ptr [0E610]; Tedd.MortonEncoding.Encode(UInt32, UInt32, UInt32)
       nop
       add       rsp,20
       pop       rbp
       ret
M22_L00:
       mov       rcx,7FF83A92EB04
       call      0000000000008420
       mov       eax,[rbp+10]
       imul      eax,[rbp+28]
       add       eax,[rbp+18]
       imul      eax,[rbp+28]
       add       eax,[rbp+20]
       add       rsp,20
       pop       rbp
       ret
; Total bytes of code 106
```
```assembly
; Tedd.Voxtree.OctreeChunk.get_ChannelCount()
       mov       rax,[rcx+8]
       mov       eax,[rax+8]
       ret
; Total bytes of code 8
```
```assembly
; Tedd.Voxtree.OctreeSpan..ctor(System.ReadOnlySpan`1<Byte>, Int32, Tedd.Voxtree.StorageKind)
       push      rbp
       mov       rbp,rsp
       mov       [rbp+10],rcx
       mov       [rbp+18],rdx
       mov       [rbp+20],r8d
       mov       [rbp+28],r9d
       mov       rax,[rbp+18]
       mov       rcx,[rbp+10]
       vmovdqu   xmm0,xmmword ptr [rax]
       vmovdqu   xmmword ptr [rcx],xmm0
       mov       rax,[rbp+10]
       mov       ecx,[rbp+20]
       mov       [rax+10],ecx
       mov       rax,[rbp+10]
       mov       ecx,[rbp+28]
       mov       [rax+14],cl
       pop       rbp
       ret
; Total bytes of code 58
```
```assembly
; System.Runtime.CompilerServices.DefaultInterpolatedStringHandler..ctor(Int32, Int32)
       push      rdi
       push      rsi
       push      rbx
       sub       rsp,20
       mov       rbx,rcx
       mov       esi,edx
       mov       edi,r8d
       xor       eax,eax
       mov       [rbx],rax
       call      qword ptr [0A098]
       mov       rcx,[rax]
       imul      edx,edi,0B
       add       edx,esi
       mov       eax,100
       cmp       edx,100
       cmovle    edx,eax
       cmp       [rcx],ecx
       call      qword ptr [98B8]; Precode of System.Buffers.SharedArrayPool`1[[System.Char, System.Private.CoreLib]].Rent(Int32)
       mov       [rbx+8],rax
       test      rax,rax
       je        short 000000000000C4E0
       lea       rcx,[rax+10]
       mov       eax,[rax+8]
M25_L00:
       mov       [rbx+18],rcx
       mov       [rbx+20],eax
       xor       eax,eax
       mov       [rbx+10],eax
       mov       byte ptr [rbx+14],0
       add       rsp,20
       pop       rbx
       pop       rsi
       pop       rdi
       ret
M25_L01:
       xor       ecx,ecx
       xor       eax,eax
       jmp       short 000000000000C4C8
; Total bytes of code 102
```
```assembly
; System.Runtime.CompilerServices.DefaultInterpolatedStringHandler.AppendLiteral(System.String)
       push      rdi
       push      rsi
       push      rbx
       sub       rsp,20
       mov       rbx,rcx
       mov       rsi,rdx
       lea       r8,[rbx+18]
       mov       edx,[rbx+10]
       mov       ecx,[r8+8]
       cmp       edx,ecx
       ja        short 0000000000003F9B
       mov       r8,[r8]
       mov       eax,edx
       lea       rax,[r8+rax*2]
       sub       ecx,edx
       mov       edi,[rsi+8]
       cmp       edi,ecx
       ja        short 0000000000003FA2
       mov       r8d,edi
       add       r8,r8
       lea       rdx,[rsi+0C]
       mov       rcx,rax
       call      qword ptr [5818]; System.SpanHelpers.Memmove(Byte ByRef, Byte ByRef, UIntPtr)
       mov       rcx,7FF83A8123F8
       call      0000000000008420
       add       [rbx+10],edi
       add       rsp,20
       pop       rbx
       pop       rsi
       pop       rdi
       ret
M26_L00:
       call      qword ptr [7C18]; Precode of System.ThrowHelper.ThrowArgumentOutOfRangeException()
       int       3
M26_L01:
       mov       rcx,7FF83A8123FC
       call      0000000000008420
       mov       rcx,rbx
       mov       rdx,rsi
       add       rsp,20
       pop       rbx
       pop       rsi
       pop       rdi
       jmp       qword ptr [6808]; Precode of System.Runtime.CompilerServices.DefaultInterpolatedStringHandler.GrowThenCopyString(System.String)
; Total bytes of code 132
```
```assembly
; System.Runtime.CompilerServices.DefaultInterpolatedStringHandler.AppendFormatted[[System.Int32, System.Private.CoreLib]](Int32)
       push      rdi
       push      rsi
       push      rbp
       push      rbx
       sub       rsp,58
       xorps     xmm4,xmm4
       movaps    [rsp+30],xmm4
       movaps    [rsp+40],xmm4
       mov       rbx,rcx
       mov       esi,edx
       cmp       byte ptr [rbx+14],0
       jne       short 000000000000F15B
M27_L00:
       lea       rdx,[rbx+18]
       mov       r8d,[rbx+10]
       mov       edi,[rdx+8]
       cmp       r8d,edi
       ja        near ptr 000000000000F1D8
       mov       rdx,[rdx]
       mov       ecx,r8d
       lea       rbp,[rdx+rcx*2]
       sub       edi,r8d
       mov       rcx,[rbx]
       test      esi,esi
       jl        short 000000000000F173
       mov       [rsp+40],rbp
       mov       [rsp+48],edi
       lea       rdx,[rsp+40]
       lea       r8,[rsp+50]
       mov       ecx,esi
       call      qword ptr [0CF8]; Precode of System.Number.TryUInt32ToDecStr[[System.Char, System.Private.CoreLib]](UInt32, System.Span`1<Char>, Int32 ByRef)
M27_L01:
       test      eax,eax
       jne       short 000000000000F152
       mov       rcx,rbx
       call      qword ptr [4FF8]
       jmp       short 000000000000F100
M27_L02:
       mov       eax,[rsp+50]
       add       [rbx+10],eax
       jmp       short 000000000000F169
M27_L03:
       mov       rcx,rbx
       mov       edx,esi
       xor       r8d,r8d
       call      qword ptr [1B50]
M27_L04:
       nop
       add       rsp,58
       pop       rbx
       pop       rbp
       pop       rsi
       pop       rdi
       ret
M27_L05:
       test      rcx,rcx
       je        short 000000000000F180
       call      qword ptr [1260]; Precode of System.Globalization.NumberFormatInfo.<GetInstance>g__GetProviderNonNull|58_0(System.IFormatProvider)
       jmp       short 000000000000F186
M27_L06:
       call      qword ptr [1248]; Precode of System.Globalization.NumberFormatInfo.get_CurrentInfo()
M27_L07:
       mov       r8,[rax+28]
       test      r8,r8
       jne       short 000000000000F197
       xor       r9d,r9d
       xor       r8d,r8d
       jmp       short 000000000000F19F
M27_L08:
       lea       r9,[r8+0C]
       mov       r8d,[r8+8]
M27_L09:
       mov       [rsp+30],r9
       mov       [rsp+38],r8d
       mov       [rsp+40],rbp
       mov       [rsp+48],edi
       lea       r8,[rsp+50]
       mov       [rsp+20],r8
       lea       r8,[rsp+30]
       lea       r9,[rsp+40]
       mov       ecx,esi
       mov       edx,0FFFFFFFF
       call      qword ptr [0CE0]
       jmp       near ptr 000000000000F143
M27_L10:
       call      qword ptr [0F2B8]
       int       3
; Total bytes of code 255
```
```assembly
; System.Runtime.CompilerServices.DefaultInterpolatedStringHandler.ToStringAndClear()
       push      rdi
       push      rsi
       push      rbp
       push      rbx
       sub       rsp,38
       xor       eax,eax
       mov       [rsp+28],rax
       mov       rbx,rcx
       lea       rsi,[rbx+18]
       mov       rcx,rsi
       mov       eax,[rbx+10]
       cmp       eax,[rcx+8]
       ja        short 000000000000C6F7
       mov       rcx,[rcx]
       mov       [rsp+28],rcx
       mov       [rsp+30],eax
       lea       rcx,[rsp+28]
       call      qword ptr [0BB28]; Precode of System.String.Ctor(System.ReadOnlySpan`1<Char>)
       mov       rdi,rax
       mov       rbp,[rbx+8]
       xor       eax,eax
       mov       [rbx+8],rax
       mov       [rsi],rax
       mov       [rsi+8],rax
       mov       [rbx+10],eax
       test      rbp,rbp
       je        short 000000000000C6EB
       call      qword ptr [0A098]
       mov       rcx,[rax]
       mov       rdx,rbp
       xor       r8d,r8d
       cmp       [rcx],ecx
       call      qword ptr [98C0]
M28_L00:
       mov       rax,rdi
       add       rsp,38
       pop       rbx
       pop       rbp
       pop       rsi
       pop       rdi
       ret
M28_L01:
       call      qword ptr [0F2B8]
       int       3
; Total bytes of code 126
```
```assembly
; Tedd.MortonEncoding.Encode(UInt32, UInt32, UInt32)
       push      rbp
       mov       rbp,rsp
       mov       [rbp+10],ecx
       mov       [rbp+18],edx
       mov       [rbp+20],r8d
       mov       eax,[rbp+20]
       mov       ecx,24924924
       pdep      eax,eax,ecx
       mov       ecx,[rbp+18]
       mov       edx,12492492
       pdep      ecx,ecx,edx
       or        eax,ecx
       mov       ecx,[rbp+10]
       mov       edx,9249249
       pdep      ecx,ecx,edx
       or        eax,ecx
       pop       rbp
       ret
; Total bytes of code 59
```
**Method was not JITted yet.**
Tedd.Voxtree.OctreeThrowHelper.ThrowInvalidView()
Tedd.Voxtree.OctreeThrowHelper.ThrowCoordinate(System.String, Int32)
Tedd.Voxtree.OctreeThrowHelper.ThrowMalformed()
System.String.StrCns(UInt32, IntPtr)
System.ObjectDisposedException..ctor(System.String)
System.ArgumentOutOfRangeException..ctor(System.String)
System.ThrowHelper.ThrowArgumentOutOfRangeException()
System.Buffers.Binary.BinaryPrimitives.ReadUInt32LittleEndian(System.ReadOnlySpan`1<Byte>)
System.InvalidOperationException..ctor(System.String)
System.ArgumentOutOfRangeException..ctor(System.String, System.Object, System.String)

## .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v3 (Job: Job-GJBZFV(IterationCount=7, IterationTime=150ms, LaunchCount=1, WarmupCount=3))

```assembly
; Tedd.Voxtree.Benchmark.Tests.DeferredChunkReads.DeferredHits()
       push      r15
       push      r14
       push      r13
       push      r12
       push      rdi
       push      rsi
       push      rbp
       push      rbx
       sub       rsp,78
       vxorps    xmm4,xmm4,xmm4
       vmovdqu   ymmword ptr [rsp+40],ymm4
       vmovdqa   xmmword ptr [rsp+60],xmm4
       mov       rbx,rcx
       mov       rsi,[rbx+20]
       xor       edi,edi
       xor       ebp,ebp
       jmp       near ptr 000000000000C099
       nop
M00_L00:
       mov       r11d,edx
       shl       r11d,4
       tzcnt     r9d,r9d
       sar       r9d,1
       add       r9d,r11d
M00_L01:
       test      r9d,r9d
       jl        near ptr 000000000000C2BA
       mov       r10,[rsp+38]
       mov       rcx,[r10+20]
       mov       eax,[rsp+74]
       mov       edx,eax
       imul      edx,[r10+2C]
       mov       r8d,r9d
       sar       r8d,6
       add       edx,r8d
       cmp       edx,[rcx+8]
       jae       near ptr 000000000000C471
       mov       rcx,[rcx+rdx*8+10]
       bt        rcx,r9
       jae       near ptr 000000000000C2BE
       mov       rcx,[r10+8]
       cmp       eax,[rcx+8]
       jae       near ptr 000000000000C471
       mov       edx,eax
       mov       rcx,[rcx+rdx*8+10]
       cmp       r9d,[rcx+8]
       jae       near ptr 000000000000C471
       mov       edx,r9d
       mov       r10d,[rcx+rdx*4+10]
M00_L02:
       add       edi,r10d
       inc       ebp
       cmp       ebp,100
       jge       near ptr 000000000000C1FB
M00_L03:
       cmp       ebp,[rsi+8]
       jae       near ptr 000000000000C471
       mov       r14d,[rsi+rbp*4+10]
       mov       r15,[rbx+18]
       mov       r13d,r14d
       sar       r13d,0A
       mov       r12d,r14d
       sar       r12d,5
       and       r12d,1F
       mov       eax,ebp
       and       eax,1
       mov       [rsp+74],eax
       and       r14d,1F
       cmp       byte ptr [r15+24],0
       jne       near ptr 000000000000C3B6
       mov       rdx,[r15+8]
       mov       rcx,[rdx+8]
       cmp       [rcx+8],eax
       jbe       near ptr 000000000000C3F2
       mov       edx,[rdx+10]
       mov       ecx,edx
       and       ecx,1F
       mov       r8d,1
       shlx      r8d,r8d,ecx
       cmp       r13d,r8d
       jae       near ptr 000000000000C42E
       cmp       r12d,r8d
       jae       near ptr 000000000000C42E
       cmp       r14d,r8d
       jae       near ptr 000000000000C42E
       add       edx,edx
       shlx      edx,r13d,edx
       shlx      ecx,r12d,ecx
       or        edx,ecx
       or        edx,r14d
       cmp       qword ptr [r15+10],0
       jne       near ptr 000000000000C211
       mov       r10,[r15+18]
       test      r10,r10
       je        near ptr 000000000000C236
       mov       [rsp+38],r10
       mov       ecx,[r10+30]
       test      ecx,ecx
       je        near ptr 000000000000C1CC
       mov       r8,[r10+10]
       test      r8,r8
       je        near ptr 000000000000C23F
       cmp       ecx,1
       je        short 000000000000C1D7
       cmp       ecx,20
       jg        near ptr 000000000000C273
       add       ecx,0F
       and       ecx,0FFFFFFF0
       cmp       [r8+8],ecx
       jb        near ptr 000000000000C46A
       add       r8,10
       add       rcx,rcx
       shr       rcx,5
       cmp       rcx,7FFFFFFF
       ja        near ptr 000000000000C477
       vmovd     xmm0,edx
       vpbroadcastw ymm0,xmm0
       xor       edx,edx
       test      ecx,ecx
       jle       short 000000000000C1C7
M00_L04:
       mov       r9,rdx
       shl       r9,5
       vpcmpeqw  ymm1,ymm0,[r8+r9]
       vpmovmskb r9d,ymm1
       test      r9d,r9d
       jne       near ptr 000000000000C011
       inc       edx
       cmp       edx,ecx
       jl        short 000000000000C1A0
       mov       r10,[rsp+38]
       jmp       short 000000000000C1CC
M00_L05:
       mov       r10,[rsp+38]
M00_L06:
       mov       r9d,0FFFFFFFF
       jmp       near ptr 000000000000C023
M00_L07:
       cmp       dword ptr [r8+8],0
       jbe       near ptr 000000000000C471
       movzx     r9d,word ptr [r8+10]
       cmp       r9d,edx
       je        short 000000000000C1F3
       mov       r10,[rsp+38]
       jmp       short 000000000000C1CC
M00_L08:
       xor       r9d,r9d
       jmp       near ptr 000000000000C023
M00_L09:
       mov       eax,edi
       vzeroupper
       add       rsp,78
       pop       rbx
       pop       rbp
       pop       rsi
       pop       rdi
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       ret
M00_L10:
       mov       eax,[rsp+74]
       mov       [rsp+20],r14d
       mov       rcx,[r15+10]
       mov       edx,eax
       mov       r8d,r13d
       mov       r9d,r12d
       cmp       [rcx],ecx
       call      qword ptr [0E820]; Tedd.Voxtree.HotOctreeChunk.get_Item(Int32, Int32, Int32, Int32)
       mov       r10d,eax
       jmp       near ptr 000000000000C088
M00_L11:
       mov       eax,[rsp+74]
       jmp       near ptr 000000000000C2BE
M00_L12:
       mov       r10,[rsp+38]
       mov       r8,[r10+18]
       mov       r9d,ecx
       test      r8,r8
       je        near ptr 000000000000C46A
       cmp       [r8+8],r9d
       jb        near ptr 000000000000C46A
       lea       rcx,[r8+10]
       mov       r8d,r9d
       call      qword ptr [5398]; Precode of System.SpanHelpers.NonPackedIndexOfValueType[[System.Int32, System.Private.CoreLib],[System.SpanHelpers+DontNegate`1[[System.Int32, System.Private.CoreLib]], System.Private.CoreLib]](Int32 ByRef, Int32, Int32)
       mov       r9d,eax
       jmp       near ptr 000000000000C023
M00_L13:
       mov       r9d,ecx
       cmp       [r8+8],r9d
       jb        near ptr 000000000000C46A
       lea       rcx,[r8+10]
       movzx     edx,dx
       movsx     rdx,dx
       movzx     r8d,dx
       dec       r8d
       cmp       r8d,0FE
       jae       short 000000000000C2A9
       mov       r8d,r9d
       call      qword ptr [0C378]; System.PackedSpanHelpers.IndexOf[[System.SpanHelpers+DontNegate`1[[System.Int16, System.Private.CoreLib]], System.Private.CoreLib],[System.PackedSpanHelpers+NopTransform, System.Private.CoreLib]](Int16 ByRef, Int16, Int32)
       mov       r9d,eax
       jmp       short 000000000000C2B5
M00_L14:
       mov       r8d,r9d
       call      qword ptr [6220]
       mov       r9d,eax
M00_L15:
       jmp       near ptr 000000000000C023
M00_L16:
       mov       eax,[rsp+74]
M00_L17:
       mov       rcx,[r15+8]
       lea       rdx,[rsp+58]
       mov       r8d,eax
       cmp       [rcx],ecx
       call      qword ptr [0DB78]; Tedd.Voxtree.OctreeChunk.GetChannel(Int32)
       xor       ecx,ecx
       mov       [rsp+50],ecx
       mov       edx,[rsp+68]
       cmp       dword ptr [rsp+60],0
       jne       short 000000000000C2F1
       call      qword ptr [0EBB0]; Precode of Tedd.Voxtree.OctreeThrowHelper.ThrowInvalidView()
       mov       r10d,eax
       jmp       near ptr 000000000000C3B1
M00_L18:
       mov       ecx,1
       shlx      ecx,ecx,edx
       cmp       r13d,ecx
       jb        short 000000000000C31B
       mov       edx,r13d
       mov       rcx,16F80552B18
       call      qword ptr [0EBC8]; Precode of Tedd.Voxtree.OctreeThrowHelper.ThrowCoordinate(System.String, Int32)
       mov       r10d,eax
       jmp       near ptr 000000000000C3B1
M00_L19:
       mov       ecx,1
       shlx      ecx,ecx,edx
       cmp       r12d,ecx
       jb        short 000000000000C342
       mov       edx,r12d
       mov       rcx,16F805622F8
       call      qword ptr [0EBC8]; Precode of Tedd.Voxtree.OctreeThrowHelper.ThrowCoordinate(System.String, Int32)
       mov       r10d,eax
       jmp       short 000000000000C3B1
M00_L20:
       mov       ecx,1
       shlx      ecx,ecx,edx
       cmp       r14d,ecx
       jb        short 000000000000C369
       mov       edx,r14d
       mov       rcx,16F80562310
       call      qword ptr [0EBC8]; Precode of Tedd.Voxtree.OctreeThrowHelper.ThrowCoordinate(System.String, Int32)
       mov       r10d,eax
       jmp       short 000000000000C3B1
M00_L21:
       vmovdqu   xmm0,xmmword ptr [rsp+58]
       vmovdqu   xmmword ptr [rsp+40],xmm0
       mov       [rsp+20],r12d
       mov       [rsp+28],r14d
       lea       rcx,[rsp+50]
       mov       [rsp+30],rcx
       lea       rcx,[rsp+40]
       movzx     r8d,byte ptr [rsp+6C]
       mov       r9d,r13d
       call      qword ptr [0EBE0]; Tedd.Voxtree.OctreeCodec.TryGetUnchecked(System.ReadOnlySpan`1<Byte>, Int32, Tedd.Voxtree.StorageKind, Int32, Int32, Int32, UInt32 ByRef)
       test      eax,eax
       jne       short 000000000000C3AC
       call      qword ptr [0EBF8]; Precode of Tedd.Voxtree.OctreeThrowHelper.ThrowMalformed()
       mov       r10d,eax
       jmp       short 000000000000C3B1
M00_L22:
       mov       r10d,[rsp+50]
M00_L23:
       jmp       near ptr 000000000000C088
M00_L24:
       mov       rcx,offset MT_System.ObjectDisposedException
       call      0000000000005240
       mov       rbx,rax
       mov       ecx,3F5
       mov       rdx,7FF83A852A78
       call      qword ptr [6F28]; Precode of System.String.StrCns(UInt32, IntPtr)
       mov       rdx,rax
       mov       rcx,rbx
       call      qword ptr [7B40]; Precode of System.ObjectDisposedException..ctor(System.String)
       mov       rcx,rbx
       call      000000000000B8A0
       int       3
M00_L25:
       mov       rcx,offset MT_System.ArgumentOutOfRangeException
       call      0000000000005240
       mov       rbx,rax
       mov       ecx,3E1
       mov       rdx,7FF83A852A78
       call      qword ptr [6F28]; Precode of System.String.StrCns(UInt32, IntPtr)
       mov       rdx,rax
       mov       rcx,rbx
       call      qword ptr [0D1B8]; Precode of System.ArgumentOutOfRangeException..ctor(System.String)
       mov       rcx,rbx
       call      000000000000B8A0
       int       3
M00_L26:
       mov       rcx,offset MT_System.ArgumentOutOfRangeException
       call      0000000000005240
       mov       rbx,rax
       mov       ecx,3F1
       mov       rdx,7FF83A852A78
       call      qword ptr [6F28]; Precode of System.String.StrCns(UInt32, IntPtr)
       mov       rdx,rax
       mov       rcx,rbx
       call      qword ptr [0D1B8]; Precode of System.ArgumentOutOfRangeException..ctor(System.String)
       mov       rcx,rbx
       call      000000000000B8A0
       int       3
M00_L27:
       call      qword ptr [7C30]; Precode of System.ThrowHelper.ThrowArgumentOutOfRangeException()
       int       3
M00_L28:
       call      0000000000001788
       int       3
M00_L29:
       call      0000000000001770
       int       3
; Total bytes of code 1181
```
```assembly
; Tedd.Voxtree.HotOctreeChunk.get_Item(Int32, Int32, Int32, Int32)
       push      rbp
       sub       rsp,40
       lea       rbp,[rsp+40]
       xor       eax,eax
       mov       [rbp+0FFF0],rax
       mov       [rbp+0FFF8],rax
       mov       [rbp+10],rcx
       mov       [rbp+18],edx
       mov       [rbp+20],r8d
       mov       [rbp+28],r9d
       lea       rdx,[rbp+0FFF0]
       mov       rcx,[rbp+10]
       mov       r8d,[rbp+18]
       call      qword ptr [0E628]; Tedd.Voxtree.HotOctreeChunk.GetChannelSpan(Int32)
       mov       rcx,[rbp+10]
       call      qword ptr [0E640]; Tedd.Voxtree.HotOctreeChunk.get_Levels()
       mov       [rbp+0FFE8],eax
       mov       dword ptr [rsp+20],1
       mov       r9d,[rbp+0FFE8]
       mov       edx,[rbp+28]
       mov       r8d,[rbp+30]
       mov       ecx,[rbp+20]
       call      qword ptr [0E658]; Tedd.Voxtree.DenseVoxel.GetIndex(Int32, Int32, Int32, Int32, Tedd.Voxtree.DenseVoxelLayout)
       mov       [rbp+0FFEC],eax
       mov       eax,[rbp+0FFF8]
       cmp       [rbp+0FFEC],eax
       jae       short 0000000000009409
       mov       eax,[rbp+0FFEC]
       mov       rcx,[rbp+0FFF0]
       mov       eax,[rcx+rax*4]
       add       rsp,40
       pop       rbp
       ret
M01_L00:
       call      0000000000001788
       int       3
; Total bytes of code 127
```
```assembly
; System.SpanHelpers.NonPackedIndexOfValueType[[System.Int32, System.Private.CoreLib],[System.SpanHelpers+DontNegate`1[[System.Int32, System.Private.CoreLib]], System.Private.CoreLib]](Int32 ByRef, Int32, Int32)
       cmp       r8d,4
       jl        near ptr 0000000000000E5A
       movd      xmm0,edx
       pshufd    xmm0,xmm0,0
       mov       rdx,rcx
       lea       eax,[r8+0FFFC]
       cdqe
       shl       rax,2
       lea       r10,[rdx+rax]
       movups    xmm1,[rcx]
       pcmpeqd   xmm1,xmm0
       ptest     xmm1,xmm1
       je        short 0000000000000E13
M02_L00:
       movmskps  eax,xmm1
       bsf       r8d,eax
       mov       r10d,20
       test      eax,eax
       cmove     r8d,r10d
       mov       rax,rdx
       sub       rax,rcx
       shr       rax,2
       add       eax,r8d
M02_L01:
       ret
M02_L02:
       add       rdx,10
       cmp       rdx,r10
       jbe       near ptr 0000000000000F43
       mov       ecx,r8d
       test      cl,3
       je        near ptr 0000000000000F5A
       movups    xmm1,[r10]
       pcmpeqd   xmm1,xmm0
       ptest     xmm1,xmm1
       je        near ptr 0000000000000F5A
       movmskps  edx,xmm1
       bsf       r8d,edx
       mov       ecx,20
       test      edx,edx
       cmove     r8d,ecx
       shr       rax,2
       add       eax,r8d
       jmp       short 0000000000000E12
M02_L03:
       xor       r10d,r10d
       cmp       r8d,8
       jge       short 0000000000000E8D
M02_L04:
       cmp       r8d,4
       jge       short 0000000000000EDC
M02_L05:
       test      r8d,r8d
       jle       near ptr 0000000000000F5A
M02_L06:
       dec       r8d
       cmp       [rcx+r10*4],edx
       je        short 0000000000000E88
       inc       r10
       test      r8d,r8d
       jg        short 0000000000000E72
       jmp       near ptr 0000000000000F5A
M02_L07:
       mov       eax,r10d
       jmp       short 0000000000000E12
M02_L08:
       add       r8d,0FFFFFFF8
       cmp       [rcx+r10*4],edx
       je        short 0000000000000E88
       cmp       [rcx+r10*4+4],edx
       je        near ptr 0000000000000F3A
       cmp       [rcx+r10*4+8],edx
       je        near ptr 0000000000000F31
       cmp       [rcx+r10*4+0C],edx
       je        short 0000000000000F28
       cmp       [rcx+r10*4+10],edx
       je        short 0000000000000F1F
       cmp       [rcx+r10*4+14],edx
       je        short 0000000000000F16
       cmp       [rcx+r10*4+18],edx
       je        short 0000000000000F0D
       cmp       [rcx+r10*4+1C],edx
       je        short 0000000000000F04
       add       r10,8
       cmp       r8d,8
       jge       short 0000000000000E8D
       jmp       short 0000000000000E63
M02_L09:
       add       r8d,0FFFFFFFC
       cmp       [rcx+r10*4],edx
       je        short 0000000000000E88
       cmp       [rcx+r10*4+4],edx
       je        short 0000000000000F3A
       cmp       [rcx+r10*4+8],edx
       je        short 0000000000000F31
       cmp       [rcx+r10*4+0C],edx
       je        short 0000000000000F28
       add       r10,4
       jmp       near ptr 0000000000000E69
M02_L10:
       lea       eax,[r10+7]
       jmp       near ptr 0000000000000E12
M02_L11:
       lea       eax,[r10+6]
       jmp       near ptr 0000000000000E12
M02_L12:
       lea       eax,[r10+5]
       jmp       near ptr 0000000000000E12
M02_L13:
       lea       eax,[r10+4]
       jmp       near ptr 0000000000000E12
M02_L14:
       lea       eax,[r10+3]
       jmp       near ptr 0000000000000E12
M02_L15:
       lea       eax,[r10+2]
       jmp       near ptr 0000000000000E12
M02_L16:
       lea       eax,[r10+1]
       jmp       near ptr 0000000000000E12
M02_L17:
       movups    xmm1,[rdx]
       pcmpeqd   xmm1,xmm0
       ptest     xmm1,xmm1
       jne       near ptr 0000000000000DF2
       jmp       near ptr 0000000000000E13
M02_L18:
       mov       eax,0FFFFFFFF
       ret
; Total bytes of code 416
```
```assembly
; System.PackedSpanHelpers.IndexOf[[System.SpanHelpers+DontNegate`1[[System.Int16, System.Private.CoreLib]], System.Private.CoreLib],[System.PackedSpanHelpers+NopTransform, System.Private.CoreLib]](Int16 ByRef, Int16, Int32)
       push      r14
       push      rdi
       push      rsi
       push      rbp
       push      rbx
       sub       rsp,50
       vmovaps   [rsp+40],xmm6
       vmovaps   [rsp+30],xmm7
       vmovaps   [rsp+20],xmm8
       mov       rsi,rcx
       mov       edi,edx
       mov       ebx,r8d
       cmp       ebx,8
       jl        near ptr 000000000000D51C
       mov       rbp,rsi
       cmp       ebx,10
       jle       near ptr 000000000000D499
       vmovd     xmm6,edi
       vpbroadcastb ymm6,xmm6
       cmp       ebx,20
       jle       near ptr 000000000000D3D4
       lea       ecx,[rbx+0FFE0]
       movsxd    rcx,ecx
       lea       rdi,[rbp+rcx*2]
       vmovups   ymm0,[rsi]
       vpackuswb ymm0,ymm0,[rsi+20]
       vpcmpeqb  ymm7,ymm0,ymm6
       vptest    ymm7,ymm7
       jne       short 000000000000D383
M03_L00:
       add       rbp,40
       cmp       rbp,rdi
       jae       short 000000000000D3B9
       mov       rcx,7FF83A4A8EA0
       vextractf128 xmm8,ymm6,1
       call      0000000000008420
       vmovups   ymm0,[rbp]
       vpackuswb ymm0,ymm0,[rbp+20]
       vinsertf128 ymm6,ymm6,xmm8,1
       vpcmpeqb  ymm7,ymm0,ymm6
       vptest    ymm7,ymm7
       je        short 000000000000D34A
M03_L01:
       mov       rcx,7FF83A4A8E94
       vextractf128 xmm8,ymm7,1
       call      0000000000008420
       mov       rax,rbp
       sub       rax,rsi
       shr       rax,1
       vinsertf128 ymm7,ymm7,xmm8,1
       vpermq    ymm0,ymm7,0D8
       vpmovmskb ecx,ymm0
       tzcnt     ecx,ecx
       add       eax,ecx
       jmp       short 000000000000D41C
M03_L02:
       mov       rcx,7FF83A4A8E9C
       vextractf128 xmm8,ymm6,1
       call      0000000000008420
       vinsertf128 ymm6,ymm6,xmm8,1
M03_L03:
       add       ebx,0FFFFFFF0
       movsxd    rcx,ebx
       lea       rbx,[rsi+rcx*2]
       cmp       rbp,rbx
       ja        short 000000000000D43C
       mov       rdi,rbp
M03_L04:
       vmovups   ymm0,[rdi]
       vpackuswb ymm0,ymm0,[rbx]
       vpcmpeqb  ymm6,ymm0,ymm6
       vptest    ymm6,ymm6
       jne       short 000000000000D45C
       mov       rcx,7FF83A4A8EAC
       call      0000000000008420
M03_L05:
       mov       rcx,7FF83A4A8EBC
       call      0000000000008420
       mov       eax,0FFFFFFFF
M03_L06:
       vzeroupper
       vmovaps   xmm6,[rsp+40]
       vmovaps   xmm7,[rsp+30]
       vmovaps   xmm8,[rsp+20]
       add       rsp,50
       pop       rbx
       pop       rbp
       pop       rsi
       pop       rdi
       pop       r14
       ret
M03_L07:
       mov       rcx,7FF83A4A8EA4
       vextractf128 xmm8,ymm6,1
       call      0000000000008420
       mov       rdi,rbx
       vinsertf128 ymm6,ymm6,xmm8,1
       jmp       short 000000000000D3E6
M03_L08:
       mov       rcx,7FF83A4A8EA8
       vextractf128 xmm7,ymm6,1
       call      0000000000008420
       vinsertf128 ymm6,ymm6,xmm7,1
       vpermq    ymm0,ymm6,0D8
       vpmovmskb ecx,ymm0
       tzcnt     ecx,ecx
       cmp       ecx,10
       jge       near ptr 000000000000D670
M03_L09:
       sub       rdi,rsi
       shr       rdi,1
       lea       eax,[rdi+rcx]
       jmp       short 000000000000D41C
M03_L10:
       mov       rcx,7FF83A4A8E98
       call      0000000000008420
       vmovd     xmm6,edi
       vpbroadcastb xmm6,xmm6
       lea       ecx,[rbx+0FFF8]
       movsxd    rcx,ecx
       lea       rbx,[rsi+rcx*2]
       cmp       rsi,rbx
       ja        near ptr 000000000000D67B
       mov       rdi,rsi
M03_L11:
       vmovups   xmm0,[rdi]
       vpackuswb xmm0,xmm0,[rbx]
       vpcmpeqb  xmm6,xmm0,xmm6
       vptest    xmm6,xmm6
       jne       short 000000000000D4EE
       mov       rcx,7FF83A4A8EB8
       call      0000000000008420
       jmp       near ptr 000000000000D408
M03_L12:
       mov       rcx,7FF83A4A8EB4
       call      0000000000008420
       vpmovmskb ecx,xmm6
       tzcnt     ecx,ecx
       cmp       ecx,8
       jge       near ptr 000000000000D692
M03_L13:
       sub       rdi,rsi
       shr       rdi,1
       lea       eax,[rdi+rcx]
       jmp       near ptr 000000000000D41C
M03_L14:
       xor       ebp,ebp
       cmp       ebx,4
       jl        short 000000000000D575
       add       ebx,0FFFFFFFC
       movsx     rcx,word ptr [rsi]
       movsx     r14,di
       cmp       ecx,r14d
       je        near ptr 000000000000D5BE
       movsx     rcx,word ptr [rsi+2]
       cmp       ecx,r14d
       je        near ptr 000000000000D5EF
       movsx     rcx,word ptr [rsi+4]
       cmp       ecx,r14d
       je        near ptr 000000000000D623
       movsx     rcx,word ptr [rsi+6]
       cmp       ecx,r14d
       je        near ptr 000000000000D657
       mov       rcx,7FF83A4A8E88
       call      0000000000008420
       mov       ebp,4
M03_L15:
       test      ebx,ebx
       jle       near ptr 000000000000D408
       movsx     r14,di
M03_L16:
       dec       ebx
       movsx     rcx,word ptr [rsi+rbp*2]
       cmp       ecx,r14d
       je        short 000000000000D5A8
       mov       rcx,7FF83A4A8E90
       call      0000000000008420
       inc       rbp
       test      ebx,ebx
       jg        short 000000000000D581
       jmp       near ptr 000000000000D408
M03_L17:
       mov       rcx,7FF83A4A8E8C
       call      0000000000008420
       mov       eax,ebp
       jmp       near ptr 000000000000D41C
M03_L18:
       mov       rcx,7FF83A4A8E78
       call      0000000000008420
       xor       eax,eax
       vzeroupper
       vmovaps   xmm6,[rsp+40]
       vmovaps   xmm7,[rsp+30]
       vmovaps   xmm8,[rsp+20]
       add       rsp,50
       pop       rbx
       pop       rbp
       pop       rsi
       pop       rdi
       pop       r14
       ret
M03_L19:
       mov       rcx,7FF83A4A8E7C
       call      0000000000008420
       mov       eax,1
       vzeroupper
       vmovaps   xmm6,[rsp+40]
       vmovaps   xmm7,[rsp+30]
       vmovaps   xmm8,[rsp+20]
       add       rsp,50
       pop       rbx
       pop       rbp
       pop       rsi
       pop       rdi
       pop       r14
       ret
M03_L20:
       mov       rcx,7FF83A4A8E80
       call      0000000000008420
       mov       eax,2
       vzeroupper
       vmovaps   xmm6,[rsp+40]
       vmovaps   xmm7,[rsp+30]
       vmovaps   xmm8,[rsp+20]
       add       rsp,50
       pop       rbx
       pop       rbp
       pop       rsi
       pop       rdi
       pop       r14
       ret
M03_L21:
       mov       rcx,7FF83A4A8E84
       call      0000000000008420
       mov       eax,3
       jmp       near ptr 000000000000D41C
M03_L22:
       mov       rdi,rbx
       add       ecx,0FFFFFFF0
       jmp       near ptr 000000000000D48E
M03_L23:
       mov       rcx,7FF83A4A8EB0
       call      0000000000008420
       mov       rdi,rbx
       jmp       near ptr 000000000000D4C7
M03_L24:
       mov       rdi,rbx
       add       ecx,0FFFFFFF8
       jmp       near ptr 000000000000D50E
; Total bytes of code 957
```
```assembly
; Tedd.Voxtree.OctreeChunk.GetChannel(Int32)
       push      rbp
       sub       rsp,70
       lea       rbp,[rsp+70]
       xor       eax,eax
       mov       [rbp+0FFB8],rax
       vxorps    xmm4,xmm4,xmm4
       vmovdqu   ymmword ptr [rbp+0FFC0],ymm4
       vmovdqu   ymmword ptr [rbp+0FFE0],ymm4
       mov       [rbp+10],rcx
       mov       [rbp+18],rdx
       mov       [rbp+20],r8d
       lea       rdx,[rbp+0FFE0]
       mov       rcx,[rbp+10]
       mov       r8d,[rbp+20]
       call      qword ptr [0DBC0]; Tedd.Voxtree.OctreeChunk.GetChannelData(Int32)
       lea       rdx,[rbp+0FFF0]
       lea       rcx,[rbp+0FFE0]
       call      qword ptr [0DB90]; System.ReadOnlyMemory`1[[System.Byte, System.Private.CoreLib]].get_Span()
       mov       rcx,[rbp+10]
       call      qword ptr [0DAE8]; Tedd.Voxtree.OctreeChunk.get_Levels()
       mov       [rbp+0FFDC],eax
       vmovdqu   xmm0,xmmword ptr [rbp+0FFF0]
       vmovdqu   xmmword ptr [rbp+0FFC8],xmm0
       vmovdqu   xmm0,xmmword ptr [rbp+0FFF0]
       vmovdqu   xmmword ptr [rbp+0FFB8],xmm0
       lea       rcx,[rbp+0FFB8]
       call      qword ptr [0D830]; Tedd.Voxtree.OctreeCodec.GetStorageKindUnchecked(System.ReadOnlySpan`1<Byte>)
       mov       [rbp+0FFB4],eax
       mov       r9d,[rbp+0FFB4]
       lea       rdx,[rbp+0FFC8]
       mov       r8d,[rbp+0FFDC]
       mov       rcx,[rbp+18]
       call      qword ptr [0DBD8]; Tedd.Voxtree.OctreeSpan.CreateTrusted(System.ReadOnlySpan`1<Byte>, Int32, Tedd.Voxtree.StorageKind)
       mov       rax,[rbp+18]
       add       rsp,70
       pop       rbp
       ret
; Total bytes of code 152
```
```assembly
; Tedd.Voxtree.OctreeCodec.TryGetUnchecked(System.ReadOnlySpan`1<Byte>, Int32, Tedd.Voxtree.StorageKind, Int32, Int32, Int32, UInt32 ByRef)
       push      rbp
       sub       rsp,130
       lea       rbp,[rsp+130]
       vxorps    xmm4,xmm4,xmm4
       vmovdqa   xmmword ptr [rbp+0FEF0],xmm4
       mov       rax,0FFFFFFFFFF40
M05_L00:
       vmovdqa   xmmword ptr [rbp+rax+0FFC0],xmm4
       vmovdqa   xmmword ptr [rbp+rax+0FFD0],xmm4
       vmovdqa   xmmword ptr [rbp+rax+0FFE0],xmm4
       add       rax,30
       jne       short 0000000000009D46
       mov       [rbp+0FFC0],rax
       mov       [rbp+10],rcx
       mov       [rbp+18],edx
       mov       [rbp+20],r8d
       mov       [rbp+28],r9d
       mov       dword ptr [rbp+0FF38],3E8
       mov       rax,[rbp+40]
       xor       ecx,ecx
       mov       [rax],ecx
       mov       eax,1
       mov       ecx,[rbp+18]
       shlx      eax,eax,ecx
       mov       [rbp+0FFC4],eax
       movzx     eax,byte ptr [rbp+20]
       cmp       eax,1
       jne       short 0000000000009E0A
       mov       dword ptr [rbp+0FFA0],2
       mov       rax,[rbp+10]
       vmovdqu   xmm0,xmmword ptr [rax]
       vmovdqu   xmmword ptr [rbp+0FF20],xmm0
       lea       rcx,[rbp+0FF20]
       lea       rdx,[rbp+0FFA0]
       mov       r8,[rbp+40]
       call      qword ptr [0D650]; Tedd.Voxtree.OctreeCodec.TryReadVarUInt(System.ReadOnlySpan`1<Byte>, Int32 ByRef, UInt32 ByRef)
       test      eax,eax
       je        short 0000000000009DF6
       mov       rcx,7FF83A877FB0
       call      0000000000008420
       mov       eax,[rbp+0FFA0]
       mov       rcx,[rbp+10]
       cmp       eax,[rcx+8]
       sete      al
       movzx     eax,al
       mov       [rbp+0FF34],eax
       jmp       near ptr 000000000000A212
M05_L01:
       mov       rcx,7FF83A877FB4
       call      0000000000008420
       jmp       near ptr 000000000000A207
M05_L02:
       movzx     eax,byte ptr [rbp+20]
       cmp       eax,2
       jne       short 0000000000009E8C
       mov       rcx,7FF83A877FB8
       call      0000000000008420
       mov       eax,[rbp+28]
       imul      eax,[rbp+0FFC4]
       imul      eax,[rbp+0FFC4]
       mov       ecx,[rbp+30]
       imul      ecx,[rbp+0FFC4]
       add       eax,ecx
       add       eax,[rbp+38]
       mov       [rbp+0FF9C],eax
       mov       eax,[rbp+0FF9C]
       lea       eax,[rax*4+2]
       mov       [rbp+0FF98],eax
       lea       rdx,[rbp+0FF40]
       mov       rcx,[rbp+10]
       mov       r8d,[rbp+0FF98]
       mov       r9d,4
       call      qword ptr [6238]; System.ReadOnlySpan`1[[System.Byte, System.Private.CoreLib]].Slice(Int32, Int32)
       vmovdqu   xmm0,xmmword ptr [rbp+0FF40]
       vmovdqu   xmmword ptr [rbp+0FF10],xmm0
       lea       rcx,[rbp+0FF10]
       call      qword ptr [0EC10]; Precode of System.Buffers.Binary.BinaryPrimitives.ReadUInt32LittleEndian(System.ReadOnlySpan`1<Byte>)
       mov       rcx,[rbp+40]
       mov       [rcx],eax
       jmp       near ptr 000000000000A147
M05_L03:
       cmp       dword ptr [rbp+18],0
       je        short 0000000000009EAB
       mov       rax,[rbp+10]
       cmp       dword ptr [rax+8],0C
       jge       short 0000000000009EBF
       mov       rcx,7FF83A877FBC
       call      0000000000008420
M05_L04:
       mov       rcx,7FF83A877FC0
       call      0000000000008420
       jmp       near ptr 000000000000A207
M05_L05:
       mov       rax,[rbp+10]
       mov       [rbp+0FF90],rax
       lea       rdx,[rbp+0FFB0]
       mov       rax,[rbp+0FF90]
       mov       eax,[rax+8]
       lea       r9d,[rax+0FFFF]
       mov       rcx,[rbp+0FF90]
       xor       r8d,r8d
       call      qword ptr [6238]; System.ReadOnlySpan`1[[System.Byte, System.Private.CoreLib]].Slice(Int32, Int32)
       mov       rax,[rbp+10]
       mov       eax,[rax+8]
       dec       eax
       mov       [rbp+0FF54],eax
       mov       rax,[rbp+10]
       mov       eax,[rax+8]
       cmp       [rbp+0FF54],eax
       jae       near ptr 000000000000A222
       mov       rax,[rbp+10]
       mov       rax,[rax]
       mov       ecx,[rbp+0FF54]
       movzx     eax,byte ptr [rax+rcx]
       mov       [rbp+0FFAC],eax
       mov       eax,[rbp+0FFB8]
       sub       eax,[rbp+0FFAC]
       mov       [rbp+0FFA8],eax
       cmp       dword ptr [rbp+0FFAC],9
       jl        short 0000000000009F3D
       cmp       dword ptr [rbp+0FFAC],29
       jle       short 0000000000009F46
       mov       rcx,7FF83A877FC4
       call      0000000000008420
M05_L06:
       mov       dword ptr [rbp+0FF8C],1
       jmp       short 0000000000009F5A
M05_L07:
       mov       rcx,7FF83A877FC8
       call      0000000000008420
       xor       eax,eax
       mov       [rbp+0FF8C],eax
M05_L08:
       cmp       dword ptr [rbp+0FF8C],0
       jne       short 0000000000009F75
       cmp       dword ptr [rbp+0FFA8],2
       jge       short 0000000000009F89
       mov       rcx,7FF83A877FCC
       call      0000000000008420
M05_L09:
       mov       rcx,7FF83A877FD0
       call      0000000000008420
       jmp       near ptr 000000000000A207
M05_L10:
       mov       eax,[rbp+18]
       dec       eax
       mov       [rbp+0FF88],eax
       jmp       near ptr 000000000000A1C6
M05_L11:
       mov       eax,[rbp+0FFA8]
       mov       [rbp+0FF84],eax
       mov       eax,[rbp+0FF84]
       cmp       eax,[rbp+0FFB8]
       jb        short 0000000000009FB8
       mov       rcx,7FF83A877FD4
       call      0000000000008420
       jmp       near ptr 000000000000A207
M05_L12:
       mov       eax,[rbp+0FF84]
       mov       [rbp+0FF78],eax
       mov       eax,[rbp+0FF78]
       mov       [rbp+0FF50],eax
       mov       eax,[rbp+0FF78]
       inc       eax
       mov       [rbp+0FF78],eax
       mov       eax,[rbp+0FFB8]
       cmp       [rbp+0FF50],eax
       jae       near ptr 000000000000A222
       mov       eax,[rbp+0FF50]
       mov       rcx,[rbp+0FFB0]
       movzx     eax,byte ptr [rcx+rax]
       mov       [rbp+0FF74],eax
       mov       eax,[rbp+0FF88]
       sarx      eax,[rbp+28],eax
       and       eax,1
       shl       eax,2
       mov       ecx,[rbp+0FF88]
       sarx      ecx,[rbp+30],ecx
       and       ecx,1
       add       ecx,ecx
       or        eax,ecx
       mov       ecx,[rbp+0FF88]
       sarx      ecx,[rbp+38],ecx
       and       ecx,1
       or        eax,ecx
       mov       [rbp+0FF70],eax
       xor       eax,eax
       mov       [rbp+0FF64],eax
       jmp       short 000000000000A098
M05_L13:
       vmovdqu   xmm0,xmmword ptr [rbp+0FFB0]
       vmovdqu   xmmword ptr [rbp+0FF00],xmm0
       lea       rcx,[rbp+0FF00]
       lea       r8,[rbp+0FF58]
       lea       rdx,[rbp+0FF78]
       call      qword ptr [0D650]; Tedd.Voxtree.OctreeCodec.TryReadVarUInt(System.ReadOnlySpan`1<Byte>, Int32 ByRef, UInt32 ByRef)
       test      eax,eax
       jne       short 000000000000A07B
       mov       rcx,7FF83A877FD8
       call      0000000000008420
       jmp       near ptr 000000000000A207
M05_L14:
       mov       rcx,7FF83A877FDC
       call      0000000000008420
       mov       eax,[rbp+0FF64]
       inc       eax
       mov       [rbp+0FF64],eax
M05_L15:
       mov       eax,[rbp+0FF38]
       dec       eax
       mov       [rbp+0FF38],eax
       cmp       dword ptr [rbp+0FF38],0
       jg        short 000000000000A0C0
       lea       rcx,[rbp+0FF38]
       mov       edx,125
       call      0000000000003990
M05_L16:
       mov       eax,[rbp+0FF64]
       cmp       eax,[rbp+0FF70]
       jl        near ptr 000000000000A03B
       vmovdqu   xmm0,xmmword ptr [rbp+0FFB0]
       vmovdqu   xmmword ptr [rbp+0FEF0],xmm0
       lea       rcx,[rbp+0FEF0]
       lea       r8,[rbp+0FF68]
       lea       rdx,[rbp+0FF78]
       call      qword ptr [0D650]; Tedd.Voxtree.OctreeCodec.TryReadVarUInt(System.ReadOnlySpan`1<Byte>, Int32 ByRef, UInt32 ByRef)
       test      eax,eax
       jne       short 000000000000A112
       mov       rcx,7FF83A877FE0
       call      0000000000008420
       jmp       near ptr 000000000000A207
M05_L17:
       mov       eax,1
       mov       ecx,[rbp+0FF70]
       shlx      eax,eax,ecx
       and       eax,[rbp+0FF74]
       test      eax,eax
       je        short 000000000000A155
       mov       rcx,7FF83A877FE4
       call      0000000000008420
       mov       rax,[rbp+40]
       mov       ecx,[rbp+0FF68]
       mov       [rax],ecx
M05_L18:
       mov       eax,1
       add       rsp,130
       pop       rbp
       ret
M05_L19:
       cmp       dword ptr [rbp+0FF88],0
       je        short 000000000000A181
       cmp       dword ptr [rbp+0FF68],0
       je        short 000000000000A192
       mov       eax,[rbp+0FF84]
       add       eax,0FFFFFFFE
       cmp       [rbp+0FF68],eax
       jbe       short 000000000000A1A3
       mov       rcx,7FF83A877FE8
       call      0000000000008420
M05_L20:
       mov       rcx,7FF83A877FEC
       call      0000000000008420
       jmp       short 000000000000A207
M05_L21:
       mov       rcx,7FF83A877FF0
       call      0000000000008420
       jmp       short 000000000000A181
M05_L22:
       mov       rcx,7FF83A877FF4
       call      0000000000008420
       mov       eax,[rbp+0FF84]
       sub       eax,[rbp+0FF68]
       mov       [rbp+0FFA8],eax
       mov       eax,[rbp+0FF88]
       dec       eax
       mov       [rbp+0FF88],eax
M05_L23:
       mov       eax,[rbp+0FF38]
       dec       eax
       mov       [rbp+0FF38],eax
       cmp       dword ptr [rbp+0FF38],0
       jg        short 000000000000A1EE
       lea       rcx,[rbp+0FF38]
       mov       edx,16A
       call      0000000000003990
M05_L24:
       cmp       dword ptr [rbp+0FF88],0
       jge       near ptr 0000000000009F96
       mov       rcx,7FF83A877FF8
       call      0000000000008420
M05_L25:
       xor       eax,eax
       add       rsp,130
       pop       rbp
       ret
M05_L26:
       movzx     eax,byte ptr [rbp+0FF34]
       add       rsp,130
       pop       rbp
       ret
M05_L27:
       call      0000000000001788
       int       3
; Total bytes of code 1288
```
```assembly
; Tedd.Voxtree.HotOctreeChunk.GetChannelSpan(Int32)
       push      rbp
       sub       rsp,50
       lea       rbp,[rsp+50]
       xor       eax,eax
       mov       [rbp+0FFD8],rax
       vxorps    xmm4,xmm4,xmm4
       vmovdqu   ymmword ptr [rbp+0FFE0],ymm4
       mov       [rbp+10],rcx
       mov       [rbp+18],rdx
       mov       [rbp+20],r8d
       mov       rcx,[rbp+10]
       call      qword ptr [0E688]; Tedd.Voxtree.HotOctreeChunk.GetValues()
       mov       [rbp+0FFF0],rax
       mov       rax,[rbp+0FFF0]
       mov       [rbp+0FFE8],rax
       mov       rcx,[rbp+10]
       call      qword ptr [0E6A0]; Tedd.Voxtree.HotOctreeChunk.get_ChannelCount()
       cmp       eax,[rbp+20]
       ja        short 0000000000008BCE
       mov       rcx,offset MT_System.ArgumentOutOfRangeException
       call      0000000000005240
       mov       [rbp+0FFE0],rax
       mov       ecx,3E1
       mov       rdx,7FF83A852A78
       call      qword ptr [6F28]; Precode of System.String.StrCns(UInt32, IntPtr)
       mov       [rbp+0FFD8],rax
       mov       rdx,[rbp+0FFD8]
       mov       rcx,[rbp+0FFE0]
       call      qword ptr [0D1B8]; Precode of System.ArgumentOutOfRangeException..ctor(System.String)
       mov       rcx,[rbp+0FFE0]
       call      000000000000B8A0
       int       3
M06_L00:
       mov       rcx,[rbp+10]
       call      qword ptr [0E640]; Tedd.Voxtree.HotOctreeChunk.get_Levels()
       mov       ecx,eax
       call      qword ptr [0D1A0]; Tedd.Voxtree.OctreeCodec.GetVoxelCount(Int32)
       mov       [rbp+0FFFC],eax
       mov       eax,[rbp+20]
       mov       r8d,eax
       imul      r8d,[rbp+0FFFC]
       mov       rcx,[rbp+18]
       mov       rdx,[rbp+0FFE8]
       mov       r9d,[rbp+0FFFC]
       call      qword ptr [0E670]; System.MemoryExtensions.AsSpan[[System.UInt32, System.Private.CoreLib]](UInt32[], Int32, Int32)
       mov       rax,[rbp+18]
       add       rsp,50
       pop       rbp
       ret
; Total bytes of code 202
```
```assembly
; Tedd.Voxtree.HotOctreeChunk.get_Levels()
       push      rbp
       mov       rbp,rsp
       mov       [rbp+10],rcx
       mov       rax,[rbp+10]
       mov       eax,[rax+20]
       pop       rbp
       ret
; Total bytes of code 17
```
```assembly
; Tedd.Voxtree.DenseVoxel.GetIndex(Int32, Int32, Int32, Int32, Tedd.Voxtree.DenseVoxelLayout)
       push      rbp
       sub       rsp,40
       lea       rbp,[rsp+40]
       vxorps    xmm4,xmm4,xmm4
       vmovdqu   xmmword ptr [rbp+0FFE8],xmm4
       xor       eax,eax
       mov       [rbp+0FFF8],rax
       mov       [rbp+10],ecx
       mov       [rbp+18],edx
       mov       [rbp+20],r8d
       mov       [rbp+28],r9d
       mov       ecx,[rbp+28]
       call      qword ptr [0D188]; Tedd.Voxtree.OctreeCodec.ValidateLevels(Int32)
       mov       ecx,[rbp+30]
       call      qword ptr [0D080]; Tedd.Voxtree.DenseVoxel.Validate(Tedd.Voxtree.DenseVoxelLayout)
       mov       eax,1
       mov       ecx,[rbp+28]
       shlx      eax,eax,ecx
       mov       [rbp+0FFFC],eax
       mov       eax,[rbp+10]
       cmp       eax,[rbp+0FFFC]
       jae       short 0000000000008DC0
       mov       eax,[rbp+18]
       cmp       eax,[rbp+0FFFC]
       jae       short 0000000000008E04
       mov       eax,[rbp+20]
       cmp       eax,[rbp+0FFFC]
       jb        short 0000000000008E15
       mov       rcx,7FF83A941A80
       call      0000000000008420
M08_L00:
       mov       rcx,offset MT_System.ArgumentOutOfRangeException
       call      0000000000005240
       mov       [rbp+0FFF0],rax
       mov       ecx,3F1
       mov       rdx,7FF83A852A78
       call      qword ptr [6F28]; Precode of System.String.StrCns(UInt32, IntPtr)
       mov       [rbp+0FFE8],rax
       mov       rdx,[rbp+0FFE8]
       mov       rcx,[rbp+0FFF0]
       call      qword ptr [0D1B8]; Precode of System.ArgumentOutOfRangeException..ctor(System.String)
       mov       rcx,[rbp+0FFF0]
       call      000000000000B8A0
       int       3
M08_L01:
       mov       rcx,7FF83A941A84
       call      0000000000008420
       jmp       short 0000000000008DC0
M08_L02:
       mov       rcx,7FF83A941A88
       call      0000000000008420
       mov       eax,[rbp+30]
       mov       [rsp+20],eax
       mov       ecx,[rbp+10]
       mov       edx,[rbp+18]
       mov       r8d,[rbp+20]
       mov       r9d,[rbp+0FFFC]
       call      qword ptr [0E6B8]; Tedd.Voxtree.DenseVoxel.Index(Int32, Int32, Int32, Int32, Tedd.Voxtree.DenseVoxelLayout)
       nop
       add       rsp,40
       pop       rbp
       ret
; Total bytes of code 246
```
```assembly
; Tedd.Voxtree.OctreeChunk.GetChannelData(Int32)
       push      rbp
       sub       rsp,30
       lea       rbp,[rsp+30]
       xor       eax,eax
       mov       [rbp+0FFF8],rax
       mov       [rbp+0FFF0],rax
       mov       [rbp+10],rcx
       mov       [rbp+18],rdx
       mov       [rbp+20],r8d
       mov       rcx,[rbp+10]
       call      qword ptr [0DB00]; Tedd.Voxtree.OctreeChunk.get_ChannelCount()
       cmp       eax,[rbp+20]
       ja        short 0000000000009A73
       mov       rcx,offset MT_System.ArgumentOutOfRangeException
       call      0000000000005240
       mov       [rbp+0FFF8],rax
       mov       ecx,3E1
       mov       rdx,7FF83A852A78
       call      qword ptr [6F28]; Precode of System.String.StrCns(UInt32, IntPtr)
       mov       [rbp+0FFF0],rax
       mov       rdx,[rbp+0FFF0]
       mov       rcx,[rbp+0FFF8]
       call      qword ptr [0D1B8]; Precode of System.ArgumentOutOfRangeException..ctor(System.String)
       mov       rcx,[rbp+0FFF8]
       call      000000000000B8A0
       int       3
M09_L00:
       mov       rax,[rbp+10]
       mov       rax,[rax+8]
       mov       ecx,[rbp+20]
       cmp       ecx,[rax+8]
       jae       short 0000000000009AA4
       mov       edx,ecx
       imul      rdx,10
       lea       rax,[rax+rdx+10]
       mov       rcx,[rbp+18]
       vmovdqu   xmm0,xmmword ptr [rax]
       vmovdqu   xmmword ptr [rcx],xmm0
       mov       rax,[rbp+18]
       add       rsp,30
       pop       rbp
       ret
M09_L01:
       call      0000000000001788
       int       3
; Total bytes of code 170
```
```assembly
; System.ReadOnlyMemory`1[[System.Byte, System.Private.CoreLib]].get_Span()
       push      r14
       push      rdi
       push      rsi
       push      rbp
       push      rbx
       sub       rsp,30
       xor       eax,eax
       mov       [rsp+20],rax
       mov       rsi,rcx
       mov       rbx,rdx
       xor       edi,edi
       xor       ebp,ebp
       mov       r14,[rsi]
       test      r14,r14
       je        short 0000000000009875
       mov       rcx,[r14]
       test      dword ptr [rcx],80000000
       je        short 0000000000009898
       lea       rdi,[r14+10]
       mov       ebp,[r14+8]
M10_L00:
       mov       ecx,[rsi+8]
       and       ecx,7FFFFFFF
       mov       r14d,ecx
       mov       esi,[rsi+0C]
       mov       ecx,esi
       add       rcx,r14
       mov       eax,ebp
       cmp       rcx,rax
       ja        short 00000000000098D9
       mov       rcx,7FF83A941F24
       call      0000000000008420
       add       rdi,r14
       mov       ebp,esi
M10_L01:
       mov       rcx,7FF83A941F28
       call      0000000000008420
       mov       [rbx],rdi
       mov       [rbx+8],ebp
       mov       rax,rbx
       add       rsp,30
       pop       rbx
       pop       rbp
       pop       rsi
       pop       rdi
       pop       r14
       ret
M10_L02:
       mov       rcx,7FF83A941E10
       call      0000000000008420
       mov       rcx,r14
       mov       rdx,7FF83A941E18
       call      0000000000004AB0
       mov       rcx,r14
       lea       rdx,[rsp+20]
       mov       rax,[r14]
       mov       rax,[rax+40]
       call      qword ptr [rax+28]
       mov       ebp,[rsp+28]
       mov       rdi,[rsp+20]
       jmp       near ptr 0000000000009846
M10_L03:
       mov       rcx,7FF83A941F20
       call      0000000000008420
       call      qword ptr [7C30]; Precode of System.ThrowHelper.ThrowArgumentOutOfRangeException()
       int       3
; Total bytes of code 223
```
```assembly
; Tedd.Voxtree.OctreeChunk.get_Levels()
       mov       eax,[rcx+10]
       ret
; Total bytes of code 4
```
```assembly
; Tedd.Voxtree.OctreeCodec.GetStorageKindUnchecked(System.ReadOnlySpan`1<Byte>)
       push      rbp
       sub       rsp,20
       lea       rbp,[rsp+20]
       mov       [rbp+10],rcx
       mov       rax,[rbp+10]
       cmp       dword ptr [rax+8],1
       jbe       short 00000000000097EC
       mov       rax,[rbp+10]
       mov       rax,[rax]
       movzx     eax,byte ptr [rax+1]
       and       eax,3
       add       rsp,20
       pop       rbp
       ret
M12_L00:
       call      0000000000001788
       int       3
; Total bytes of code 50
```
```assembly
; Tedd.Voxtree.OctreeSpan.CreateTrusted(System.ReadOnlySpan`1<Byte>, Int32, Tedd.Voxtree.StorageKind)
       push      rbp
       sub       rsp,50
       lea       rbp,[rsp+50]
       xor       eax,eax
       mov       [rbp+0FFD8],rax
       vxorps    xmm4,xmm4,xmm4
       vmovdqu   ymmword ptr [rbp+0FFE0],ymm4
       mov       [rbp+10],rcx
       mov       [rbp+18],rdx
       mov       [rbp+20],r8d
       mov       [rbp+28],r9d
       mov       rax,[rbp+18]
       vmovdqu   xmm0,xmmword ptr [rax]
       vmovdqu   xmmword ptr [rbp+0FFD8],xmm0
       lea       rdx,[rbp+0FFD8]
       movzx     r9d,byte ptr [rbp+28]
       lea       rcx,[rbp+0FFE8]
       mov       r8d,[rbp+20]
       call      qword ptr [0DBF0]; Tedd.Voxtree.OctreeSpan..ctor(System.ReadOnlySpan`1<Byte>, Int32, Tedd.Voxtree.StorageKind)
       mov       rax,[rbp+10]
       vmovdqu   xmm0,xmmword ptr [rbp+0FFE8]
       vmovdqu   xmmword ptr [rax],xmm0
       mov       rcx,[rbp+0FFF8]
       mov       [rax+10],rcx
       mov       rax,[rbp+10]
       add       rsp,50
       pop       rbp
       ret
; Total bytes of code 108
```
```assembly
; Tedd.Voxtree.OctreeCodec.TryReadVarUInt(System.ReadOnlySpan`1<Byte>, Int32 ByRef, UInt32 ByRef)
       push      rbp
       sub       rsp,80
       lea       rbp,[rsp+80]
       vxorps    xmm4,xmm4,xmm4
       vmovdqu   xmmword ptr [rbp+0FFB8],xmm4
       mov       [rbp+10],rcx
       mov       [rbp+18],rdx
       mov       [rbp+20],r8
       mov       dword ptr [rbp+0FFB0],3E8
       mov       rax,[rbp+20]
       xor       ecx,ecx
       mov       [rax],ecx
       mov       rax,[rbp+18]
       mov       eax,[rax]
       mov       [rbp+0FFC4],eax
       xor       eax,eax
       mov       [rbp+0FFC0],eax
       jmp       near ptr 00000000000076E9
M14_L00:
       mov       rax,[rbp+18]
       mov       eax,[rax]
       mov       rcx,[rbp+10]
       cmp       eax,[rcx+8]
       jb        short 00000000000075FA
       mov       rcx,7FF83A85F180
       call      0000000000008420
       jmp       near ptr 000000000000771E
M14_L01:
       mov       rax,[rbp+18]
       mov       eax,[rax]
       mov       [rbp+0FFB8],eax
       mov       eax,[rbp+0FFB8]
       inc       eax
       mov       rcx,[rbp+18]
       mov       [rcx],eax
       mov       rax,[rbp+10]
       mov       eax,[rax+8]
       cmp       [rbp+0FFB8],eax
       jae       near ptr 0000000000007736
       mov       rax,[rbp+10]
       mov       rax,[rax]
       mov       ecx,[rbp+0FFB8]
       movzx     eax,byte ptr [rax+rcx]
       mov       [rbp+0FFBC],eax
       cmp       dword ptr [rbp+0FFC0],1C
       jne       short 0000000000007664
       mov       eax,[rbp+0FFBC]
       and       eax,0F0
       test      eax,eax
       je        short 0000000000007655
       mov       rcx,7FF83A85F184
       call      0000000000008420
       jmp       near ptr 000000000000771E
M14_L02:
       mov       rcx,7FF83A85F188
       call      0000000000008420
M14_L03:
       mov       eax,[rbp+0FFBC]
       and       eax,7F
       mov       ecx,[rbp+0FFC0]
       shlx      eax,eax,ecx
       mov       rcx,[rbp+20]
       or        [rcx],eax
       mov       eax,[rbp+0FFBC]
       and       eax,80
       test      eax,eax
       jne       short 00000000000076D1
       mov       rax,[rbp+18]
       mov       eax,[rax]
       sub       eax,[rbp+0FFC4]
       cmp       eax,1
       je        short 00000000000076B4
       mov       rcx,7FF83A85F18C
       call      0000000000008420
       mov       eax,[rbp+0FFBC]
       and       eax,7F
       test      eax,eax
       setne     al
       movzx     eax,al
       mov       [rbp+0FFAC],eax
       jmp       short 0000000000007729
M14_L04:
       mov       rcx,7FF83A85F190
       call      0000000000008420
       mov       eax,1
       add       rsp,80
       pop       rbp
       ret
M14_L05:
       mov       rcx,7FF83A85F194
       call      0000000000008420
       mov       eax,[rbp+0FFC0]
       add       eax,7
       mov       [rbp+0FFC0],eax
M14_L06:
       mov       eax,[rbp+0FFB0]
       dec       eax
       mov       [rbp+0FFB0],eax
       cmp       dword ptr [rbp+0FFB0],0
       jg        short 0000000000007705
       lea       rcx,[rbp+0FFB0]
       mov       edx,65
       call      0000000000003990
M14_L07:
       cmp       dword ptr [rbp+0FFC0],1C
       jle       near ptr 00000000000075D7
       mov       rcx,7FF83A85F198
       call      0000000000008420
M14_L08:
       xor       eax,eax
       add       rsp,80
       pop       rbp
       ret
M14_L09:
       movzx     eax,byte ptr [rbp+0FFAC]
       add       rsp,80
       pop       rbp
       ret
M14_L10:
       call      0000000000001788
       int       3
; Total bytes of code 428
```
```assembly
; System.ReadOnlySpan`1[[System.Byte, System.Private.CoreLib]].Slice(Int32, Int32)
       push      rdi
       push      rsi
       push      rbp
       push      rbx
       sub       rsp,28
       mov       rsi,rcx
       mov       rbx,rdx
       mov       edi,r8d
       mov       ebp,r9d
       mov       ecx,edi
       mov       eax,ebp
       add       rcx,rax
       mov       eax,[rsi+8]
       cmp       rcx,rax
       ja        short 0000000000009789
       mov       rcx,7FF83A941DBC
       call      0000000000008420
       mov       eax,edi
       add       rax,[rsi]
       mov       [rbx],rax
       mov       [rbx+8],ebp
       mov       rax,rbx
       add       rsp,28
       pop       rbx
       pop       rbp
       pop       rsi
       pop       rdi
       ret
M15_L00:
       mov       rcx,7FF83A941DB8
       call      0000000000008420
       call      qword ptr [7C30]; Precode of System.ThrowHelper.ThrowArgumentOutOfRangeException()
       int       3
; Total bytes of code 95
```
```assembly
; Tedd.Voxtree.HotOctreeChunk.GetValues()
       push      rbp
       sub       rsp,40
       lea       rbp,[rsp+40]
       vxorps    xmm4,xmm4,xmm4
       vmovdqu   ymmword ptr [rbp+0FFE0],ymm4
       mov       [rbp+10],rcx
       mov       rax,[rbp+10]
       mov       rax,[rax+8]
       mov       [rbp+0FFF8],rax
       mov       rax,[rbp+0FFF8]
       mov       [rbp+0FFF0],rax
       cmp       qword ptr [rbp+0FFF8],0
       jne       short 0000000000008C96
       mov       rcx,offset MT_System.InvalidOperationException
       call      0000000000005240
       mov       [rbp+0FFE8],rax
       mov       ecx,9F3
       mov       rdx,7FF83A852A78
       call      qword ptr [6F28]; Precode of System.String.StrCns(UInt32, IntPtr)
       mov       [rbp+0FFE0],rax
       mov       rdx,[rbp+0FFE0]
       mov       rcx,[rbp+0FFE8]
       call      qword ptr [6688]; Precode of System.InvalidOperationException..ctor(System.String)
       mov       rcx,[rbp+0FFE8]
       call      000000000000B8A0
       int       3
M16_L00:
       mov       rax,[rbp+0FFF0]
       add       rsp,40
       pop       rbp
       ret
; Total bytes of code 128
```
```assembly
; Tedd.Voxtree.HotOctreeChunk.get_ChannelCount()
       push      rbp
       mov       rbp,rsp
       mov       [rbp+10],rcx
       mov       rax,[rbp+10]
       mov       eax,[rax+24]
       pop       rbp
       ret
; Total bytes of code 17
```
```assembly
; Tedd.Voxtree.OctreeCodec.GetVoxelCount(Int32)
       push      rbp
       mov       rbp,rsp
       mov       [rbp+10],ecx
       mov       eax,1
       mov       ecx,[rbp+10]
       lea       ecx,[rcx+rcx*2]
       shlx      eax,eax,ecx
       pop       rbp
       ret
; Total bytes of code 25
```
```assembly
; System.MemoryExtensions.AsSpan[[System.UInt32, System.Private.CoreLib]](UInt32[], Int32, Int32)
       sub       rsp,28
       test      rdx,rdx
       je        short 0000000000008D1F
       mov       r8d,r8d
       mov       eax,r9d
       add       rax,r8
       mov       r10d,[rdx+8]
       cmp       rax,r10
       ja        short 0000000000008D2B
       lea       rax,[rdx+r8*4+10]
M19_L00:
       mov       [rcx],rax
       mov       [rcx+8],r9d
       mov       rax,rcx
       add       rsp,28
       ret
M19_L01:
       or        r8d,r9d
       jne       short 0000000000008D2B
       xor       eax,eax
       xor       r9d,r9d
       jmp       short 0000000000008D10
M19_L02:
       call      qword ptr [7C30]; Precode of System.ThrowHelper.ThrowArgumentOutOfRangeException()
       int       3
; Total bytes of code 66
```
```assembly
; Tedd.Voxtree.OctreeCodec.ValidateLevels(Int32)
       push      rbp
       sub       rsp,80
       lea       rbp,[rsp+80]
       xor       eax,eax
       mov       [rbp+0FFA8],rax
       vxorps    xmm4,xmm4,xmm4
       vmovdqu   ymmword ptr [rbp+0FFB0],ymm4
       vmovdqu   ymmword ptr [rbp+0FFD0],ymm4
       vmovdqa   xmmword ptr [rbp+0FFF0],xmm4
       mov       [rbp+10],ecx
       cmp       dword ptr [rbp+10],9
       jbe       near ptr 0000000000007F9F
       mov       rcx,offset MT_System.Int32
       call      0000000000005240
       mov       [rbp+0FFD0],rax
       mov       rax,[rbp+0FFD0]
       mov       ecx,[rbp+10]
       mov       [rax+8],ecx
       lea       rcx,[rbp+0FFD8]
       mov       edx,31
       mov       r8d,1
       call      qword ptr [67C0]; System.Runtime.CompilerServices.DefaultInterpolatedStringHandler..ctor(Int32, Int32)
       mov       ecx,1341
       mov       rdx,7FF83A852A78
       call      qword ptr [6F28]; Precode of System.String.StrCns(UInt32, IntPtr)
       mov       [rbp+0FFC0],rax
       mov       rdx,[rbp+0FFC0]
       lea       rcx,[rbp+0FFD8]
       call      qword ptr [6C28]; System.Runtime.CompilerServices.DefaultInterpolatedStringHandler.AppendLiteral(System.String)
       lea       rcx,[rbp+0FFD8]
       mov       edx,9
       call      qword ptr [6AF0]; System.Runtime.CompilerServices.DefaultInterpolatedStringHandler.AppendFormatted[[System.Int32, System.Private.CoreLib]](Int32)
       mov       ecx,369
       mov       rdx,7FF83A852A78
       call      qword ptr [6F28]; Precode of System.String.StrCns(UInt32, IntPtr)
       mov       [rbp+0FFB8],rax
       mov       rdx,[rbp+0FFB8]
       lea       rcx,[rbp+0FFD8]
       call      qword ptr [6C28]; System.Runtime.CompilerServices.DefaultInterpolatedStringHandler.AppendLiteral(System.String)
       mov       rcx,offset MT_System.ArgumentOutOfRangeException
       call      0000000000005240
       mov       [rbp+0FFC8],rax
       mov       ecx,1333
       mov       rdx,7FF83A852A78
       call      qword ptr [6F28]; Precode of System.String.StrCns(UInt32, IntPtr)
       mov       [rbp+0FFB0],rax
       lea       rcx,[rbp+0FFD8]
       call      qword ptr [67F0]; System.Runtime.CompilerServices.DefaultInterpolatedStringHandler.ToStringAndClear()
       mov       [rbp+0FFA8],rax
       mov       rdx,[rbp+0FFB0]
       mov       r9,[rbp+0FFA8]
       mov       r8,[rbp+0FFD0]
       mov       rcx,[rbp+0FFC8]
       call      qword ptr [7ED0]; Precode of System.ArgumentOutOfRangeException..ctor(System.String, System.Object, System.String)
       mov       rcx,[rbp+0FFC8]
       call      000000000000B8A0
       int       3
M20_L00:
       add       rsp,80
       pop       rbp
       ret
; Total bytes of code 296
```
```assembly
; Tedd.Voxtree.DenseVoxel.Validate(Tedd.Voxtree.DenseVoxelLayout)
       push      rbp
       sub       rsp,30
       lea       rbp,[rsp+30]
       xor       eax,eax
       mov       [rbp+0FFF8],rax
       mov       [rbp+0FFF0],rax
       mov       [rbp+10],ecx
       cmp       dword ptr [rbp+10],0
       je        short 0000000000008036
       cmp       dword ptr [rbp+10],1
       je        short 0000000000008027
       mov       rcx,offset MT_System.ArgumentOutOfRangeException
       call      0000000000005240
       mov       [rbp+0FFF8],rax
       mov       ecx,4B5
       mov       rdx,7FF83A852A78
       call      qword ptr [6F28]; Precode of System.String.StrCns(UInt32, IntPtr)
       mov       [rbp+0FFF0],rax
       mov       rdx,[rbp+0FFF0]
       mov       rcx,[rbp+0FFF8]
       call      qword ptr [0D1B8]; Precode of System.ArgumentOutOfRangeException..ctor(System.String)
       mov       rcx,[rbp+0FFF8]
       call      000000000000B8A0
       int       3
M21_L00:
       mov       rcx,7FF83A941810
       call      0000000000008420
M21_L01:
       mov       rcx,7FF83A941814
       call      0000000000008420
       nop
       add       rsp,30
       pop       rbp
       ret
; Total bytes of code 140
```
```assembly
; Tedd.Voxtree.DenseVoxel.Index(Int32, Int32, Int32, Int32, Tedd.Voxtree.DenseVoxelLayout)
       push      rbp
       sub       rsp,20
       lea       rbp,[rsp+20]
       mov       [rbp+10],ecx
       mov       [rbp+18],edx
       mov       [rbp+20],r8d
       mov       [rbp+28],r9d
       cmp       dword ptr [rbp+30],0
       je        short 0000000000008EA4
       mov       rcx,7FF83A941AC0
       call      0000000000008420
       mov       ecx,[rbp+10]
       mov       edx,[rbp+18]
       mov       r8d,[rbp+20]
       call      qword ptr [0E6D0]; Tedd.MortonEncoding.Encode(UInt32, UInt32, UInt32)
       nop
       add       rsp,20
       pop       rbp
       ret
M22_L00:
       mov       rcx,7FF83A941AC4
       call      0000000000008420
       mov       eax,[rbp+10]
       imul      eax,[rbp+28]
       add       eax,[rbp+18]
       imul      eax,[rbp+28]
       add       eax,[rbp+20]
       add       rsp,20
       pop       rbp
       ret
; Total bytes of code 106
```
```assembly
; Tedd.Voxtree.OctreeChunk.get_ChannelCount()
       mov       rax,[rcx+8]
       mov       eax,[rax+8]
       ret
; Total bytes of code 8
```
```assembly
; Tedd.Voxtree.OctreeSpan..ctor(System.ReadOnlySpan`1<Byte>, Int32, Tedd.Voxtree.StorageKind)
       push      rbp
       mov       rbp,rsp
       mov       [rbp+10],rcx
       mov       [rbp+18],rdx
       mov       [rbp+20],r8d
       mov       [rbp+28],r9d
       mov       rax,[rbp+18]
       mov       rcx,[rbp+10]
       vmovdqu   xmm0,xmmword ptr [rax]
       vmovdqu   xmmword ptr [rcx],xmm0
       mov       rax,[rbp+10]
       mov       ecx,[rbp+20]
       mov       [rax+10],ecx
       mov       rax,[rbp+10]
       mov       ecx,[rbp+28]
       mov       [rax+14],cl
       pop       rbp
       ret
; Total bytes of code 58
```
```assembly
; System.Runtime.CompilerServices.DefaultInterpolatedStringHandler..ctor(Int32, Int32)
       push      rdi
       push      rsi
       push      rbx
       sub       rsp,20
       mov       rbx,rcx
       mov       esi,edx
       mov       edi,r8d
       xor       eax,eax
       mov       [rbx],rax
       call      qword ptr [0A098]
       mov       rcx,[rax]
       imul      edx,edi,0B
       add       edx,esi
       mov       eax,100
       cmp       edx,100
       cmovle    edx,eax
       cmp       [rcx],ecx
       call      qword ptr [98B8]; Precode of System.Buffers.SharedArrayPool`1[[System.Char, System.Private.CoreLib]].Rent(Int32)
       mov       [rbx+8],rax
       test      rax,rax
       je        short 000000000000C4E0
       lea       rcx,[rax+10]
       mov       eax,[rax+8]
M25_L00:
       mov       [rbx+18],rcx
       mov       [rbx+20],eax
       xor       eax,eax
       mov       [rbx+10],eax
       mov       byte ptr [rbx+14],0
       add       rsp,20
       pop       rbx
       pop       rsi
       pop       rdi
       ret
M25_L01:
       xor       ecx,ecx
       xor       eax,eax
       jmp       short 000000000000C4C8
; Total bytes of code 102
```
```assembly
; System.Runtime.CompilerServices.DefaultInterpolatedStringHandler.AppendLiteral(System.String)
       push      rdi
       push      rsi
       push      rbx
       sub       rsp,20
       mov       rbx,rcx
       mov       rsi,rdx
       lea       r8,[rbx+18]
       mov       edx,[rbx+10]
       mov       ecx,[r8+8]
       cmp       edx,ecx
       ja        short 00000000000040DB
       mov       r8,[r8]
       mov       eax,edx
       lea       rax,[r8+rax*2]
       sub       ecx,edx
       mov       edi,[rsi+8]
       cmp       edi,ecx
       ja        short 00000000000040E2
       mov       r8d,edi
       add       r8,r8
       lea       rdx,[rsi+0C]
       mov       rcx,rax
       call      qword ptr [5818]; System.SpanHelpers.Memmove(Byte ByRef, Byte ByRef, UIntPtr)
       mov       rcx,7FF83A802550
       call      0000000000008420
       add       [rbx+10],edi
       add       rsp,20
       pop       rbx
       pop       rsi
       pop       rdi
       ret
M26_L00:
       call      qword ptr [7C30]; Precode of System.ThrowHelper.ThrowArgumentOutOfRangeException()
       int       3
M26_L01:
       mov       rcx,7FF83A802554
       call      0000000000008420
       mov       rcx,rbx
       mov       rdx,rsi
       add       rsp,20
       pop       rbx
       pop       rsi
       pop       rdi
       jmp       qword ptr [67D8]; Precode of System.Runtime.CompilerServices.DefaultInterpolatedStringHandler.GrowThenCopyString(System.String)
; Total bytes of code 132
```
```assembly
; System.Runtime.CompilerServices.DefaultInterpolatedStringHandler.AppendFormatted[[System.Int32, System.Private.CoreLib]](Int32)
       push      rdi
       push      rsi
       push      rbp
       push      rbx
       sub       rsp,58
       xorps     xmm4,xmm4
       movaps    [rsp+30],xmm4
       movaps    [rsp+40],xmm4
       mov       rbx,rcx
       mov       esi,edx
       cmp       byte ptr [rbx+14],0
       jne       short 000000000000F15B
M27_L00:
       lea       rdx,[rbx+18]
       mov       r8d,[rbx+10]
       mov       edi,[rdx+8]
       cmp       r8d,edi
       ja        near ptr 000000000000F1D8
       mov       rdx,[rdx]
       mov       ecx,r8d
       lea       rbp,[rdx+rcx*2]
       sub       edi,r8d
       mov       rcx,[rbx]
       test      esi,esi
       jl        short 000000000000F173
       mov       [rsp+40],rbp
       mov       [rsp+48],edi
       lea       rdx,[rsp+40]
       lea       r8,[rsp+50]
       mov       ecx,esi
       call      qword ptr [0CF8]; Precode of System.Number.TryUInt32ToDecStr[[System.Char, System.Private.CoreLib]](UInt32, System.Span`1<Char>, Int32 ByRef)
M27_L01:
       test      eax,eax
       jne       short 000000000000F152
       mov       rcx,rbx
       call      qword ptr [4FF8]
       jmp       short 000000000000F100
M27_L02:
       mov       eax,[rsp+50]
       add       [rbx+10],eax
       jmp       short 000000000000F169
M27_L03:
       mov       rcx,rbx
       mov       edx,esi
       xor       r8d,r8d
       call      qword ptr [1B50]
M27_L04:
       nop
       add       rsp,58
       pop       rbx
       pop       rbp
       pop       rsi
       pop       rdi
       ret
M27_L05:
       test      rcx,rcx
       je        short 000000000000F180
       call      qword ptr [1260]; Precode of System.Globalization.NumberFormatInfo.<GetInstance>g__GetProviderNonNull|58_0(System.IFormatProvider)
       jmp       short 000000000000F186
M27_L06:
       call      qword ptr [1248]; Precode of System.Globalization.NumberFormatInfo.get_CurrentInfo()
M27_L07:
       mov       r8,[rax+28]
       test      r8,r8
       jne       short 000000000000F197
       xor       r9d,r9d
       xor       r8d,r8d
       jmp       short 000000000000F19F
M27_L08:
       lea       r9,[r8+0C]
       mov       r8d,[r8+8]
M27_L09:
       mov       [rsp+30],r9
       mov       [rsp+38],r8d
       mov       [rsp+40],rbp
       mov       [rsp+48],edi
       lea       r8,[rsp+50]
       mov       [rsp+20],r8
       lea       r8,[rsp+30]
       lea       r9,[rsp+40]
       mov       ecx,esi
       mov       edx,0FFFFFFFF
       call      qword ptr [0CE0]
       jmp       near ptr 000000000000F143
M27_L10:
       call      qword ptr [0F2B8]
       int       3
; Total bytes of code 255
```
```assembly
; System.Runtime.CompilerServices.DefaultInterpolatedStringHandler.ToStringAndClear()
       push      rdi
       push      rsi
       push      rbp
       push      rbx
       sub       rsp,38
       xor       eax,eax
       mov       [rsp+28],rax
       mov       rbx,rcx
       lea       rsi,[rbx+18]
       mov       rcx,rsi
       mov       eax,[rbx+10]
       cmp       eax,[rcx+8]
       ja        short 000000000000C6F7
       mov       rcx,[rcx]
       mov       [rsp+28],rcx
       mov       [rsp+30],eax
       lea       rcx,[rsp+28]
       call      qword ptr [0BB28]; Precode of System.String.Ctor(System.ReadOnlySpan`1<Char>)
       mov       rdi,rax
       mov       rbp,[rbx+8]
       xor       eax,eax
       mov       [rbx+8],rax
       mov       [rsi],rax
       mov       [rsi+8],rax
       mov       [rbx+10],eax
       test      rbp,rbp
       je        short 000000000000C6EB
       call      qword ptr [0A098]
       mov       rcx,[rax]
       mov       rdx,rbp
       xor       r8d,r8d
       cmp       [rcx],ecx
       call      qword ptr [98C0]; Precode of System.Buffers.SharedArrayPool`1[[System.Char, System.Private.CoreLib]].Return(Char[], Boolean)
M28_L00:
       mov       rax,rdi
       add       rsp,38
       pop       rbx
       pop       rbp
       pop       rsi
       pop       rdi
       ret
M28_L01:
       call      qword ptr [0F2B8]
       int       3
; Total bytes of code 126
```
```assembly
; Tedd.MortonEncoding.Encode(UInt32, UInt32, UInt32)
       push      rbp
       mov       rbp,rsp
       mov       [rbp+10],ecx
       mov       [rbp+18],edx
       mov       [rbp+20],r8d
       mov       eax,[rbp+20]
       mov       ecx,24924924
       pdep      eax,eax,ecx
       mov       ecx,[rbp+18]
       mov       edx,12492492
       pdep      ecx,ecx,edx
       or        eax,ecx
       mov       ecx,[rbp+10]
       mov       edx,9249249
       pdep      ecx,ecx,edx
       or        eax,ecx
       pop       rbp
       ret
; Total bytes of code 59
```
**Method was not JITted yet.**
Tedd.Voxtree.OctreeThrowHelper.ThrowInvalidView()
Tedd.Voxtree.OctreeThrowHelper.ThrowCoordinate(System.String, Int32)
Tedd.Voxtree.OctreeThrowHelper.ThrowMalformed()
System.String.StrCns(UInt32, IntPtr)
System.ObjectDisposedException..ctor(System.String)
System.ArgumentOutOfRangeException..ctor(System.String)
System.ThrowHelper.ThrowArgumentOutOfRangeException()
System.Buffers.Binary.BinaryPrimitives.ReadUInt32LittleEndian(System.ReadOnlySpan`1<Byte>)
System.InvalidOperationException..ctor(System.String)
System.ArgumentOutOfRangeException..ctor(System.String, System.Object, System.String)

## .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v3 (Job: Job-GJBZFV(IterationCount=7, IterationTime=150ms, LaunchCount=1, WarmupCount=3))

```assembly
; Tedd.Voxtree.Benchmark.Tests.DeferredChunkReads.DeferredMisses()
       push      r15
       push      r14
       push      r13
       push      r12
       push      rdi
       push      rsi
       push      rbp
       push      rbx
       sub       rsp,98
       vxorps    xmm4,xmm4,xmm4
       vmovdqu   ymmword ptr [rsp+40],ymm4
       vmovdqu   ymmword ptr [rsp+60],ymm4
       vmovdqa   xmmword ptr [rsp+80],xmm4
       mov       rbx,rcx
       mov       rsi,[rbx+28]
       xor       edi,edi
       xor       ebp,ebp
       jmp       near ptr 000000000000A705
M00_L00:
       mov       r10,[rsp+38]
M00_L01:
       mov       r9d,0FFFFFFFF
M00_L02:
       test      r9d,r9d
       jge       near ptr 000000000000A960
M00_L03:
       mov       r15,[r15+8]
       mov       rdx,[r15+8]
       cmp       [rdx+8],eax
       jbe       near ptr 000000000000AAF2
       cmp       eax,[rdx+8]
       jae       near ptr 000000000000AB35
       mov       ecx,eax
       shl       rcx,4
       lea       rdx,[rdx+rcx+10]
       mov       rcx,[rdx]
       mov       eax,[rdx+8]
       mov       [rsp+54],eax
       mov       r8d,[rdx+0C]
       mov       [rsp+50],r8d
       xor       r10d,r10d
       xor       r9d,r9d
       test      rcx,rcx
       je        short 000000000000A633
       mov       r10,[rcx]
       test      dword ptr [r10],80000000
       je        near ptr 000000000000A9C1
       lea       r10,[rcx+10]
       mov       r9d,[rcx+8]
M00_L04:
       mov       eax,[rsp+54]
       and       eax,7FFFFFFF
       mov       ecx,eax
       mov       r8d,[rsp+50]
       mov       eax,r8d
       add       rax,rcx
       mov       r9d,r9d
       cmp       rax,r9
       ja        near ptr 000000000000AB2E
       add       r10,rcx
       mov       r9d,r8d
M00_L05:
       mov       rcx,r10
       mov       eax,[r15+10]
       cmp       r9d,1
       jbe       near ptr 000000000000AB35
       movzx     edx,byte ptr [rcx+1]
       and       edx,3
       mov       [rsp+78],rcx
       mov       [rsp+80],r9d
       mov       [rsp+88],eax
       mov       [rsp+8C],dl
       xor       ecx,ecx
       mov       [rsp+58],ecx
       lea       rcx,[rsp+78]
       call      qword ptr [0D608]; Tedd.Voxtree.OctreeSpan.get_IsValid()
       test      eax,eax
       je        near ptr 000000000000A9E0
       mov       ecx,[rsp+88]
       mov       edx,1
       shlx      ecx,edx,ecx
       cmp       r13d,ecx
       jae       near ptr 000000000000A9EB
       cmp       r12d,ecx
       jae       near ptr 000000000000AA03
       cmp       r14d,ecx
       jae       near ptr 000000000000AA1B
       vmovdqu   xmm0,xmmword ptr [rsp+78]
       vmovdqu   xmmword ptr [rsp+40],xmm0
       mov       [rsp+20],r12d
       mov       [rsp+28],r14d
       lea       rcx,[rsp+58]
       mov       [rsp+30],rcx
       lea       rcx,[rsp+40]
       mov       edx,[rsp+88]
       movzx     r8d,byte ptr [rsp+8C]
       mov       r9d,r13d
       call      qword ptr [0E6D0]; Tedd.Voxtree.OctreeCodec.TryGetUnchecked(System.ReadOnlySpan`1<Byte>, Int32, Tedd.Voxtree.StorageKind, Int32, Int32, Int32, UInt32 ByRef)
       test      eax,eax
       je        near ptr 000000000000AA33
       mov       eax,[rsp+58]
M00_L06:
       add       edi,eax
       inc       ebp
       cmp       ebp,100
       jge       near ptr 000000000000A80D
M00_L07:
       cmp       ebp,[rsi+8]
       jae       near ptr 000000000000AB35
       mov       r14d,[rsi+rbp*4+10]
       mov       r15,[rbx+18]
       mov       r13d,r14d
       sar       r13d,0A
       mov       r12d,r14d
       sar       r12d,5
       and       r12d,1F
       mov       eax,ebp
       and       eax,1
       mov       [rsp+94],eax
       and       r14d,1F
       cmp       [r15],r15b
       vxorps    xmm0,xmm0,xmm0
       vmovdqu   xmmword ptr [rsp+78],xmm0
       vmovdqu   xmmword ptr [rsp+80],xmm0
       cmp       byte ptr [r15+24],0
       jne       near ptr 000000000000AA3E
       mov       rdx,[r15+8]
       mov       rcx,[rdx+8]
       cmp       [rcx+8],eax
       jbe       near ptr 000000000000AA7A
       mov       eax,[rsp+94]
       mov       edx,[rdx+10]
       mov       ecx,edx
       and       ecx,1F
       mov       r8d,1
       shlx      r8d,r8d,ecx
       cmp       r13d,r8d
       jae       near ptr 000000000000AAB6
       cmp       r12d,r8d
       jae       near ptr 000000000000AAB6
       cmp       r14d,r8d
       jae       near ptr 000000000000AAB6
       add       edx,edx
       shlx      edx,r13d,edx
       shlx      ecx,r12d,ecx
       or        edx,ecx
       or        edx,r14d
       cmp       qword ptr [r15+10],0
       jne       short 000000000000A826
       mov       r10,[r15+18]
       test      r10,r10
       je        near ptr 000000000000A5B0
       mov       [rsp+38],r10
       mov       ecx,[r10+30]
       test      ecx,ecx
       je        near ptr 000000000000A5A1
       mov       r8,[r10+10]
       test      r8,r8
       je        short 000000000000A844
       cmp       ecx,1
       jne       near ptr 000000000000A889
       cmp       dword ptr [r8+8],0
       jbe       near ptr 000000000000AB35
       movzx     ecx,word ptr [r8+10]
       cmp       ecx,edx
       jne       near ptr 000000000000A59C
       xor       r9d,r9d
       mov       r10,[rsp+38]
       jmp       near ptr 000000000000A5A7
M00_L08:
       mov       eax,edi
       vzeroupper
       add       rsp,98
       pop       rbx
       pop       rbp
       pop       rsi
       pop       rdi
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       ret
M00_L09:
       mov       [rsp+20],r14d
       mov       rcx,[r15+10]
       mov       edx,eax
       mov       r8d,r13d
       mov       r9d,r12d
       cmp       [rcx],ecx
       call      qword ptr [0E610]; Tedd.Voxtree.HotOctreeChunk.get_Item(Int32, Int32, Int32, Int32)
       jmp       near ptr 000000000000A6F5
M00_L10:
       mov       r10,[rsp+38]
       mov       r8,[r10+18]
       mov       r9d,ecx
       test      r8,r8
       je        near ptr 000000000000AB2E
       mov       r10,[rsp+38]
       cmp       [r8+8],r9d
       jb        near ptr 000000000000AB2E
       lea       rcx,[r8+10]
       mov       r8d,r9d
       call      qword ptr [4D68]; Precode of System.SpanHelpers.NonPackedIndexOfValueType[[System.Int32, System.Private.CoreLib],[System.SpanHelpers+DontNegate`1[[System.Int32, System.Private.CoreLib]], System.Private.CoreLib]](Int32 ByRef, Int32, Int32)
       mov       r9d,eax
       mov       eax,[rsp+94]
       mov       r10,[rsp+38]
       jmp       near ptr 000000000000A5A7
M00_L11:
       cmp       ecx,20
       jg        short 000000000000A907
       add       ecx,0F
       and       ecx,0FFFFFFF0
       cmp       [r8+8],ecx
       jb        near ptr 000000000000AB2E
       add       r8,10
       mov       r9d,ecx
       add       r9,r9
       shr       r9,5
       cmp       r9,7FFFFFFF
       ja        near ptr 000000000000AB3B
       vmovd     xmm0,edx
       vpbroadcastw ymm0,xmm0
       xor       edx,edx
       jmp       short 000000000000A8DC
M00_L12:
       mov       ecx,edx
       shl       rcx,5
       vpcmpeqw  ymm1,ymm0,[r8+rcx]
       vpmovmskb ecx,ymm1
       test      ecx,ecx
       jne       short 000000000000A8EB
       inc       edx
M00_L13:
       cmp       edx,r9d
       jl        short 000000000000A8C6
       mov       r10,[rsp+38]
       jmp       near ptr 000000000000A5A1
M00_L14:
       mov       r9d,edx
       shl       r9d,4
       xor       edx,edx
       tzcnt     edx,ecx
       sar       edx,1
       add       r9d,edx
       mov       r10,[rsp+38]
       jmp       near ptr 000000000000A5A7
M00_L15:
       mov       r9d,ecx
       cmp       [r8+8],r9d
       jb        near ptr 000000000000AB2E
       lea       rcx,[r8+10]
       movzx     edx,dx
       movsx     rdx,dx
       movzx     r8d,dx
       dec       r8d
       cmp       r8d,0FE
       jae       short 000000000000A93D
       mov       r8d,r9d
       call      qword ptr [0C378]; System.PackedSpanHelpers.IndexOf[[System.SpanHelpers+DontNegate`1[[System.Int16, System.Private.CoreLib]], System.Private.CoreLib],[System.PackedSpanHelpers+NopTransform, System.Private.CoreLib]](Int16 ByRef, Int16, Int32)
       mov       r9d,eax
       jmp       short 000000000000A949
M00_L16:
       mov       r8d,r9d
       call      qword ptr [60E8]
       mov       r9d,eax
M00_L17:
       mov       eax,r9d
       mov       r9d,eax
       mov       eax,[rsp+94]
       mov       r10,[rsp+38]
       jmp       near ptr 000000000000A5A7
M00_L18:
       mov       rcx,r10
       mov       edx,eax
       mov       [rsp+74],r9d
       mov       r8d,r9d
       call      qword ptr [0E670]; Tedd.Voxtree.SparseVoxelEdits`1[[System.UInt32, System.Private.CoreLib]].HasValue(Int32, Int32)
       test      eax,eax
       je        short 000000000000A9B5
       mov       r15,[rsp+38]
       mov       rdx,[r15+8]
       mov       r15d,[rsp+94]
       cmp       r15d,[rdx+8]
       jae       near ptr 000000000000AB35
       mov       ecx,r15d
       mov       rdx,[rdx+rcx*8+10]
       mov       r15d,[rsp+74]
       cmp       r15d,[rdx+8]
       jae       near ptr 000000000000AB35
       mov       ecx,r15d
       mov       eax,[rdx+rcx*4+10]
       jmp       near ptr 000000000000A6F5
M00_L19:
       mov       eax,[rsp+94]
       jmp       near ptr 000000000000A5B0
M00_L20:
       lea       rdx,[rsp+60]
       mov       r10,[rcx]
       mov       r10,[r10+40]
       call      qword ptr [r10+28]
       mov       r10,[rsp+60]
       mov       r9d,[rsp+68]
       jmp       near ptr 000000000000A60B
M00_L21:
       call      qword ptr [0E6A0]; Precode of Tedd.Voxtree.OctreeThrowHelper.ThrowInvalidView()
       jmp       near ptr 000000000000A6F5
M00_L22:
       mov       edx,r13d
       mov       rcx,2A480302B18
       call      qword ptr [0E6B8]; Precode of Tedd.Voxtree.OctreeThrowHelper.ThrowCoordinate(System.String, Int32)
       jmp       near ptr 000000000000A6F5
M00_L23:
       mov       edx,r12d
       mov       rcx,2A4803122F8
       call      qword ptr [0E6B8]; Precode of Tedd.Voxtree.OctreeThrowHelper.ThrowCoordinate(System.String, Int32)
       jmp       near ptr 000000000000A6F5
M00_L24:
       mov       edx,r14d
       mov       rcx,2A480312310
       call      qword ptr [0E6B8]; Precode of Tedd.Voxtree.OctreeThrowHelper.ThrowCoordinate(System.String, Int32)
       jmp       near ptr 000000000000A6F5
M00_L25:
       call      qword ptr [0E6E8]; Precode of Tedd.Voxtree.OctreeThrowHelper.ThrowMalformed()
       jmp       near ptr 000000000000A6F5
M00_L26:
       mov       rcx,offset MT_System.ObjectDisposedException
       call      0000000000005240
       mov       rbx,rax
       mov       ecx,3F5
       mov       rdx,7FF83A852B28
       call      qword ptr [72B8]; Precode of System.String.StrCns(UInt32, IntPtr)
       mov       rdx,rax
       mov       rcx,rbx
       call      qword ptr [7AC8]; Precode of System.ObjectDisposedException..ctor(System.String)
       mov       rcx,rbx
       call      000000000000B8A0
       int       3
M00_L27:
       mov       rcx,offset MT_System.ArgumentOutOfRangeException
       call      0000000000005240
       mov       rbx,rax
       mov       ecx,3E1
       mov       rdx,7FF83A852B28
       call      qword ptr [72B8]; Precode of System.String.StrCns(UInt32, IntPtr)
       mov       rdx,rax
       mov       rcx,rbx
       call      qword ptr [0D140]; Precode of System.ArgumentOutOfRangeException..ctor(System.String)
       mov       rcx,rbx
       call      000000000000B8A0
       int       3
M00_L28:
       mov       rcx,offset MT_System.ArgumentOutOfRangeException
       call      0000000000005240
       mov       rbx,rax
       mov       ecx,3F1
       mov       rdx,7FF83A852B28
       call      qword ptr [72B8]; Precode of System.String.StrCns(UInt32, IntPtr)
       mov       rdx,rax
       mov       rcx,rbx
       call      qword ptr [0D140]; Precode of System.ArgumentOutOfRangeException..ctor(System.String)
       mov       rcx,rbx
       call      000000000000B8A0
       int       3
M00_L29:
       mov       rcx,offset MT_System.ArgumentOutOfRangeException
       call      0000000000005240
       mov       rdi,rax
       mov       ecx,3E1
       mov       rdx,7FF83A852B28
       call      qword ptr [72B8]; Precode of System.String.StrCns(UInt32, IntPtr)
       mov       rdx,rax
       mov       rcx,rdi
       call      qword ptr [0D140]; Precode of System.ArgumentOutOfRangeException..ctor(System.String)
       mov       rcx,rdi
       call      000000000000B8A0
       int       3
M00_L30:
       call      qword ptr [7C18]; Precode of System.ThrowHelper.ThrowArgumentOutOfRangeException()
       int       3
M00_L31:
       call      0000000000001788
       int       3
M00_L32:
       call      0000000000001770
       int       3
; Total bytes of code 1505
```
```assembly
; Tedd.Voxtree.OctreeSpan.get_IsValid()
       cmp       dword ptr [rcx+8],0
       setne     al
       movzx     eax,al
       ret
; Total bytes of code 11
```
```assembly
; Tedd.Voxtree.OctreeCodec.TryGetUnchecked(System.ReadOnlySpan`1<Byte>, Int32, Tedd.Voxtree.StorageKind, Int32, Int32, Int32, UInt32 ByRef)
       push      r15
       push      r14
       push      r13
       push      r12
       push      rdi
       push      rsi
       push      rbp
       push      rbx
       sub       rsp,58
       xor       eax,eax
       mov       [rsp+28],rax
       vxorps    xmm4,xmm4,xmm4
       vmovdqu   ymmword ptr [rsp+30],ymm4
       mov       [rsp+50],rax
       mov       esi,r9d
       mov       rbx,[rsp+0D0]
       xor       eax,eax
       mov       [rbx],eax
       mov       eax,1
       shlx      edi,eax,edx
       cmp       r8b,1
       jne       near ptr 000000000000A2A3
       mov       eax,2
       mov       r8,[rcx]
       mov       edx,[rcx+8]
       xor       r10d,r10d
       mov       [rbx],r10d
       cmp       edx,2
       jbe       short 000000000000A292
M02_L00:
       lea       r9d,[rax+1]
       mov       eax,eax
       movzx     eax,byte ptr [r8+rax]
       cmp       r10d,1C
       je        short 000000000000A26E
M02_L01:
       mov       r11d,eax
       and       r11d,7F
       shlx      r11d,r11d,r10d
       or        [rbx],r11d
       test      al,80
       jne       short 000000000000A274
       cmp       r9d,3
       jne       short 000000000000A288
M02_L02:
       cmp       r9d,[rcx+8]
       sete      al
       movzx     eax,al
       add       rsp,58
       pop       rbx
       pop       rbp
       pop       rsi
       pop       rdi
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       ret
M02_L03:
       cmp       r9d,edx
       mov       eax,r9d
       jae       short 000000000000A292
       jmp       short 000000000000A21F
M02_L04:
       test      al,0F0
       jne       short 000000000000A283
       jmp       short 000000000000A230
M02_L05:
       add       r10d,7
       cmp       r10d,1C
       jle       short 000000000000A264
       mov       eax,r9d
       jmp       short 000000000000A292
M02_L06:
       mov       eax,r9d
       jmp       short 000000000000A292
M02_L07:
       test      al,7F
       setne     al
       movzx     eax,al
       jmp       short 000000000000A299
M02_L08:
       xor       edx,edx
       mov       r9d,eax
       mov       eax,edx
M02_L09:
       test      eax,eax
       je        near ptr 000000000000A452
       jmp       short 000000000000A249
M02_L10:
       cmp       r8b,2
       jne       short 000000000000A2E2
       imul      esi,edi
       imul      esi,edi
       imul      edi,[rsp+0C0]
       add       esi,edi
       add       esi,[rsp+0C8]
       lea       eax,[rsi*4+2]
       mov       edx,eax
       add       rdx,4
       mov       r8d,[rcx+8]
       cmp       rdx,r8
       ja        short 000000000000A2FE
       add       rax,[rcx]
       mov       eax,[rax]
       mov       [rbx],eax
       jmp       near ptr 000000000000A43C
M02_L11:
       test      edx,edx
       je        near ptr 000000000000A452
       cmp       dword ptr [rcx+8],0C
       jl        near ptr 000000000000A452
       mov       edi,[rcx+8]
       dec       edi
       cmp       edi,[rcx+8]
       jbe       short 000000000000A305
M02_L12:
       call      qword ptr [7C18]; Precode of System.ThrowHelper.ThrowArgumentOutOfRangeException()
       int       3
M02_L13:
       mov       rbp,[rcx]
       mov       r8d,[rcx+8]
       dec       r8d
       cmp       r8d,[rcx+8]
       jae       near ptr 000000000000A465
       mov       rcx,[rcx]
       movzx     ecx,byte ptr [rcx+r8]
       mov       r14d,edi
       sub       r14d,ecx
       cmp       ecx,9
       jl        near ptr 000000000000A452
       cmp       ecx,29
       jg        near ptr 000000000000A452
       cmp       r14d,2
       jl        near ptr 000000000000A452
       lea       r15d,[rdx+0FFFF]
       test      r15d,r15d
       jl        near ptr 000000000000A452
M02_L14:
       cmp       r14d,edi
       jae       near ptr 000000000000A452
       mov       [rsp+50],r14d
       mov       ecx,[rsp+50]
       mov       edx,[rsp+50]
       inc       edx
       mov       [rsp+50],edx
       cmp       ecx,edi
       jae       near ptr 000000000000A465
       movzx     r13d,byte ptr [rcx+rbp]
       sarx      r12d,esi,r15d
       and       r12d,1
       shl       r12d,2
       sarx      r10d,[rsp+0C0],r15d
       and       r10d,1
       add       r10d,r10d
       or        r12d,r10d
       sarx      r9d,[rsp+0C8],r15d
       and       r9d,1
       or        r12d,r9d
       xor       r9d,r9d
       jmp       short 000000000000A3DE
M02_L15:
       mov       [rsp+28],rbp
       mov       [rsp+30],edi
       lea       rcx,[rsp+28]
       lea       rdx,[rsp+50]
       lea       r8,[rsp+38]
       call      qword ptr [0D488]; Tedd.Voxtree.OctreeCodec.TryReadVarUInt(System.ReadOnlySpan`1<Byte>, Int32 ByRef, UInt32 ByRef)
       test      eax,eax
       je        near ptr 000000000000A452
       mov       r9d,[rsp+44]
       inc       r9d
M02_L16:
       mov       [rsp+44],r9d
       cmp       r9d,r12d
       jl        short 000000000000A3B0
       mov       [rsp+28],rbp
       mov       [rsp+30],edi
       lea       rcx,[rsp+28]
       lea       rdx,[rsp+50]
       lea       r8,[rsp+48]
       call      qword ptr [0D488]; Tedd.Voxtree.OctreeCodec.TryReadVarUInt(System.ReadOnlySpan`1<Byte>, Int32 ByRef, UInt32 ByRef)
       test      eax,eax
       je        short 000000000000A452
       bt        r13d,r12d
       jb        short 000000000000A436
       test      r15d,r15d
       je        short 000000000000A452
       cmp       dword ptr [rsp+48],0
       je        short 000000000000A452
       lea       eax,[r14+0FFFE]
       cmp       [rsp+48],eax
       ja        short 000000000000A452
       sub       r14d,[rsp+48]
       dec       r15d
       jns       near ptr 000000000000A350
       jmp       short 000000000000A452
M02_L17:
       mov       eax,[rsp+48]
       mov       [rbx],eax
M02_L18:
       mov       eax,1
       add       rsp,58
       pop       rbx
       pop       rbp
       pop       rsi
       pop       rdi
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       ret
M02_L19:
       xor       eax,eax
       add       rsp,58
       pop       rbx
       pop       rbp
       pop       rsi
       pop       rdi
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       ret
M02_L20:
       call      0000000000001788
       int       3
; Total bytes of code 683
```
```assembly
; Tedd.Voxtree.HotOctreeChunk.get_Item(Int32, Int32, Int32, Int32)
       push      rbp
       sub       rsp,40
       lea       rbp,[rsp+40]
       xor       eax,eax
       mov       [rbp+0FFF0],rax
       mov       [rbp+0FFF8],rax
       mov       [rbp+10],rcx
       mov       [rbp+18],edx
       mov       [rbp+20],r8d
       mov       [rbp+28],r9d
       lea       rdx,[rbp+0FFF0]
       mov       rcx,[rbp+10]
       mov       r8d,[rbp+18]
       call      qword ptr [0E4A8]; Tedd.Voxtree.HotOctreeChunk.GetChannelSpan(Int32)
       mov       rcx,[rbp+10]
       call      qword ptr [0E4C0]; Tedd.Voxtree.HotOctreeChunk.get_Levels()
       mov       [rbp+0FFE8],eax
       mov       dword ptr [rsp+20],1
       mov       r9d,[rbp+0FFE8]
       mov       edx,[rbp+28]
       mov       r8d,[rbp+30]
       mov       ecx,[rbp+20]
       call      qword ptr [0E4D8]; Tedd.Voxtree.DenseVoxel.GetIndex(Int32, Int32, Int32, Int32, Tedd.Voxtree.DenseVoxelLayout)
       mov       [rbp+0FFEC],eax
       mov       eax,[rbp+0FFF8]
       cmp       [rbp+0FFEC],eax
       jae       short 00000000000064B9
       mov       eax,[rbp+0FFEC]
       mov       rcx,[rbp+0FFF0]
       mov       eax,[rcx+rax*4]
       add       rsp,40
       pop       rbp
       ret
M03_L00:
       call      0000000000001788
       int       3
; Total bytes of code 127
```
```assembly
; System.SpanHelpers.NonPackedIndexOfValueType[[System.Int32, System.Private.CoreLib],[System.SpanHelpers+DontNegate`1[[System.Int32, System.Private.CoreLib]], System.Private.CoreLib]](Int32 ByRef, Int32, Int32)
       cmp       r8d,4
       jl        near ptr 0000000000000E5A
       movd      xmm0,edx
       pshufd    xmm0,xmm0,0
       mov       rdx,rcx
       lea       eax,[r8+0FFFC]
       cdqe
       shl       rax,2
       lea       r10,[rdx+rax]
       movups    xmm1,[rcx]
       pcmpeqd   xmm1,xmm0
       ptest     xmm1,xmm1
       je        short 0000000000000E13
M04_L00:
       movmskps  eax,xmm1
       bsf       r8d,eax
       mov       r10d,20
       test      eax,eax
       cmove     r8d,r10d
       mov       rax,rdx
       sub       rax,rcx
       shr       rax,2
       add       eax,r8d
M04_L01:
       ret
M04_L02:
       add       rdx,10
       cmp       rdx,r10
       jbe       near ptr 0000000000000F43
       mov       ecx,r8d
       test      cl,3
       je        near ptr 0000000000000F5A
       movups    xmm1,[r10]
       pcmpeqd   xmm1,xmm0
       ptest     xmm1,xmm1
       je        near ptr 0000000000000F5A
       movmskps  edx,xmm1
       bsf       r8d,edx
       mov       ecx,20
       test      edx,edx
       cmove     r8d,ecx
       shr       rax,2
       add       eax,r8d
       jmp       short 0000000000000E12
M04_L03:
       xor       r10d,r10d
       cmp       r8d,8
       jge       short 0000000000000E8D
M04_L04:
       cmp       r8d,4
       jge       short 0000000000000EDC
M04_L05:
       test      r8d,r8d
       jle       near ptr 0000000000000F5A
M04_L06:
       dec       r8d
       cmp       [rcx+r10*4],edx
       je        short 0000000000000E88
       inc       r10
       test      r8d,r8d
       jg        short 0000000000000E72
       jmp       near ptr 0000000000000F5A
M04_L07:
       mov       eax,r10d
       jmp       short 0000000000000E12
M04_L08:
       add       r8d,0FFFFFFF8
       cmp       [rcx+r10*4],edx
       je        short 0000000000000E88
       cmp       [rcx+r10*4+4],edx
       je        near ptr 0000000000000F3A
       cmp       [rcx+r10*4+8],edx
       je        near ptr 0000000000000F31
       cmp       [rcx+r10*4+0C],edx
       je        short 0000000000000F28
       cmp       [rcx+r10*4+10],edx
       je        short 0000000000000F1F
       cmp       [rcx+r10*4+14],edx
       je        short 0000000000000F16
       cmp       [rcx+r10*4+18],edx
       je        short 0000000000000F0D
       cmp       [rcx+r10*4+1C],edx
       je        short 0000000000000F04
       add       r10,8
       cmp       r8d,8
       jge       short 0000000000000E8D
       jmp       short 0000000000000E63
M04_L09:
       add       r8d,0FFFFFFFC
       cmp       [rcx+r10*4],edx
       je        short 0000000000000E88
       cmp       [rcx+r10*4+4],edx
       je        short 0000000000000F3A
       cmp       [rcx+r10*4+8],edx
       je        short 0000000000000F31
       cmp       [rcx+r10*4+0C],edx
       je        short 0000000000000F28
       add       r10,4
       jmp       near ptr 0000000000000E69
M04_L10:
       lea       eax,[r10+7]
       jmp       near ptr 0000000000000E12
M04_L11:
       lea       eax,[r10+6]
       jmp       near ptr 0000000000000E12
M04_L12:
       lea       eax,[r10+5]
       jmp       near ptr 0000000000000E12
M04_L13:
       lea       eax,[r10+4]
       jmp       near ptr 0000000000000E12
M04_L14:
       lea       eax,[r10+3]
       jmp       near ptr 0000000000000E12
M04_L15:
       lea       eax,[r10+2]
       jmp       near ptr 0000000000000E12
M04_L16:
       lea       eax,[r10+1]
       jmp       near ptr 0000000000000E12
M04_L17:
       movups    xmm1,[rdx]
       pcmpeqd   xmm1,xmm0
       ptest     xmm1,xmm1
       jne       near ptr 0000000000000DF2
       jmp       near ptr 0000000000000E13
M04_L18:
       mov       eax,0FFFFFFFF
       ret
; Total bytes of code 416
```
```assembly
; System.PackedSpanHelpers.IndexOf[[System.SpanHelpers+DontNegate`1[[System.Int16, System.Private.CoreLib]], System.Private.CoreLib],[System.PackedSpanHelpers+NopTransform, System.Private.CoreLib]](Int16 ByRef, Int16, Int32)
       push      r14
       push      rdi
       push      rsi
       push      rbp
       push      rbx
       sub       rsp,50
       vmovaps   [rsp+40],xmm6
       vmovaps   [rsp+30],xmm7
       vmovaps   [rsp+20],xmm8
       mov       rsi,rcx
       mov       edi,edx
       mov       ebx,r8d
       cmp       ebx,8
       jl        near ptr 000000000000D51C
       mov       rbp,rsi
       cmp       ebx,10
       jle       near ptr 000000000000D499
       vmovd     xmm6,edi
       vpbroadcastb ymm6,xmm6
       cmp       ebx,20
       jle       near ptr 000000000000D3D4
       lea       ecx,[rbx+0FFE0]
       movsxd    rcx,ecx
       lea       rdi,[rbp+rcx*2]
       vmovups   ymm0,[rsi]
       vpackuswb ymm0,ymm0,[rsi+20]
       vpcmpeqb  ymm7,ymm0,ymm6
       vptest    ymm7,ymm7
       jne       short 000000000000D383
M05_L00:
       add       rbp,40
       cmp       rbp,rdi
       jae       short 000000000000D3B9
       mov       rcx,7FF83A4C2D90
       vextractf128 xmm8,ymm6,1
       call      0000000000008420
       vmovups   ymm0,[rbp]
       vpackuswb ymm0,ymm0,[rbp+20]
       vinsertf128 ymm6,ymm6,xmm8,1
       vpcmpeqb  ymm7,ymm0,ymm6
       vptest    ymm7,ymm7
       je        short 000000000000D34A
M05_L01:
       mov       rcx,7FF83A4C2D84
       vextractf128 xmm8,ymm7,1
       call      0000000000008420
       mov       rax,rbp
       sub       rax,rsi
       shr       rax,1
       vinsertf128 ymm7,ymm7,xmm8,1
       vpermq    ymm0,ymm7,0D8
       vpmovmskb ecx,ymm0
       tzcnt     ecx,ecx
       add       eax,ecx
       jmp       short 000000000000D41C
M05_L02:
       mov       rcx,7FF83A4C2D8C
       vextractf128 xmm8,ymm6,1
       call      0000000000008420
       vinsertf128 ymm6,ymm6,xmm8,1
M05_L03:
       add       ebx,0FFFFFFF0
       movsxd    rcx,ebx
       lea       rbx,[rsi+rcx*2]
       cmp       rbp,rbx
       ja        short 000000000000D43C
       mov       rdi,rbp
M05_L04:
       vmovups   ymm0,[rdi]
       vpackuswb ymm0,ymm0,[rbx]
       vpcmpeqb  ymm6,ymm0,ymm6
       vptest    ymm6,ymm6
       jne       short 000000000000D45C
       mov       rcx,7FF83A4C2D9C
       call      0000000000008420
M05_L05:
       mov       rcx,7FF83A4C2DAC
       call      0000000000008420
       mov       eax,0FFFFFFFF
M05_L06:
       vzeroupper
       vmovaps   xmm6,[rsp+40]
       vmovaps   xmm7,[rsp+30]
       vmovaps   xmm8,[rsp+20]
       add       rsp,50
       pop       rbx
       pop       rbp
       pop       rsi
       pop       rdi
       pop       r14
       ret
M05_L07:
       mov       rcx,7FF83A4C2D94
       vextractf128 xmm8,ymm6,1
       call      0000000000008420
       mov       rdi,rbx
       vinsertf128 ymm6,ymm6,xmm8,1
       jmp       short 000000000000D3E6
M05_L08:
       mov       rcx,7FF83A4C2D98
       vextractf128 xmm7,ymm6,1
       call      0000000000008420
       vinsertf128 ymm6,ymm6,xmm7,1
       vpermq    ymm0,ymm6,0D8
       vpmovmskb ecx,ymm0
       tzcnt     ecx,ecx
       cmp       ecx,10
       jge       near ptr 000000000000D670
M05_L09:
       sub       rdi,rsi
       shr       rdi,1
       lea       eax,[rdi+rcx]
       jmp       short 000000000000D41C
M05_L10:
       mov       rcx,7FF83A4C2D88
       call      0000000000008420
       vmovd     xmm6,edi
       vpbroadcastb xmm6,xmm6
       lea       ecx,[rbx+0FFF8]
       movsxd    rcx,ecx
       lea       rbx,[rsi+rcx*2]
       cmp       rsi,rbx
       ja        near ptr 000000000000D67B
       mov       rdi,rsi
M05_L11:
       vmovups   xmm0,[rdi]
       vpackuswb xmm0,xmm0,[rbx]
       vpcmpeqb  xmm6,xmm0,xmm6
       vptest    xmm6,xmm6
       jne       short 000000000000D4EE
       mov       rcx,7FF83A4C2DA8
       call      0000000000008420
       jmp       near ptr 000000000000D408
M05_L12:
       mov       rcx,7FF83A4C2DA4
       call      0000000000008420
       vpmovmskb ecx,xmm6
       tzcnt     ecx,ecx
       cmp       ecx,8
       jge       near ptr 000000000000D692
M05_L13:
       sub       rdi,rsi
       shr       rdi,1
       lea       eax,[rdi+rcx]
       jmp       near ptr 000000000000D41C
M05_L14:
       xor       ebp,ebp
       cmp       ebx,4
       jl        short 000000000000D575
       add       ebx,0FFFFFFFC
       movsx     rcx,word ptr [rsi]
       movsx     r14,di
       cmp       ecx,r14d
       je        near ptr 000000000000D5BE
       movsx     rcx,word ptr [rsi+2]
       cmp       ecx,r14d
       je        near ptr 000000000000D5EF
       movsx     rcx,word ptr [rsi+4]
       cmp       ecx,r14d
       je        near ptr 000000000000D623
       movsx     rcx,word ptr [rsi+6]
       cmp       ecx,r14d
       je        near ptr 000000000000D657
       mov       rcx,7FF83A4C2D78
       call      0000000000008420
       mov       ebp,4
M05_L15:
       test      ebx,ebx
       jle       near ptr 000000000000D408
       movsx     r14,di
M05_L16:
       dec       ebx
       movsx     rcx,word ptr [rsi+rbp*2]
       cmp       ecx,r14d
       je        short 000000000000D5A8
       mov       rcx,7FF83A4C2D80
       call      0000000000008420
       inc       rbp
       test      ebx,ebx
       jg        short 000000000000D581
       jmp       near ptr 000000000000D408
M05_L17:
       mov       rcx,7FF83A4C2D7C
       call      0000000000008420
       mov       eax,ebp
       jmp       near ptr 000000000000D41C
M05_L18:
       mov       rcx,7FF83A4C2D68
       call      0000000000008420
       xor       eax,eax
       vzeroupper
       vmovaps   xmm6,[rsp+40]
       vmovaps   xmm7,[rsp+30]
       vmovaps   xmm8,[rsp+20]
       add       rsp,50
       pop       rbx
       pop       rbp
       pop       rsi
       pop       rdi
       pop       r14
       ret
M05_L19:
       mov       rcx,7FF83A4C2D6C
       call      0000000000008420
       mov       eax,1
       vzeroupper
       vmovaps   xmm6,[rsp+40]
       vmovaps   xmm7,[rsp+30]
       vmovaps   xmm8,[rsp+20]
       add       rsp,50
       pop       rbx
       pop       rbp
       pop       rsi
       pop       rdi
       pop       r14
       ret
M05_L20:
       mov       rcx,7FF83A4C2D70
       call      0000000000008420
       mov       eax,2
       vzeroupper
       vmovaps   xmm6,[rsp+40]
       vmovaps   xmm7,[rsp+30]
       vmovaps   xmm8,[rsp+20]
       add       rsp,50
       pop       rbx
       pop       rbp
       pop       rsi
       pop       rdi
       pop       r14
       ret
M05_L21:
       mov       rcx,7FF83A4C2D74
       call      0000000000008420
       mov       eax,3
       jmp       near ptr 000000000000D41C
M05_L22:
       mov       rdi,rbx
       add       ecx,0FFFFFFF0
       jmp       near ptr 000000000000D48E
M05_L23:
       mov       rcx,7FF83A4C2DA0
       call      0000000000008420
       mov       rdi,rbx
       jmp       near ptr 000000000000D4C7
M05_L24:
       mov       rdi,rbx
       add       ecx,0FFFFFFF8
       jmp       near ptr 000000000000D50E
; Total bytes of code 957
```
```assembly
; Tedd.Voxtree.SparseVoxelEdits`1[[System.UInt32, System.Private.CoreLib]].HasValue(Int32, Int32)
       push      rbp
       sub       rsp,20
       lea       rbp,[rsp+20]
       mov       [rbp+10],rcx
       mov       [rbp+18],edx
       mov       [rbp+20],r8d
       mov       rax,[rbp+10]
       mov       rax,[rax+20]
       mov       rcx,[rbp+10]
       mov       ecx,[rcx+2C]
       imul      ecx,[rbp+18]
       mov       edx,[rbp+20]
       sar       edx,6
       add       ecx,edx
       cmp       ecx,[rax+8]
       jae       short 0000000000006E4B
       mov       edx,ecx
       lea       rax,[rax+rdx*8+10]
       mov       ecx,1
       mov       edx,[rbp+20]
       shlx      rcx,rcx,rdx
       and       rcx,[rax]
       test      rcx,rcx
       setne     al
       movzx     eax,al
       add       rsp,20
       pop       rbp
       ret
M06_L00:
       call      0000000000001788
       int       3
; Total bytes of code 97
```
```assembly
; Tedd.Voxtree.OctreeCodec.TryReadVarUInt(System.ReadOnlySpan`1<Byte>, Int32 ByRef, UInt32 ByRef)
       push      rbx
       sub       rsp,20
       mov       rax,[rcx]
       mov       ecx,[rcx+8]
       xor       r10d,r10d
       mov       [r8],r10d
       mov       r10d,[rdx]
       mov       r9d,r10d
       xor       r11d,r11d
       cmp       r10d,ecx
       jae       short 000000000000A52B
M07_L00:
       mov       r10d,[rdx]
       lea       ebx,[r10+1]
       mov       [rdx],ebx
       cmp       r10d,ecx
       jae       short 000000000000A533
       movzx     r10d,byte ptr [rax+r10]
       cmp       r11d,1C
       je        short 000000000000A507
M07_L01:
       mov       ebx,r10d
       and       ebx,7F
       shlx      ebx,ebx,r11d
       or        [r8],ebx
       test      r10b,80
       jne       short 000000000000A50F
       mov       eax,[rdx]
       sub       eax,r9d
       cmp       eax,1
       jne       short 000000000000A51B
       mov       eax,1
       add       rsp,20
       pop       rbx
       ret
M07_L02:
       cmp       [rdx],ecx
       jae       short 000000000000A52B
       jmp       short 000000000000A4BF
M07_L03:
       test      r10b,0F0
       jne       short 000000000000A52B
       jmp       short 000000000000A4D8
M07_L04:
       add       r11d,7
       cmp       r11d,1C
       jle       short 000000000000A501
       jmp       short 000000000000A52B
M07_L05:
       test      r10b,7F
       setne     al
       movzx     eax,al
       add       rsp,20
       pop       rbx
       ret
M07_L06:
       xor       eax,eax
       add       rsp,20
       pop       rbx
       ret
M07_L07:
       call      0000000000001788
       int       3
; Total bytes of code 153
```
```assembly
; Tedd.Voxtree.HotOctreeChunk.GetChannelSpan(Int32)
       push      rbp
       sub       rsp,50
       lea       rbp,[rsp+50]
       xor       eax,eax
       mov       [rbp+0FFD8],rax
       vxorps    xmm4,xmm4,xmm4
       vmovdqu   ymmword ptr [rbp+0FFE0],ymm4
       mov       [rbp+10],rcx
       mov       [rbp+18],rdx
       mov       [rbp+20],r8d
       mov       rcx,[rbp+10]
       call      qword ptr [0E508]; Tedd.Voxtree.HotOctreeChunk.GetValues()
       mov       [rbp+0FFF0],rax
       mov       rax,[rbp+0FFF0]
       mov       [rbp+0FFE8],rax
       mov       rcx,[rbp+10]
       call      qword ptr [0E520]; Tedd.Voxtree.HotOctreeChunk.get_ChannelCount()
       cmp       eax,[rbp+20]
       ja        short 00000000000060DE
       mov       rcx,offset MT_System.ArgumentOutOfRangeException
       call      0000000000005240
       mov       [rbp+0FFE0],rax
       mov       ecx,3E1
       mov       rdx,7FF83A852B28
       call      qword ptr [72B8]; Precode of System.String.StrCns(UInt32, IntPtr)
       mov       [rbp+0FFD8],rax
       mov       rdx,[rbp+0FFD8]
       mov       rcx,[rbp+0FFE0]
       call      qword ptr [0D140]; Precode of System.ArgumentOutOfRangeException..ctor(System.String)
       mov       rcx,[rbp+0FFE0]
       call      000000000000B8A0
       int       3
M08_L00:
       mov       rcx,[rbp+10]
       call      qword ptr [0E4C0]; Tedd.Voxtree.HotOctreeChunk.get_Levels()
       mov       ecx,eax
       call      qword ptr [0CE88]; Tedd.Voxtree.OctreeCodec.GetVoxelCount(Int32)
       mov       [rbp+0FFFC],eax
       mov       eax,[rbp+20]
       mov       r8d,eax
       imul      r8d,[rbp+0FFFC]
       mov       rcx,[rbp+18]
       mov       rdx,[rbp+0FFE8]
       mov       r9d,[rbp+0FFFC]
       call      qword ptr [0E4F0]; System.MemoryExtensions.AsSpan[[System.UInt32, System.Private.CoreLib]](UInt32[], Int32, Int32)
       mov       rax,[rbp+18]
       add       rsp,50
       pop       rbp
       ret
; Total bytes of code 202
```
```assembly
; Tedd.Voxtree.HotOctreeChunk.get_Levels()
       push      rbp
       mov       rbp,rsp
       mov       [rbp+10],rcx
       mov       rax,[rbp+10]
       mov       eax,[rax+20]
       pop       rbp
       ret
; Total bytes of code 17
```
```assembly
; Tedd.Voxtree.DenseVoxel.GetIndex(Int32, Int32, Int32, Int32, Tedd.Voxtree.DenseVoxelLayout)
       push      rbp
       sub       rsp,40
       lea       rbp,[rsp+40]
       vxorps    xmm4,xmm4,xmm4
       vmovdqu   xmmword ptr [rbp+0FFE8],xmm4
       xor       eax,eax
       mov       [rbp+0FFF8],rax
       mov       [rbp+10],ecx
       mov       [rbp+18],edx
       mov       [rbp+20],r8d
       mov       [rbp+28],r9d
       mov       ecx,[rbp+28]
       call      qword ptr [0CE70]; Tedd.Voxtree.OctreeCodec.ValidateLevels(Int32)
       mov       ecx,[rbp+30]
       call      qword ptr [0CD68]; Tedd.Voxtree.DenseVoxel.Validate(Tedd.Voxtree.DenseVoxelLayout)
       mov       eax,1
       mov       ecx,[rbp+28]
       shlx      eax,eax,ecx
       mov       [rbp+0FFFC],eax
       mov       eax,[rbp+10]
       cmp       eax,[rbp+0FFFC]
       jae       short 00000000000062D0
       mov       eax,[rbp+18]
       cmp       eax,[rbp+0FFFC]
       jae       short 0000000000006314
       mov       eax,[rbp+20]
       cmp       eax,[rbp+0FFFC]
       jb        short 0000000000006325
       mov       rcx,7FF83A91E3F0
       call      0000000000008420
M10_L00:
       mov       rcx,offset MT_System.ArgumentOutOfRangeException
       call      0000000000005240
       mov       [rbp+0FFF0],rax
       mov       ecx,3F1
       mov       rdx,7FF83A852B28
       call      qword ptr [72B8]; Precode of System.String.StrCns(UInt32, IntPtr)
       mov       [rbp+0FFE8],rax
       mov       rdx,[rbp+0FFE8]
       mov       rcx,[rbp+0FFF0]
       call      qword ptr [0D140]; Precode of System.ArgumentOutOfRangeException..ctor(System.String)
       mov       rcx,[rbp+0FFF0]
       call      000000000000B8A0
       int       3
M10_L01:
       mov       rcx,7FF83A91E3F4
       call      0000000000008420
       jmp       short 00000000000062D0
M10_L02:
       mov       rcx,7FF83A91E3F8
       call      0000000000008420
       mov       eax,[rbp+30]
       mov       [rsp+20],eax
       mov       ecx,[rbp+10]
       mov       edx,[rbp+18]
       mov       r8d,[rbp+20]
       mov       r9d,[rbp+0FFFC]
       call      qword ptr [0E5C8]; Tedd.Voxtree.DenseVoxel.Index(Int32, Int32, Int32, Int32, Tedd.Voxtree.DenseVoxelLayout)
       nop
       add       rsp,40
       pop       rbp
       ret
; Total bytes of code 246
```
```assembly
; Tedd.Voxtree.HotOctreeChunk.GetValues()
       push      rbp
       sub       rsp,40
       lea       rbp,[rsp+40]
       vxorps    xmm4,xmm4,xmm4
       vmovdqu   ymmword ptr [rbp+0FFE0],ymm4
       mov       [rbp+10],rcx
       mov       rax,[rbp+10]
       mov       rax,[rax+8]
       mov       [rbp+0FFF8],rax
       mov       rax,[rbp+0FFF8]
       mov       [rbp+0FFF0],rax
       cmp       qword ptr [rbp+0FFF8],0
       jne       short 00000000000061A6
       mov       rcx,offset MT_System.InvalidOperationException
       call      0000000000005240
       mov       [rbp+0FFE8],rax
       mov       ecx,9F3
       mov       rdx,7FF83A852B28
       call      qword ptr [72B8]; Precode of System.String.StrCns(UInt32, IntPtr)
       mov       [rbp+0FFE0],rax
       mov       rdx,[rbp+0FFE0]
       mov       rcx,[rbp+0FFE8]
       call      qword ptr [65C8]; Precode of System.InvalidOperationException..ctor(System.String)
       mov       rcx,[rbp+0FFE8]
       call      000000000000B8A0
       int       3
M11_L00:
       mov       rax,[rbp+0FFF0]
       add       rsp,40
       pop       rbp
       ret
; Total bytes of code 128
```
```assembly
; Tedd.Voxtree.HotOctreeChunk.get_ChannelCount()
       push      rbp
       mov       rbp,rsp
       mov       [rbp+10],rcx
       mov       rax,[rbp+10]
       mov       eax,[rax+24]
       pop       rbp
       ret
; Total bytes of code 17
```
```assembly
; Tedd.Voxtree.OctreeCodec.GetVoxelCount(Int32)
       push      rbp
       mov       rbp,rsp
       mov       [rbp+10],ecx
       mov       eax,1
       mov       ecx,[rbp+10]
       lea       ecx,[rcx+rcx*2]
       shlx      eax,eax,ecx
       pop       rbp
       ret
; Total bytes of code 25
```
```assembly
; System.MemoryExtensions.AsSpan[[System.UInt32, System.Private.CoreLib]](UInt32[], Int32, Int32)
       sub       rsp,28
       test      rdx,rdx
       je        short 000000000000622F
       mov       r8d,r8d
       mov       eax,r9d
       add       rax,r8
       mov       r10d,[rdx+8]
       cmp       rax,r10
       ja        short 000000000000623B
       lea       rax,[rdx+r8*4+10]
M14_L00:
       mov       [rcx],rax
       mov       [rcx+8],r9d
       mov       rax,rcx
       add       rsp,28
       ret
M14_L01:
       or        r8d,r9d
       jne       short 000000000000623B
       xor       eax,eax
       xor       r9d,r9d
       jmp       short 0000000000006220
M14_L02:
       call      qword ptr [7C18]; Precode of System.ThrowHelper.ThrowArgumentOutOfRangeException()
       int       3
; Total bytes of code 66
```
```assembly
; Tedd.Voxtree.OctreeCodec.ValidateLevels(Int32)
       push      rbp
       sub       rsp,80
       lea       rbp,[rsp+80]
       xor       eax,eax
       mov       [rbp+0FFA8],rax
       vxorps    xmm4,xmm4,xmm4
       vmovdqu   ymmword ptr [rbp+0FFB0],ymm4
       vmovdqu   ymmword ptr [rbp+0FFD0],ymm4
       vmovdqa   xmmword ptr [rbp+0FFF0],xmm4
       mov       [rbp+10],ecx
       cmp       dword ptr [rbp+10],9
       jbe       near ptr 0000000000005EFF
       mov       rcx,offset MT_System.Int32
       call      0000000000005240
       mov       [rbp+0FFD0],rax
       mov       rax,[rbp+0FFD0]
       mov       ecx,[rbp+10]
       mov       [rax+8],ecx
       lea       rcx,[rbp+0FFD8]
       mov       edx,31
       mov       r8d,1
       call      qword ptr [69A0]; System.Runtime.CompilerServices.DefaultInterpolatedStringHandler..ctor(Int32, Int32)
       mov       ecx,1341
       mov       rdx,7FF83A852B28
       call      qword ptr [72B8]; Precode of System.String.StrCns(UInt32, IntPtr)
       mov       [rbp+0FFC0],rax
       mov       rdx,[rbp+0FFC0]
       lea       rcx,[rbp+0FFD8]
       call      qword ptr [6B68]; System.Runtime.CompilerServices.DefaultInterpolatedStringHandler.AppendLiteral(System.String)
       lea       rcx,[rbp+0FFD8]
       mov       edx,9
       call      qword ptr [6988]; System.Runtime.CompilerServices.DefaultInterpolatedStringHandler.AppendFormatted[[System.Int32, System.Private.CoreLib]](Int32)
       mov       ecx,369
       mov       rdx,7FF83A852B28
       call      qword ptr [72B8]; Precode of System.String.StrCns(UInt32, IntPtr)
       mov       [rbp+0FFB8],rax
       mov       rdx,[rbp+0FFB8]
       lea       rcx,[rbp+0FFD8]
       call      qword ptr [6B68]; System.Runtime.CompilerServices.DefaultInterpolatedStringHandler.AppendLiteral(System.String)
       mov       rcx,offset MT_System.ArgumentOutOfRangeException
       call      0000000000005240
       mov       [rbp+0FFC8],rax
       mov       ecx,1333
       mov       rdx,7FF83A852B28
       call      qword ptr [72B8]; Precode of System.String.StrCns(UInt32, IntPtr)
       mov       [rbp+0FFB0],rax
       lea       rcx,[rbp+0FFD8]
       call      qword ptr [69D0]; System.Runtime.CompilerServices.DefaultInterpolatedStringHandler.ToStringAndClear()
       mov       [rbp+0FFA8],rax
       mov       rdx,[rbp+0FFB0]
       mov       r9,[rbp+0FFA8]
       mov       r8,[rbp+0FFD0]
       mov       rcx,[rbp+0FFC8]
       call      qword ptr [7AC8]; Precode of System.ArgumentOutOfRangeException..ctor(System.String, System.Object, System.String)
       mov       rcx,[rbp+0FFC8]
       call      000000000000B8A0
       int       3
M15_L00:
       add       rsp,80
       pop       rbp
       ret
; Total bytes of code 296
```
```assembly
; Tedd.Voxtree.DenseVoxel.Validate(Tedd.Voxtree.DenseVoxelLayout)
       push      rbp
       sub       rsp,30
       lea       rbp,[rsp+30]
       xor       eax,eax
       mov       [rbp+0FFF8],rax
       mov       [rbp+0FFF0],rax
       mov       [rbp+10],ecx
       cmp       dword ptr [rbp+10],0
       je        short 0000000000005F96
       cmp       dword ptr [rbp+10],1
       je        short 0000000000005F87
       mov       rcx,offset MT_System.ArgumentOutOfRangeException
       call      0000000000005240
       mov       [rbp+0FFF8],rax
       mov       ecx,4B5
       mov       rdx,7FF83A852B28
       call      qword ptr [72B8]; Precode of System.String.StrCns(UInt32, IntPtr)
       mov       [rbp+0FFF0],rax
       mov       rdx,[rbp+0FFF0]
       mov       rcx,[rbp+0FFF8]
       call      qword ptr [0D140]; Precode of System.ArgumentOutOfRangeException..ctor(System.String)
       mov       rcx,[rbp+0FFF8]
       call      000000000000B8A0
       int       3
M16_L00:
       mov       rcx,7FF83A91E3B8
       call      0000000000008420
M16_L01:
       mov       rcx,7FF83A91E3BC
       call      0000000000008420
       nop
       add       rsp,30
       pop       rbp
       ret
; Total bytes of code 140
```
```assembly
; Tedd.Voxtree.DenseVoxel.Index(Int32, Int32, Int32, Int32, Tedd.Voxtree.DenseVoxelLayout)
       push      rbp
       sub       rsp,20
       lea       rbp,[rsp+20]
       mov       [rbp+10],ecx
       mov       [rbp+18],edx
       mov       [rbp+20],r8d
       mov       [rbp+28],r9d
       cmp       dword ptr [rbp+30],0
       je        short 00000000000063B4
       mov       rcx,7FF83A91E430
       call      0000000000008420
       mov       ecx,[rbp+10]
       mov       edx,[rbp+18]
       mov       r8d,[rbp+20]
       call      qword ptr [0E5E0]; Tedd.MortonEncoding.Encode(UInt32, UInt32, UInt32)
       nop
       add       rsp,20
       pop       rbp
       ret
M17_L00:
       mov       rcx,7FF83A91E434
       call      0000000000008420
       mov       eax,[rbp+10]
       imul      eax,[rbp+28]
       add       eax,[rbp+18]
       imul      eax,[rbp+28]
       add       eax,[rbp+20]
       add       rsp,20
       pop       rbp
       ret
; Total bytes of code 106
```
```assembly
; System.Runtime.CompilerServices.DefaultInterpolatedStringHandler..ctor(Int32, Int32)
       push      rdi
       push      rsi
       push      rbx
       sub       rsp,20
       mov       rbx,rcx
       mov       esi,edx
       mov       edi,r8d
       xor       eax,eax
       mov       [rbx],rax
       call      qword ptr [0A098]
       mov       rcx,[rax]
       imul      edx,edi,0B
       add       edx,esi
       mov       eax,100
       cmp       edx,100
       cmovle    edx,eax
       cmp       [rcx],ecx
       call      qword ptr [98B8]; Precode of System.Buffers.SharedArrayPool`1[[System.Char, System.Private.CoreLib]].Rent(Int32)
       mov       [rbx+8],rax
       test      rax,rax
       je        short 000000000000C4E0
       lea       rcx,[rax+10]
       mov       eax,[rax+8]
M18_L00:
       mov       [rbx+18],rcx
       mov       [rbx+20],eax
       xor       eax,eax
       mov       [rbx+10],eax
       mov       byte ptr [rbx+14],0
       add       rsp,20
       pop       rbx
       pop       rsi
       pop       rdi
       ret
M18_L01:
       xor       ecx,ecx
       xor       eax,eax
       jmp       short 000000000000C4C8
; Total bytes of code 102
```
```assembly
; System.Runtime.CompilerServices.DefaultInterpolatedStringHandler.AppendLiteral(System.String)
       push      rdi
       push      rsi
       push      rbx
       sub       rsp,20
       mov       rbx,rcx
       mov       rsi,rdx
       lea       r8,[rbx+18]
       mov       edx,[rbx+10]
       mov       ecx,[r8+8]
       cmp       edx,ecx
       ja        short 000000000000586B
       mov       r8,[r8]
       mov       eax,edx
       lea       rax,[r8+rax*2]
       sub       ecx,edx
       mov       edi,[rsi+8]
       cmp       edi,ecx
       ja        short 0000000000005872
       mov       r8d,edi
       add       r8,r8
       lea       rdx,[rsi+0C]
       mov       rcx,rax
       call      qword ptr [5818]; System.SpanHelpers.Memmove(Byte ByRef, Byte ByRef, UIntPtr)
       mov       rcx,7FF83A80E140
       call      0000000000008420
       add       [rbx+10],edi
       add       rsp,20
       pop       rbx
       pop       rsi
       pop       rdi
       ret
M19_L00:
       call      qword ptr [7C18]; Precode of System.ThrowHelper.ThrowArgumentOutOfRangeException()
       int       3
M19_L01:
       mov       rcx,7FF83A80E144
       call      0000000000008420
       mov       rcx,rbx
       mov       rdx,rsi
       add       rsp,20
       pop       rbx
       pop       rsi
       pop       rdi
       jmp       qword ptr [69B8]; Precode of System.Runtime.CompilerServices.DefaultInterpolatedStringHandler.GrowThenCopyString(System.String)
; Total bytes of code 132
```
```assembly
; System.Runtime.CompilerServices.DefaultInterpolatedStringHandler.AppendFormatted[[System.Int32, System.Private.CoreLib]](Int32)
       push      rdi
       push      rsi
       push      rbp
       push      rbx
       sub       rsp,58
       xorps     xmm4,xmm4
       movaps    [rsp+30],xmm4
       movaps    [rsp+40],xmm4
       mov       rbx,rcx
       mov       esi,edx
       cmp       byte ptr [rbx+14],0
       jne       short 000000000000F15B
M20_L00:
       lea       rdx,[rbx+18]
       mov       r8d,[rbx+10]
       mov       edi,[rdx+8]
       cmp       r8d,edi
       ja        near ptr 000000000000F1D8
       mov       rdx,[rdx]
       mov       ecx,r8d
       lea       rbp,[rdx+rcx*2]
       sub       edi,r8d
       mov       rcx,[rbx]
       test      esi,esi
       jl        short 000000000000F173
       mov       [rsp+40],rbp
       mov       [rsp+48],edi
       lea       rdx,[rsp+40]
       lea       r8,[rsp+50]
       mov       ecx,esi
       call      qword ptr [0CF8]; Precode of System.Number.TryUInt32ToDecStr[[System.Char, System.Private.CoreLib]](UInt32, System.Span`1<Char>, Int32 ByRef)
M20_L01:
       test      eax,eax
       jne       short 000000000000F152
       mov       rcx,rbx
       call      qword ptr [4FF8]
       jmp       short 000000000000F100
M20_L02:
       mov       eax,[rsp+50]
       add       [rbx+10],eax
       jmp       short 000000000000F169
M20_L03:
       mov       rcx,rbx
       mov       edx,esi
       xor       r8d,r8d
       call      qword ptr [1B50]
M20_L04:
       nop
       add       rsp,58
       pop       rbx
       pop       rbp
       pop       rsi
       pop       rdi
       ret
M20_L05:
       test      rcx,rcx
       je        short 000000000000F180
       call      qword ptr [1260]; Precode of System.Globalization.NumberFormatInfo.<GetInstance>g__GetProviderNonNull|58_0(System.IFormatProvider)
       jmp       short 000000000000F186
M20_L06:
       call      qword ptr [1248]; Precode of System.Globalization.NumberFormatInfo.get_CurrentInfo()
M20_L07:
       mov       r8,[rax+28]
       test      r8,r8
       jne       short 000000000000F197
       xor       r9d,r9d
       xor       r8d,r8d
       jmp       short 000000000000F19F
M20_L08:
       lea       r9,[r8+0C]
       mov       r8d,[r8+8]
M20_L09:
       mov       [rsp+30],r9
       mov       [rsp+38],r8d
       mov       [rsp+40],rbp
       mov       [rsp+48],edi
       lea       r8,[rsp+50]
       mov       [rsp+20],r8
       lea       r8,[rsp+30]
       lea       r9,[rsp+40]
       mov       ecx,esi
       mov       edx,0FFFFFFFF
       call      qword ptr [0CE0]
       jmp       near ptr 000000000000F143
M20_L10:
       call      qword ptr [0F2B8]
       int       3
; Total bytes of code 255
```
```assembly
; System.Runtime.CompilerServices.DefaultInterpolatedStringHandler.ToStringAndClear()
       push      rdi
       push      rsi
       push      rbp
       push      rbx
       sub       rsp,38
       xor       eax,eax
       mov       [rsp+28],rax
       mov       rbx,rcx
       lea       rsi,[rbx+18]
       mov       rcx,rsi
       mov       eax,[rbx+10]
       cmp       eax,[rcx+8]
       ja        short 000000000000C6F7
       mov       rcx,[rcx]
       mov       [rsp+28],rcx
       mov       [rsp+30],eax
       lea       rcx,[rsp+28]
       call      qword ptr [0BB28]; Precode of System.String.Ctor(System.ReadOnlySpan`1<Char>)
       mov       rdi,rax
       mov       rbp,[rbx+8]
       xor       eax,eax
       mov       [rbx+8],rax
       mov       [rsi],rax
       mov       [rsi+8],rax
       mov       [rbx+10],eax
       test      rbp,rbp
       je        short 000000000000C6EB
       call      qword ptr [0A098]
       mov       rcx,[rax]
       mov       rdx,rbp
       xor       r8d,r8d
       cmp       [rcx],ecx
       call      qword ptr [98C0]; Precode of System.Buffers.SharedArrayPool`1[[System.Char, System.Private.CoreLib]].Return(Char[], Boolean)
M21_L00:
       mov       rax,rdi
       add       rsp,38
       pop       rbx
       pop       rbp
       pop       rsi
       pop       rdi
       ret
M21_L01:
       call      qword ptr [0F2B8]
       int       3
; Total bytes of code 126
```
```assembly
; Tedd.MortonEncoding.Encode(UInt32, UInt32, UInt32)
       push      rbp
       mov       rbp,rsp
       mov       [rbp+10],ecx
       mov       [rbp+18],edx
       mov       [rbp+20],r8d
       mov       eax,[rbp+20]
       mov       ecx,24924924
       pdep      eax,eax,ecx
       mov       ecx,[rbp+18]
       mov       edx,12492492
       pdep      ecx,ecx,edx
       or        eax,ecx
       mov       ecx,[rbp+10]
       mov       edx,9249249
       pdep      ecx,ecx,edx
       or        eax,ecx
       pop       rbp
       ret
; Total bytes of code 59
```
**Method was not JITted yet.**
Tedd.Voxtree.OctreeThrowHelper.ThrowInvalidView()
Tedd.Voxtree.OctreeThrowHelper.ThrowCoordinate(System.String, Int32)
Tedd.Voxtree.OctreeThrowHelper.ThrowMalformed()
System.String.StrCns(UInt32, IntPtr)
System.ObjectDisposedException..ctor(System.String)
System.ArgumentOutOfRangeException..ctor(System.String)
System.ThrowHelper.ThrowArgumentOutOfRangeException()
System.InvalidOperationException..ctor(System.String)
System.ArgumentOutOfRangeException..ctor(System.String, System.Object, System.String)

## .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v3 (Job: Job-GJBZFV(IterationCount=7, IterationTime=150ms, LaunchCount=1, WarmupCount=3))

```assembly
; Tedd.Voxtree.Benchmark.Tests.DeferredChunkReads.DeferredMisses()
       push      r15
       push      r14
       push      r13
       push      r12
       push      rdi
       push      rsi
       push      rbp
       push      rbx
       sub       rsp,98
       vxorps    xmm4,xmm4,xmm4
       vmovdqu   ymmword ptr [rsp+40],ymm4
       vmovdqu   ymmword ptr [rsp+60],ymm4
       vmovdqa   xmmword ptr [rsp+80],xmm4
       mov       rbx,rcx
       mov       rsi,[rbx+28]
       xor       edi,edi
       xor       ebp,ebp
       jmp       near ptr 000000000000C725
M00_L00:
       mov       r10,[rsp+38]
M00_L01:
       mov       r9d,0FFFFFFFF
M00_L02:
       test      r9d,r9d
       jge       near ptr 000000000000C980
M00_L03:
       mov       r15,[r15+8]
       mov       rdx,[r15+8]
       cmp       [rdx+8],eax
       jbe       near ptr 000000000000CB12
       cmp       eax,[rdx+8]
       jae       near ptr 000000000000CB55
       mov       ecx,eax
       shl       rcx,4
       lea       rdx,[rdx+rcx+10]
       mov       rcx,[rdx]
       mov       eax,[rdx+8]
       mov       [rsp+54],eax
       mov       r8d,[rdx+0C]
       mov       [rsp+50],r8d
       xor       r10d,r10d
       xor       r9d,r9d
       test      rcx,rcx
       je        short 000000000000C653
       mov       r10,[rcx]
       test      dword ptr [r10],80000000
       je        near ptr 000000000000C9E1
       lea       r10,[rcx+10]
       mov       r9d,[rcx+8]
M00_L04:
       mov       eax,[rsp+54]
       and       eax,7FFFFFFF
       mov       ecx,eax
       mov       r8d,[rsp+50]
       mov       eax,r8d
       add       rax,rcx
       mov       r9d,r9d
       cmp       rax,r9
       ja        near ptr 000000000000CB4E
       add       r10,rcx
       mov       r9d,r8d
M00_L05:
       mov       rcx,r10
       mov       eax,[r15+10]
       cmp       r9d,1
       jbe       near ptr 000000000000CB55
       movzx     edx,byte ptr [rcx+1]
       and       edx,3
       mov       [rsp+78],rcx
       mov       [rsp+80],r9d
       mov       [rsp+88],eax
       mov       [rsp+8C],dl
       xor       ecx,ecx
       mov       [rsp+58],ecx
       lea       rcx,[rsp+78]
       call      qword ptr [0D7D0]; Tedd.Voxtree.OctreeSpan.get_IsValid()
       test      eax,eax
       je        near ptr 000000000000CA00
       mov       ecx,[rsp+88]
       mov       edx,1
       shlx      ecx,edx,ecx
       cmp       r13d,ecx
       jae       near ptr 000000000000CA0B
       cmp       r12d,ecx
       jae       near ptr 000000000000CA23
       cmp       r14d,ecx
       jae       near ptr 000000000000CA3B
       vmovdqu   xmm0,xmmword ptr [rsp+78]
       vmovdqu   xmmword ptr [rsp+40],xmm0
       mov       [rsp+20],r12d
       mov       [rsp+28],r14d
       lea       rcx,[rsp+58]
       mov       [rsp+30],rcx
       lea       rcx,[rsp+40]
       mov       edx,[rsp+88]
       movzx     r8d,byte ptr [rsp+8C]
       mov       r9d,r13d
       call      qword ptr [0EAC0]; Tedd.Voxtree.OctreeCodec.TryGetUnchecked(System.ReadOnlySpan`1<Byte>, Int32, Tedd.Voxtree.StorageKind, Int32, Int32, Int32, UInt32 ByRef)
       test      eax,eax
       je        near ptr 000000000000CA53
       mov       eax,[rsp+58]
M00_L06:
       add       edi,eax
       inc       ebp
       cmp       ebp,100
       jge       near ptr 000000000000C82D
M00_L07:
       cmp       ebp,[rsi+8]
       jae       near ptr 000000000000CB55
       mov       r14d,[rsi+rbp*4+10]
       mov       r15,[rbx+18]
       mov       r13d,r14d
       sar       r13d,0A
       mov       r12d,r14d
       sar       r12d,5
       and       r12d,1F
       mov       eax,ebp
       and       eax,1
       mov       [rsp+94],eax
       and       r14d,1F
       cmp       [r15],r15b
       vxorps    xmm0,xmm0,xmm0
       vmovdqu   xmmword ptr [rsp+78],xmm0
       vmovdqu   xmmword ptr [rsp+80],xmm0
       cmp       byte ptr [r15+24],0
       jne       near ptr 000000000000CA5E
       mov       rdx,[r15+8]
       mov       rcx,[rdx+8]
       cmp       [rcx+8],eax
       jbe       near ptr 000000000000CA9A
       mov       eax,[rsp+94]
       mov       edx,[rdx+10]
       mov       ecx,edx
       and       ecx,1F
       mov       r8d,1
       shlx      r8d,r8d,ecx
       cmp       r13d,r8d
       jae       near ptr 000000000000CAD6
       cmp       r12d,r8d
       jae       near ptr 000000000000CAD6
       cmp       r14d,r8d
       jae       near ptr 000000000000CAD6
       add       edx,edx
       shlx      edx,r13d,edx
       shlx      ecx,r12d,ecx
       or        edx,ecx
       or        edx,r14d
       cmp       qword ptr [r15+10],0
       jne       short 000000000000C846
       mov       r10,[r15+18]
       test      r10,r10
       je        near ptr 000000000000C5D0
       mov       [rsp+38],r10
       mov       ecx,[r10+30]
       test      ecx,ecx
       je        near ptr 000000000000C5C1
       mov       r8,[r10+10]
       test      r8,r8
       je        short 000000000000C864
       cmp       ecx,1
       jne       near ptr 000000000000C8A9
       cmp       dword ptr [r8+8],0
       jbe       near ptr 000000000000CB55
       movzx     ecx,word ptr [r8+10]
       cmp       ecx,edx
       jne       near ptr 000000000000C5BC
       xor       r9d,r9d
       mov       r10,[rsp+38]
       jmp       near ptr 000000000000C5C7
M00_L08:
       mov       eax,edi
       vzeroupper
       add       rsp,98
       pop       rbx
       pop       rbp
       pop       rsi
       pop       rdi
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       ret
M00_L09:
       mov       [rsp+20],r14d
       mov       rcx,[r15+10]
       mov       edx,eax
       mov       r8d,r13d
       mov       r9d,r12d
       cmp       [rcx],ecx
       call      qword ptr [0EA00]; Tedd.Voxtree.HotOctreeChunk.get_Item(Int32, Int32, Int32, Int32)
       jmp       near ptr 000000000000C715
M00_L10:
       mov       r10,[rsp+38]
       mov       r8,[r10+18]
       mov       r9d,ecx
       test      r8,r8
       je        near ptr 000000000000CB4E
       mov       r10,[rsp+38]
       cmp       [r8+8],r9d
       jb        near ptr 000000000000CB4E
       lea       rcx,[r8+10]
       mov       r8d,r9d
       call      qword ptr [52D8]; Precode of System.SpanHelpers.NonPackedIndexOfValueType[[System.Int32, System.Private.CoreLib],[System.SpanHelpers+DontNegate`1[[System.Int32, System.Private.CoreLib]], System.Private.CoreLib]](Int32 ByRef, Int32, Int32)
       mov       r9d,eax
       mov       eax,[rsp+94]
       mov       r10,[rsp+38]
       jmp       near ptr 000000000000C5C7
M00_L11:
       cmp       ecx,20
       jg        short 000000000000C927
       add       ecx,0F
       and       ecx,0FFFFFFF0
       cmp       [r8+8],ecx
       jb        near ptr 000000000000CB4E
       add       r8,10
       mov       r9d,ecx
       add       r9,r9
       shr       r9,5
       cmp       r9,7FFFFFFF
       ja        near ptr 000000000000CB5B
       vmovd     xmm0,edx
       vpbroadcastw ymm0,xmm0
       xor       edx,edx
       jmp       short 000000000000C8FC
M00_L12:
       mov       ecx,edx
       shl       rcx,5
       vpcmpeqw  ymm1,ymm0,[r8+rcx]
       vpmovmskb ecx,ymm1
       test      ecx,ecx
       jne       short 000000000000C90B
       inc       edx
M00_L13:
       cmp       edx,r9d
       jl        short 000000000000C8E6
       mov       r10,[rsp+38]
       jmp       near ptr 000000000000C5C1
M00_L14:
       mov       r9d,edx
       shl       r9d,4
       xor       edx,edx
       tzcnt     edx,ecx
       sar       edx,1
       add       r9d,edx
       mov       r10,[rsp+38]
       jmp       near ptr 000000000000C5C7
M00_L15:
       mov       r9d,ecx
       cmp       [r8+8],r9d
       jb        near ptr 000000000000CB4E
       lea       rcx,[r8+10]
       movzx     edx,dx
       movsx     rdx,dx
       movzx     r8d,dx
       dec       r8d
       cmp       r8d,0FE
       jae       short 000000000000C95D
       mov       r8d,r9d
       call      qword ptr [0C3F0]; System.PackedSpanHelpers.IndexOf[[System.SpanHelpers+DontNegate`1[[System.Int16, System.Private.CoreLib]], System.Private.CoreLib],[System.PackedSpanHelpers+NopTransform, System.Private.CoreLib]](Int16 ByRef, Int16, Int32)
       mov       r9d,eax
       jmp       short 000000000000C969
M00_L16:
       mov       r8d,r9d
       call      qword ptr [6220]
       mov       r9d,eax
M00_L17:
       mov       eax,r9d
       mov       r9d,eax
       mov       eax,[rsp+94]
       mov       r10,[rsp+38]
       jmp       near ptr 000000000000C5C7
M00_L18:
       mov       rcx,r10
       mov       edx,eax
       mov       [rsp+74],r9d
       mov       r8d,r9d
       call      qword ptr [0EA60]; Tedd.Voxtree.SparseVoxelEdits`1[[System.UInt32, System.Private.CoreLib]].HasValue(Int32, Int32)
       test      eax,eax
       je        short 000000000000C9D5
       mov       r15,[rsp+38]
       mov       rdx,[r15+8]
       mov       r15d,[rsp+94]
       cmp       r15d,[rdx+8]
       jae       near ptr 000000000000CB55
       mov       ecx,r15d
       mov       rdx,[rdx+rcx*8+10]
       mov       r15d,[rsp+74]
       cmp       r15d,[rdx+8]
       jae       near ptr 000000000000CB55
       mov       ecx,r15d
       mov       eax,[rdx+rcx*4+10]
       jmp       near ptr 000000000000C715
M00_L19:
       mov       eax,[rsp+94]
       jmp       near ptr 000000000000C5D0
M00_L20:
       lea       rdx,[rsp+60]
       mov       r10,[rcx]
       mov       r10,[r10+40]
       call      qword ptr [r10+28]
       mov       r10,[rsp+60]
       mov       r9d,[rsp+68]
       jmp       near ptr 000000000000C62B
M00_L21:
       call      qword ptr [0EA90]; Precode of Tedd.Voxtree.OctreeThrowHelper.ThrowInvalidView()
       jmp       near ptr 000000000000C715
M00_L22:
       mov       edx,r13d
       mov       rcx,1A600552B18
       call      qword ptr [0EAA8]; Precode of Tedd.Voxtree.OctreeThrowHelper.ThrowCoordinate(System.String, Int32)
       jmp       near ptr 000000000000C715
M00_L23:
       mov       edx,r12d
       mov       rcx,1A6005622F8
       call      qword ptr [0EAA8]; Precode of Tedd.Voxtree.OctreeThrowHelper.ThrowCoordinate(System.String, Int32)
       jmp       near ptr 000000000000C715
M00_L24:
       mov       edx,r14d
       mov       rcx,1A600562310
       call      qword ptr [0EAA8]; Precode of Tedd.Voxtree.OctreeThrowHelper.ThrowCoordinate(System.String, Int32)
       jmp       near ptr 000000000000C715
M00_L25:
       call      qword ptr [0EAD8]; Precode of Tedd.Voxtree.OctreeThrowHelper.ThrowMalformed()
       jmp       near ptr 000000000000C715
M00_L26:
       mov       rcx,offset MT_System.ObjectDisposedException
       call      0000000000005240
       mov       rbx,rax
       mov       ecx,3F5
       mov       rdx,7FF83A853BB8
       call      qword ptr [6AF0]; Precode of System.String.StrCns(UInt32, IntPtr)
       mov       rdx,rax
       mov       rcx,rbx
       call      qword ptr [7B40]; Precode of System.ObjectDisposedException..ctor(System.String)
       mov       rcx,rbx
       call      000000000000B8A0
       int       3
M00_L27:
       mov       rcx,offset MT_System.ArgumentOutOfRangeException
       call      0000000000005240
       mov       rbx,rax
       mov       ecx,3E1
       mov       rdx,7FF83A853BB8
       call      qword ptr [6AF0]; Precode of System.String.StrCns(UInt32, IntPtr)
       mov       rdx,rax
       mov       rcx,rbx
       call      qword ptr [0D1E8]; Precode of System.ArgumentOutOfRangeException..ctor(System.String)
       mov       rcx,rbx
       call      000000000000B8A0
       int       3
M00_L28:
       mov       rcx,offset MT_System.ArgumentOutOfRangeException
       call      0000000000005240
       mov       rbx,rax
       mov       ecx,3F1
       mov       rdx,7FF83A853BB8
       call      qword ptr [6AF0]; Precode of System.String.StrCns(UInt32, IntPtr)
       mov       rdx,rax
       mov       rcx,rbx
       call      qword ptr [0D1E8]; Precode of System.ArgumentOutOfRangeException..ctor(System.String)
       mov       rcx,rbx
       call      000000000000B8A0
       int       3
M00_L29:
       mov       rcx,offset MT_System.ArgumentOutOfRangeException
       call      0000000000005240
       mov       rdi,rax
       mov       ecx,3E1
       mov       rdx,7FF83A853BB8
       call      qword ptr [6AF0]; Precode of System.String.StrCns(UInt32, IntPtr)
       mov       rdx,rax
       mov       rcx,rdi
       call      qword ptr [0D1E8]; Precode of System.ArgumentOutOfRangeException..ctor(System.String)
       mov       rcx,rdi
       call      000000000000B8A0
       int       3
M00_L30:
       call      qword ptr [7C30]; Precode of System.ThrowHelper.ThrowArgumentOutOfRangeException()
       int       3
M00_L31:
       call      0000000000001788
       int       3
M00_L32:
       call      0000000000001770
       int       3
; Total bytes of code 1505
```
```assembly
; Tedd.Voxtree.OctreeSpan.get_IsValid()
       cmp       dword ptr [rcx+8],0
       setne     al
       movzx     eax,al
       ret
; Total bytes of code 11
```
```assembly
; Tedd.Voxtree.OctreeCodec.TryGetUnchecked(System.ReadOnlySpan`1<Byte>, Int32, Tedd.Voxtree.StorageKind, Int32, Int32, Int32, UInt32 ByRef)
       push      r15
       push      r14
       push      r13
       push      r12
       push      rdi
       push      rsi
       push      rbp
       push      rbx
       sub       rsp,38
       vxorps    xmm4,xmm4,xmm4
       vmovdqa   xmmword ptr [rsp+20],xmm4
       xor       eax,eax
       mov       [rsp+30],rax
       mov       rbx,rcx
       mov       eax,[rsp+0A0]
       mov       r10d,[rsp+0A8]
       mov       rcx,[rsp+0B0]
       xor       r11d,r11d
       mov       [rcx],r11d
       mov       r11d,1
       shlx      r11d,r11d,edx
       movzx     r8d,r8b
       cmp       r8d,1
       je        near ptr 000000000000C444
       cmp       r8d,2
       je        near ptr 000000000000C498
       test      edx,edx
       je        near ptr 000000000000C4EB
       mov       r8d,[rbx+8]
       cmp       r8d,0C
       jl        near ptr 000000000000C4EB
       lea       r11d,[r8+0FFFF]
       mov       esi,r11d
       cmp       esi,r8d
       ja        near ptr 000000000000C4CF
       mov       rdi,[rbx]
       mov       rbx,rdi
       cmp       r11d,r8d
       jae       near ptr 000000000000C4FE
       mov       r8d,r11d
       movzx     r8d,byte ptr [rdi+r8]
       mov       r11d,esi
       sub       r11d,r8d
       sub       r8d,9
       cmp       r8d,20
       ja        near ptr 000000000000C4EB
       cmp       r11d,2
       jl        near ptr 000000000000C4EB
       dec       edx
       js        near ptr 000000000000C4EB
M02_L00:
       cmp       r11d,esi
       jae       near ptr 000000000000C4EB
       lea       r8d,[r11+1]
       mov       edi,r11d
       movzx     edi,byte ptr [rbx+rdi]
       mov       ebp,edx
       and       ebp,1F
       sarx      r14d,r9d,ebp
       and       r14d,1
       shl       r14d,2
       mov       [rsp+0A0],eax
       sarx      r15d,eax,ebp
       and       r15d,1
       add       r15d,r15d
       or        r14d,r15d
       sarx      ebp,r10d,ebp
       and       ebp,1
       or        ebp,r14d
       jle       short 000000000000C37B
       mov       r14d,ebp
M02_L01:
       mov       r15d,r8d
       xor       r13d,r13d
       cmp       r15d,esi
       jae       near ptr 000000000000C4EB
M02_L02:
       lea       r12d,[r8+1]
       mov       r8d,r8d
       movzx     r8d,byte ptr [rbx+r8]
       cmp       r13d,1C
       je        near ptr 000000000000C4D6
M02_L03:
       test      r8b,80
       jne       short 000000000000C35F
       mov       r13d,r12d
       sub       r13d,r15d
       cmp       r13d,1
       je        short 000000000000C355
       test      r8b,7F
       je        near ptr 000000000000C4EB
M02_L04:
       dec       r14d
       je        short 000000000000C37E
       mov       r8d,r12d
       jmp       short 000000000000C314
M02_L05:
       add       r13d,7
       cmp       r13d,1C
       jg        near ptr 000000000000C4EB
       cmp       r12d,esi
       mov       r8d,r12d
       jae       near ptr 000000000000C4EB
       jmp       short 000000000000C323
M02_L06:
       mov       r12d,r8d
M02_L07:
       xor       r8d,r8d
       mov       r14d,r12d
       xor       r15d,r15d
       cmp       r14d,esi
       jae       near ptr 000000000000C4EB
M02_L08:
       mov       r13d,r12d
       lea       r12d,[r13+1]
       cmp       r13d,esi
       jae       near ptr 000000000000C4FE
       movzx     r13d,byte ptr [rbx+r13]
       cmp       r15d,1C
       je        near ptr 000000000000C4E1
M02_L09:
       mov       eax,r13d
       and       eax,7F
       shlx      eax,eax,r15d
       or        r8d,eax
       test      r13b,80
       jne       short 000000000000C3F6
       mov       eax,r12d
       sub       eax,r14d
       cmp       eax,1
       je        short 000000000000C3D8
       test      r13b,7F
       je        near ptr 000000000000C4EB
M02_L10:
       bt        edi,ebp
       jae       short 000000000000C40F
       mov       [rcx],r8d
M02_L11:
       mov       eax,1
       add       rsp,38
       pop       rbx
       pop       rbp
       pop       rsi
       pop       rdi
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       ret
M02_L12:
       add       r15d,7
       cmp       r15d,1C
       jg        near ptr 000000000000C4EB
       cmp       r12d,esi
       jae       near ptr 000000000000C4EB
       jmp       short 000000000000C390
M02_L13:
       test      edx,edx
       je        near ptr 000000000000C4EB
       test      r8d,r8d
       je        near ptr 000000000000C4EB
       lea       eax,[r11+0FFFE]
       cmp       r8d,eax
       ja        near ptr 000000000000C4EB
       sub       r11d,r8d
       dec       edx
       mov       eax,[rsp+0A0]
       jns       near ptr 000000000000C2C7
       jmp       near ptr 000000000000C4EB
M02_L14:
       mov       [rsp+0B0],rcx
       mov       dword ptr [rsp+30],2
       vmovdqu   xmm0,xmmword ptr [rbx]
       vmovdqu   xmmword ptr [rsp+20],xmm0
       lea       rcx,[rsp+20]
       lea       rdx,[rsp+30]
       mov       r8,[rsp+0B0]
       call      qword ptr [0D650]; Tedd.Voxtree.OctreeCodec.TryReadVarUInt(System.ReadOnlySpan`1<Byte>, Int32 ByRef, UInt32 ByRef)
       test      eax,eax
       je        short 000000000000C4EB
       mov       eax,[rsp+30]
       cmp       eax,[rbx+8]
       sete      al
       movzx     eax,al
       add       rsp,38
       pop       rbx
       pop       rbp
       pop       rsi
       pop       rdi
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       ret
M02_L15:
       imul      r9d,r11d
       imul      r9d,r11d
       imul      eax,r11d
       add       eax,r9d
       add       eax,r10d
       lea       eax,[rax*4+2]
       mov       edx,eax
       add       rdx,4
       mov       r8d,[rbx+8]
       cmp       rdx,r8
       ja        short 000000000000C4CF
       mov       rdi,[rbx]
       add       rax,rdi
       mov       eax,[rax]
       mov       [rcx],eax
       jmp       near ptr 000000000000C3E0
M02_L16:
       call      qword ptr [7C30]; Precode of System.ThrowHelper.ThrowArgumentOutOfRangeException()
       int       3
M02_L17:
       test      r8b,0F0
       jne       short 000000000000C4EB
       jmp       near ptr 000000000000C339
M02_L18:
       test      r13b,0F0
       je        near ptr 000000000000C3AF
M02_L19:
       xor       eax,eax
       add       rsp,38
       pop       rbx
       pop       rbp
       pop       rsi
       pop       rdi
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       ret
M02_L20:
       call      0000000000001788
       int       3
; Total bytes of code 772
```
```assembly
; Tedd.Voxtree.HotOctreeChunk.get_Item(Int32, Int32, Int32, Int32)
       push      rbp
       sub       rsp,40
       lea       rbp,[rsp+40]
       xor       eax,eax
       mov       [rbp+0FFF0],rax
       mov       [rbp+0FFF8],rax
       mov       [rbp+10],rcx
       mov       [rbp+18],edx
       mov       [rbp+20],r8d
       mov       [rbp+28],r9d
       lea       rdx,[rbp+0FFF0]
       mov       rcx,[rbp+10]
       mov       r8d,[rbp+18]
       call      qword ptr [0E628]; Tedd.Voxtree.HotOctreeChunk.GetChannelSpan(Int32)
       mov       rcx,[rbp+10]
       call      qword ptr [0E640]; Tedd.Voxtree.HotOctreeChunk.get_Levels()
       mov       [rbp+0FFE8],eax
       mov       dword ptr [rsp+20],1
       mov       r9d,[rbp+0FFE8]
       mov       edx,[rbp+28]
       mov       r8d,[rbp+30]
       mov       ecx,[rbp+20]
       call      qword ptr [0E658]; Tedd.Voxtree.DenseVoxel.GetIndex(Int32, Int32, Int32, Int32, Tedd.Voxtree.DenseVoxelLayout)
       mov       [rbp+0FFEC],eax
       mov       eax,[rbp+0FFF8]
       cmp       [rbp+0FFEC],eax
       jae       short 0000000000008619
       mov       eax,[rbp+0FFEC]
       mov       rcx,[rbp+0FFF0]
       mov       eax,[rcx+rax*4]
       add       rsp,40
       pop       rbp
       ret
M03_L00:
       call      0000000000001788
       int       3
; Total bytes of code 127
```
```assembly
; System.SpanHelpers.NonPackedIndexOfValueType[[System.Int32, System.Private.CoreLib],[System.SpanHelpers+DontNegate`1[[System.Int32, System.Private.CoreLib]], System.Private.CoreLib]](Int32 ByRef, Int32, Int32)
       cmp       r8d,4
       jl        near ptr 0000000000000E5A
       movd      xmm0,edx
       pshufd    xmm0,xmm0,0
       mov       rdx,rcx
       lea       eax,[r8+0FFFC]
       cdqe
       shl       rax,2
       lea       r10,[rdx+rax]
       movups    xmm1,[rcx]
       pcmpeqd   xmm1,xmm0
       ptest     xmm1,xmm1
       je        short 0000000000000E13
M04_L00:
       movmskps  eax,xmm1
       bsf       r8d,eax
       mov       r10d,20
       test      eax,eax
       cmove     r8d,r10d
       mov       rax,rdx
       sub       rax,rcx
       shr       rax,2
       add       eax,r8d
M04_L01:
       ret
M04_L02:
       add       rdx,10
       cmp       rdx,r10
       jbe       near ptr 0000000000000F43
       mov       ecx,r8d
       test      cl,3
       je        near ptr 0000000000000F5A
       movups    xmm1,[r10]
       pcmpeqd   xmm1,xmm0
       ptest     xmm1,xmm1
       je        near ptr 0000000000000F5A
       movmskps  edx,xmm1
       bsf       r8d,edx
       mov       ecx,20
       test      edx,edx
       cmove     r8d,ecx
       shr       rax,2
       add       eax,r8d
       jmp       short 0000000000000E12
M04_L03:
       xor       r10d,r10d
       cmp       r8d,8
       jge       short 0000000000000E8D
M04_L04:
       cmp       r8d,4
       jge       short 0000000000000EDC
M04_L05:
       test      r8d,r8d
       jle       near ptr 0000000000000F5A
M04_L06:
       dec       r8d
       cmp       [rcx+r10*4],edx
       je        short 0000000000000E88
       inc       r10
       test      r8d,r8d
       jg        short 0000000000000E72
       jmp       near ptr 0000000000000F5A
M04_L07:
       mov       eax,r10d
       jmp       short 0000000000000E12
M04_L08:
       add       r8d,0FFFFFFF8
       cmp       [rcx+r10*4],edx
       je        short 0000000000000E88
       cmp       [rcx+r10*4+4],edx
       je        near ptr 0000000000000F3A
       cmp       [rcx+r10*4+8],edx
       je        near ptr 0000000000000F31
       cmp       [rcx+r10*4+0C],edx
       je        short 0000000000000F28
       cmp       [rcx+r10*4+10],edx
       je        short 0000000000000F1F
       cmp       [rcx+r10*4+14],edx
       je        short 0000000000000F16
       cmp       [rcx+r10*4+18],edx
       je        short 0000000000000F0D
       cmp       [rcx+r10*4+1C],edx
       je        short 0000000000000F04
       add       r10,8
       cmp       r8d,8
       jge       short 0000000000000E8D
       jmp       short 0000000000000E63
M04_L09:
       add       r8d,0FFFFFFFC
       cmp       [rcx+r10*4],edx
       je        short 0000000000000E88
       cmp       [rcx+r10*4+4],edx
       je        short 0000000000000F3A
       cmp       [rcx+r10*4+8],edx
       je        short 0000000000000F31
       cmp       [rcx+r10*4+0C],edx
       je        short 0000000000000F28
       add       r10,4
       jmp       near ptr 0000000000000E69
M04_L10:
       lea       eax,[r10+7]
       jmp       near ptr 0000000000000E12
M04_L11:
       lea       eax,[r10+6]
       jmp       near ptr 0000000000000E12
M04_L12:
       lea       eax,[r10+5]
       jmp       near ptr 0000000000000E12
M04_L13:
       lea       eax,[r10+4]
       jmp       near ptr 0000000000000E12
M04_L14:
       lea       eax,[r10+3]
       jmp       near ptr 0000000000000E12
M04_L15:
       lea       eax,[r10+2]
       jmp       near ptr 0000000000000E12
M04_L16:
       lea       eax,[r10+1]
       jmp       near ptr 0000000000000E12
M04_L17:
       movups    xmm1,[rdx]
       pcmpeqd   xmm1,xmm0
       ptest     xmm1,xmm1
       jne       near ptr 0000000000000DF2
       jmp       near ptr 0000000000000E13
M04_L18:
       mov       eax,0FFFFFFFF
       ret
; Total bytes of code 416
```
```assembly
; System.PackedSpanHelpers.IndexOf[[System.SpanHelpers+DontNegate`1[[System.Int16, System.Private.CoreLib]], System.Private.CoreLib],[System.PackedSpanHelpers+NopTransform, System.Private.CoreLib]](Int16 ByRef, Int16, Int32)
       push      r14
       push      rdi
       push      rsi
       push      rbp
       push      rbx
       sub       rsp,50
       vmovaps   [rsp+40],xmm6
       vmovaps   [rsp+30],xmm7
       vmovaps   [rsp+20],xmm8
       mov       rsi,rcx
       mov       edi,edx
       mov       ebx,r8d
       cmp       ebx,8
       jl        near ptr 000000000000D51C
       mov       rbp,rsi
       cmp       ebx,10
       jle       near ptr 000000000000D499
       vmovd     xmm6,edi
       vpbroadcastb ymm6,xmm6
       cmp       ebx,20
       jle       near ptr 000000000000D3D4
       lea       ecx,[rbx+0FFE0]
       movsxd    rcx,ecx
       lea       rdi,[rbp+rcx*2]
       vmovups   ymm0,[rsi]
       vpackuswb ymm0,ymm0,[rsi+20]
       vpcmpeqb  ymm7,ymm0,ymm6
       vptest    ymm7,ymm7
       jne       short 000000000000D383
M05_L00:
       add       rbp,40
       cmp       rbp,rdi
       jae       short 000000000000D3B9
       mov       rcx,7FF83A4A8F38
       vextractf128 xmm8,ymm6,1
       call      0000000000008420
       vmovups   ymm0,[rbp]
       vpackuswb ymm0,ymm0,[rbp+20]
       vinsertf128 ymm6,ymm6,xmm8,1
       vpcmpeqb  ymm7,ymm0,ymm6
       vptest    ymm7,ymm7
       je        short 000000000000D34A
M05_L01:
       mov       rcx,7FF83A4A8F2C
       vextractf128 xmm8,ymm7,1
       call      0000000000008420
       mov       rax,rbp
       sub       rax,rsi
       shr       rax,1
       vinsertf128 ymm7,ymm7,xmm8,1
       vpermq    ymm0,ymm7,0D8
       vpmovmskb ecx,ymm0
       tzcnt     ecx,ecx
       add       eax,ecx
       jmp       short 000000000000D41C
M05_L02:
       mov       rcx,7FF83A4A8F34
       vextractf128 xmm8,ymm6,1
       call      0000000000008420
       vinsertf128 ymm6,ymm6,xmm8,1
M05_L03:
       add       ebx,0FFFFFFF0
       movsxd    rcx,ebx
       lea       rbx,[rsi+rcx*2]
       cmp       rbp,rbx
       ja        short 000000000000D43C
       mov       rdi,rbp
M05_L04:
       vmovups   ymm0,[rdi]
       vpackuswb ymm0,ymm0,[rbx]
       vpcmpeqb  ymm6,ymm0,ymm6
       vptest    ymm6,ymm6
       jne       short 000000000000D45C
       mov       rcx,7FF83A4A8F44
       call      0000000000008420
M05_L05:
       mov       rcx,7FF83A4A8F54
       call      0000000000008420
       mov       eax,0FFFFFFFF
M05_L06:
       vzeroupper
       vmovaps   xmm6,[rsp+40]
       vmovaps   xmm7,[rsp+30]
       vmovaps   xmm8,[rsp+20]
       add       rsp,50
       pop       rbx
       pop       rbp
       pop       rsi
       pop       rdi
       pop       r14
       ret
M05_L07:
       mov       rcx,7FF83A4A8F3C
       vextractf128 xmm8,ymm6,1
       call      0000000000008420
       mov       rdi,rbx
       vinsertf128 ymm6,ymm6,xmm8,1
       jmp       short 000000000000D3E6
M05_L08:
       mov       rcx,7FF83A4A8F40
       vextractf128 xmm7,ymm6,1
       call      0000000000008420
       vinsertf128 ymm6,ymm6,xmm7,1
       vpermq    ymm0,ymm6,0D8
       vpmovmskb ecx,ymm0
       tzcnt     ecx,ecx
       cmp       ecx,10
       jge       near ptr 000000000000D670
M05_L09:
       sub       rdi,rsi
       shr       rdi,1
       lea       eax,[rdi+rcx]
       jmp       short 000000000000D41C
M05_L10:
       mov       rcx,7FF83A4A8F30
       call      0000000000008420
       vmovd     xmm6,edi
       vpbroadcastb xmm6,xmm6
       lea       ecx,[rbx+0FFF8]
       movsxd    rcx,ecx
       lea       rbx,[rsi+rcx*2]
       cmp       rsi,rbx
       ja        near ptr 000000000000D67B
       mov       rdi,rsi
M05_L11:
       vmovups   xmm0,[rdi]
       vpackuswb xmm0,xmm0,[rbx]
       vpcmpeqb  xmm6,xmm0,xmm6
       vptest    xmm6,xmm6
       jne       short 000000000000D4EE
       mov       rcx,7FF83A4A8F50
       call      0000000000008420
       jmp       near ptr 000000000000D408
M05_L12:
       mov       rcx,7FF83A4A8F4C
       call      0000000000008420
       vpmovmskb ecx,xmm6
       tzcnt     ecx,ecx
       cmp       ecx,8
       jge       near ptr 000000000000D692
M05_L13:
       sub       rdi,rsi
       shr       rdi,1
       lea       eax,[rdi+rcx]
       jmp       near ptr 000000000000D41C
M05_L14:
       xor       ebp,ebp
       cmp       ebx,4
       jl        short 000000000000D575
       add       ebx,0FFFFFFFC
       movsx     rcx,word ptr [rsi]
       movsx     r14,di
       cmp       ecx,r14d
       je        near ptr 000000000000D5BE
       movsx     rcx,word ptr [rsi+2]
       cmp       ecx,r14d
       je        near ptr 000000000000D5EF
       movsx     rcx,word ptr [rsi+4]
       cmp       ecx,r14d
       je        near ptr 000000000000D623
       movsx     rcx,word ptr [rsi+6]
       cmp       ecx,r14d
       je        near ptr 000000000000D657
       mov       rcx,7FF83A4A8F20
       call      0000000000008420
       mov       ebp,4
M05_L15:
       test      ebx,ebx
       jle       near ptr 000000000000D408
       movsx     r14,di
M05_L16:
       dec       ebx
       movsx     rcx,word ptr [rsi+rbp*2]
       cmp       ecx,r14d
       je        short 000000000000D5A8
       mov       rcx,7FF83A4A8F28
       call      0000000000008420
       inc       rbp
       test      ebx,ebx
       jg        short 000000000000D581
       jmp       near ptr 000000000000D408
M05_L17:
       mov       rcx,7FF83A4A8F24
       call      0000000000008420
       mov       eax,ebp
       jmp       near ptr 000000000000D41C
M05_L18:
       mov       rcx,7FF83A4A8F10
       call      0000000000008420
       xor       eax,eax
       vzeroupper
       vmovaps   xmm6,[rsp+40]
       vmovaps   xmm7,[rsp+30]
       vmovaps   xmm8,[rsp+20]
       add       rsp,50
       pop       rbx
       pop       rbp
       pop       rsi
       pop       rdi
       pop       r14
       ret
M05_L19:
       mov       rcx,7FF83A4A8F14
       call      0000000000008420
       mov       eax,1
       vzeroupper
       vmovaps   xmm6,[rsp+40]
       vmovaps   xmm7,[rsp+30]
       vmovaps   xmm8,[rsp+20]
       add       rsp,50
       pop       rbx
       pop       rbp
       pop       rsi
       pop       rdi
       pop       r14
       ret
M05_L20:
       mov       rcx,7FF83A4A8F18
       call      0000000000008420
       mov       eax,2
       vzeroupper
       vmovaps   xmm6,[rsp+40]
       vmovaps   xmm7,[rsp+30]
       vmovaps   xmm8,[rsp+20]
       add       rsp,50
       pop       rbx
       pop       rbp
       pop       rsi
       pop       rdi
       pop       r14
       ret
M05_L21:
       mov       rcx,7FF83A4A8F1C
       call      0000000000008420
       mov       eax,3
       jmp       near ptr 000000000000D41C
M05_L22:
       mov       rdi,rbx
       add       ecx,0FFFFFFF0
       jmp       near ptr 000000000000D48E
M05_L23:
       mov       rcx,7FF83A4A8F48
       call      0000000000008420
       mov       rdi,rbx
       jmp       near ptr 000000000000D4C7
M05_L24:
       mov       rdi,rbx
       add       ecx,0FFFFFFF8
       jmp       near ptr 000000000000D50E
; Total bytes of code 957
```
```assembly
; Tedd.Voxtree.SparseVoxelEdits`1[[System.UInt32, System.Private.CoreLib]].HasValue(Int32, Int32)
       push      rbp
       sub       rsp,20
       lea       rbp,[rsp+20]
       mov       [rbp+10],rcx
       mov       [rbp+18],edx
       mov       [rbp+20],r8d
       mov       rax,[rbp+10]
       mov       rax,[rax+20]
       mov       rcx,[rbp+10]
       mov       ecx,[rcx+2C]
       imul      ecx,[rbp+18]
       mov       edx,[rbp+20]
       sar       edx,6
       add       ecx,edx
       cmp       ecx,[rax+8]
       jae       short 0000000000008FAB
       mov       edx,ecx
       lea       rax,[rax+rdx*8+10]
       mov       ecx,1
       mov       edx,[rbp+20]
       shlx      rcx,rcx,rdx
       and       rcx,[rax]
       test      rcx,rcx
       setne     al
       movzx     eax,al
       add       rsp,20
       pop       rbp
       ret
M06_L00:
       call      0000000000001788
       int       3
; Total bytes of code 97
```
```assembly
; Tedd.Voxtree.OctreeCodec.TryReadVarUInt(System.ReadOnlySpan`1<Byte>, Int32 ByRef, UInt32 ByRef)
       push      rbx
       sub       rsp,20
       mov       rax,[rcx]
       mov       ecx,[rcx+8]
       xor       r10d,r10d
       mov       [r8],r10d
       mov       r10d,[rdx]
       mov       r9d,r10d
       xor       r11d,r11d
       cmp       r10d,ecx
       jae       short 000000000000A1E7
M07_L00:
       mov       r10d,[rdx]
       lea       ebx,[r10+1]
       mov       [rdx],ebx
       cmp       r10d,ecx
       jae       short 000000000000A1EF
       movzx     r10d,byte ptr [rax+r10]
       cmp       r11d,1C
       je        short 000000000000A1E1
M07_L01:
       mov       ebx,r10d
       and       ebx,7F
       shlx      ebx,ebx,r11d
       or        [r8],ebx
       test      r10b,80
       jne       short 000000000000A1C1
       mov       eax,[rdx]
       sub       eax,r9d
       cmp       eax,1
       jne       short 000000000000A1D1
       mov       eax,1
       add       rsp,20
       pop       rbx
       ret
M07_L02:
       add       r11d,7
       cmp       r11d,1C
       jg        short 000000000000A1E7
       cmp       [rdx],ecx
       jae       short 000000000000A1E7
       jmp       short 000000000000A17F
M07_L03:
       test      r10b,7F
       setne     al
       movzx     eax,al
       add       rsp,20
       pop       rbx
       ret
M07_L04:
       test      r10b,0F0
       je        short 000000000000A198
M07_L05:
       xor       eax,eax
       add       rsp,20
       pop       rbx
       ret
M07_L06:
       call      0000000000001788
       int       3
; Total bytes of code 149
```
```assembly
; Tedd.Voxtree.HotOctreeChunk.GetChannelSpan(Int32)
       push      rbp
       sub       rsp,50
       lea       rbp,[rsp+50]
       xor       eax,eax
       mov       [rbp+0FFD8],rax
       vxorps    xmm4,xmm4,xmm4
       vmovdqu   ymmword ptr [rbp+0FFE0],ymm4
       mov       [rbp+10],rcx
       mov       [rbp+18],rdx
       mov       [rbp+20],r8d
       mov       rcx,[rbp+10]
       call      qword ptr [0E688]; Tedd.Voxtree.HotOctreeChunk.GetValues()
       mov       [rbp+0FFF0],rax
       mov       rax,[rbp+0FFF0]
       mov       [rbp+0FFE8],rax
       mov       rcx,[rbp+10]
       call      qword ptr [0E6A0]; Tedd.Voxtree.HotOctreeChunk.get_ChannelCount()
       cmp       eax,[rbp+20]
       ja        short 000000000000823E
       mov       rcx,offset MT_System.ArgumentOutOfRangeException
       call      0000000000005240
       mov       [rbp+0FFE0],rax
       mov       ecx,3E1
       mov       rdx,7FF83A853BB8
       call      qword ptr [6AF0]; Precode of System.String.StrCns(UInt32, IntPtr)
       mov       [rbp+0FFD8],rax
       mov       rdx,[rbp+0FFD8]
       mov       rcx,[rbp+0FFE0]
       call      qword ptr [0D1E8]; Precode of System.ArgumentOutOfRangeException..ctor(System.String)
       mov       rcx,[rbp+0FFE0]
       call      000000000000B8A0
       int       3
M08_L00:
       mov       rcx,[rbp+10]
       call      qword ptr [0E640]; Tedd.Voxtree.HotOctreeChunk.get_Levels()
       mov       ecx,eax
       call      qword ptr [0D1D0]; Tedd.Voxtree.OctreeCodec.GetVoxelCount(Int32)
       mov       [rbp+0FFFC],eax
       mov       eax,[rbp+20]
       mov       r8d,eax
       imul      r8d,[rbp+0FFFC]
       mov       rcx,[rbp+18]
       mov       rdx,[rbp+0FFE8]
       mov       r9d,[rbp+0FFFC]
       call      qword ptr [0E670]; System.MemoryExtensions.AsSpan[[System.UInt32, System.Private.CoreLib]](UInt32[], Int32, Int32)
       mov       rax,[rbp+18]
       add       rsp,50
       pop       rbp
       ret
; Total bytes of code 202
```
```assembly
; Tedd.Voxtree.HotOctreeChunk.get_Levels()
       push      rbp
       mov       rbp,rsp
       mov       [rbp+10],rcx
       mov       rax,[rbp+10]
       mov       eax,[rax+20]
       pop       rbp
       ret
; Total bytes of code 17
```
```assembly
; Tedd.Voxtree.DenseVoxel.GetIndex(Int32, Int32, Int32, Int32, Tedd.Voxtree.DenseVoxelLayout)
       push      rbp
       sub       rsp,40
       lea       rbp,[rsp+40]
       vxorps    xmm4,xmm4,xmm4
       vmovdqu   xmmword ptr [rbp+0FFE8],xmm4
       xor       eax,eax
       mov       [rbp+0FFF8],rax
       mov       [rbp+10],ecx
       mov       [rbp+18],edx
       mov       [rbp+20],r8d
       mov       [rbp+28],r9d
       mov       ecx,[rbp+28]
       call      qword ptr [0D1B8]; Tedd.Voxtree.OctreeCodec.ValidateLevels(Int32)
       mov       ecx,[rbp+30]
       call      qword ptr [0D098]; Tedd.Voxtree.DenseVoxel.Validate(Tedd.Voxtree.DenseVoxelLayout)
       mov       eax,1
       mov       ecx,[rbp+28]
       shlx      eax,eax,ecx
       mov       [rbp+0FFFC],eax
       mov       eax,[rbp+10]
       cmp       eax,[rbp+0FFFC]
       jae       short 0000000000008430
       mov       eax,[rbp+18]
       cmp       eax,[rbp+0FFFC]
       jae       short 0000000000008474
       mov       eax,[rbp+20]
       cmp       eax,[rbp+0FFFC]
       jb        short 0000000000008485
       mov       rcx,7FF83A940B68
       call      0000000000008420
M10_L00:
       mov       rcx,offset MT_System.ArgumentOutOfRangeException
       call      0000000000005240
       mov       [rbp+0FFF0],rax
       mov       ecx,3F1
       mov       rdx,7FF83A853BB8
       call      qword ptr [6AF0]; Precode of System.String.StrCns(UInt32, IntPtr)
       mov       [rbp+0FFE8],rax
       mov       rdx,[rbp+0FFE8]
       mov       rcx,[rbp+0FFF0]
       call      qword ptr [0D1E8]; Precode of System.ArgumentOutOfRangeException..ctor(System.String)
       mov       rcx,[rbp+0FFF0]
       call      000000000000B8A0
       int       3
M10_L01:
       mov       rcx,7FF83A940B6C
       call      0000000000008420
       jmp       short 0000000000008430
M10_L02:
       mov       rcx,7FF83A940B70
       call      0000000000008420
       mov       eax,[rbp+30]
       mov       [rsp+20],eax
       mov       ecx,[rbp+10]
       mov       edx,[rbp+18]
       mov       r8d,[rbp+20]
       mov       r9d,[rbp+0FFFC]
       call      qword ptr [0E9B8]; Tedd.Voxtree.DenseVoxel.Index(Int32, Int32, Int32, Int32, Tedd.Voxtree.DenseVoxelLayout)
       nop
       add       rsp,40
       pop       rbp
       ret
; Total bytes of code 246
```
```assembly
; Tedd.Voxtree.HotOctreeChunk.GetValues()
       push      rbp
       sub       rsp,40
       lea       rbp,[rsp+40]
       vxorps    xmm4,xmm4,xmm4
       vmovdqu   ymmword ptr [rbp+0FFE0],ymm4
       mov       [rbp+10],rcx
       mov       rax,[rbp+10]
       mov       rax,[rax+8]
       mov       [rbp+0FFF8],rax
       mov       rax,[rbp+0FFF8]
       mov       [rbp+0FFF0],rax
       cmp       qword ptr [rbp+0FFF8],0
       jne       short 0000000000008306
       mov       rcx,offset MT_System.InvalidOperationException
       call      0000000000005240
       mov       [rbp+0FFE8],rax
       mov       ecx,9F3
       mov       rdx,7FF83A853BB8
       call      qword ptr [6AF0]; Precode of System.String.StrCns(UInt32, IntPtr)
       mov       [rbp+0FFE0],rax
       mov       rdx,[rbp+0FFE0]
       mov       rcx,[rbp+0FFE8]
       call      qword ptr [66D0]; Precode of System.InvalidOperationException..ctor(System.String)
       mov       rcx,[rbp+0FFE8]
       call      000000000000B8A0
       int       3
M11_L00:
       mov       rax,[rbp+0FFF0]
       add       rsp,40
       pop       rbp
       ret
; Total bytes of code 128
```
```assembly
; Tedd.Voxtree.HotOctreeChunk.get_ChannelCount()
       push      rbp
       mov       rbp,rsp
       mov       [rbp+10],rcx
       mov       rax,[rbp+10]
       mov       eax,[rax+24]
       pop       rbp
       ret
; Total bytes of code 17
```
```assembly
; Tedd.Voxtree.OctreeCodec.GetVoxelCount(Int32)
       push      rbp
       mov       rbp,rsp
       mov       [rbp+10],ecx
       mov       eax,1
       mov       ecx,[rbp+10]
       lea       ecx,[rcx+rcx*2]
       shlx      eax,eax,ecx
       pop       rbp
       ret
; Total bytes of code 25
```
```assembly
; System.MemoryExtensions.AsSpan[[System.UInt32, System.Private.CoreLib]](UInt32[], Int32, Int32)
       sub       rsp,28
       test      rdx,rdx
       je        short 000000000000838F
       mov       r8d,r8d
       mov       eax,r9d
       add       rax,r8
       mov       r10d,[rdx+8]
       cmp       rax,r10
       ja        short 000000000000839B
       lea       rax,[rdx+r8*4+10]
M14_L00:
       mov       [rcx],rax
       mov       [rcx+8],r9d
       mov       rax,rcx
       add       rsp,28
       ret
M14_L01:
       or        r8d,r9d
       jne       short 000000000000839B
       xor       eax,eax
       xor       r9d,r9d
       jmp       short 0000000000008380
M14_L02:
       call      qword ptr [7C30]; Precode of System.ThrowHelper.ThrowArgumentOutOfRangeException()
       int       3
; Total bytes of code 66
```
```assembly
; Tedd.Voxtree.OctreeCodec.ValidateLevels(Int32)
       push      rbp
       sub       rsp,80
       lea       rbp,[rsp+80]
       xor       eax,eax
       mov       [rbp+0FFA8],rax
       vxorps    xmm4,xmm4,xmm4
       vmovdqu   ymmword ptr [rbp+0FFB0],ymm4
       vmovdqu   ymmword ptr [rbp+0FFD0],ymm4
       vmovdqa   xmmword ptr [rbp+0FFF0],xmm4
       mov       [rbp+10],ecx
       cmp       dword ptr [rbp+10],9
       jbe       near ptr 000000000000805F
       mov       rcx,offset MT_System.Int32
       call      0000000000005240
       mov       [rbp+0FFD0],rax
       mov       rax,[rbp+0FFD0]
       mov       ecx,[rbp+10]
       mov       [rax+8],ecx
       lea       rcx,[rbp+0FFD8]
       mov       edx,31
       mov       r8d,1
       call      qword ptr [67C0]; System.Runtime.CompilerServices.DefaultInterpolatedStringHandler..ctor(Int32, Int32)
       mov       ecx,1341
       mov       rdx,7FF83A853BB8
       call      qword ptr [6AF0]; Precode of System.String.StrCns(UInt32, IntPtr)
       mov       [rbp+0FFC0],rax
       mov       rdx,[rbp+0FFC0]
       lea       rcx,[rbp+0FFD8]
       call      qword ptr [6C28]; System.Runtime.CompilerServices.DefaultInterpolatedStringHandler.AppendLiteral(System.String)
       lea       rcx,[rbp+0FFD8]
       mov       edx,9
       call      qword ptr [6AF0]; System.Runtime.CompilerServices.DefaultInterpolatedStringHandler.AppendFormatted[[System.Int32, System.Private.CoreLib]](Int32)
       mov       ecx,369
       mov       rdx,7FF83A853BB8
       call      qword ptr [6AF0]; Precode of System.String.StrCns(UInt32, IntPtr)
       mov       [rbp+0FFB8],rax
       mov       rdx,[rbp+0FFB8]
       lea       rcx,[rbp+0FFD8]
       call      qword ptr [6C28]; System.Runtime.CompilerServices.DefaultInterpolatedStringHandler.AppendLiteral(System.String)
       mov       rcx,offset MT_System.ArgumentOutOfRangeException
       call      0000000000005240
       mov       [rbp+0FFC8],rax
       mov       ecx,1333
       mov       rdx,7FF83A853BB8
       call      qword ptr [6AF0]; Precode of System.String.StrCns(UInt32, IntPtr)
       mov       [rbp+0FFB0],rax
       lea       rcx,[rbp+0FFD8]
       call      qword ptr [67F0]; System.Runtime.CompilerServices.DefaultInterpolatedStringHandler.ToStringAndClear()
       mov       [rbp+0FFA8],rax
       mov       rdx,[rbp+0FFB0]
       mov       r9,[rbp+0FFA8]
       mov       r8,[rbp+0FFD0]
       mov       rcx,[rbp+0FFC8]
       call      qword ptr [7EE8]; Precode of System.ArgumentOutOfRangeException..ctor(System.String, System.Object, System.String)
       mov       rcx,[rbp+0FFC8]
       call      000000000000B8A0
       int       3
M15_L00:
       add       rsp,80
       pop       rbp
       ret
; Total bytes of code 296
```
```assembly
; Tedd.Voxtree.DenseVoxel.Validate(Tedd.Voxtree.DenseVoxelLayout)
       push      rbp
       sub       rsp,30
       lea       rbp,[rsp+30]
       xor       eax,eax
       mov       [rbp+0FFF8],rax
       mov       [rbp+0FFF0],rax
       mov       [rbp+10],ecx
       cmp       dword ptr [rbp+10],0
       je        short 00000000000080F6
       cmp       dword ptr [rbp+10],1
       je        short 00000000000080E7
       mov       rcx,offset MT_System.ArgumentOutOfRangeException
       call      0000000000005240
       mov       [rbp+0FFF8],rax
       mov       ecx,4B5
       mov       rdx,7FF83A853BB8
       call      qword ptr [6AF0]; Precode of System.String.StrCns(UInt32, IntPtr)
       mov       [rbp+0FFF0],rax
       mov       rdx,[rbp+0FFF0]
       mov       rcx,[rbp+0FFF8]
       call      qword ptr [0D1E8]; Precode of System.ArgumentOutOfRangeException..ctor(System.String)
       mov       rcx,[rbp+0FFF8]
       call      000000000000B8A0
       int       3
M16_L00:
       mov       rcx,7FF83A940B30
       call      0000000000008420
M16_L01:
       mov       rcx,7FF83A940B34
       call      0000000000008420
       nop
       add       rsp,30
       pop       rbp
       ret
; Total bytes of code 140
```
```assembly
; Tedd.Voxtree.DenseVoxel.Index(Int32, Int32, Int32, Int32, Tedd.Voxtree.DenseVoxelLayout)
       push      rbp
       sub       rsp,20
       lea       rbp,[rsp+20]
       mov       [rbp+10],ecx
       mov       [rbp+18],edx
       mov       [rbp+20],r8d
       mov       [rbp+28],r9d
       cmp       dword ptr [rbp+30],0
       je        short 0000000000008514
       mov       rcx,7FF83A940BA8
       call      0000000000008420
       mov       ecx,[rbp+10]
       mov       edx,[rbp+18]
       mov       r8d,[rbp+20]
       call      qword ptr [0E9D0]; Tedd.MortonEncoding.Encode(UInt32, UInt32, UInt32)
       nop
       add       rsp,20
       pop       rbp
       ret
M17_L00:
       mov       rcx,7FF83A940BAC
       call      0000000000008420
       mov       eax,[rbp+10]
       imul      eax,[rbp+28]
       add       eax,[rbp+18]
       imul      eax,[rbp+28]
       add       eax,[rbp+20]
       add       rsp,20
       pop       rbp
       ret
; Total bytes of code 106
```
```assembly
; System.Runtime.CompilerServices.DefaultInterpolatedStringHandler..ctor(Int32, Int32)
       push      rdi
       push      rsi
       push      rbx
       sub       rsp,20
       mov       rbx,rcx
       mov       esi,edx
       mov       edi,r8d
       xor       eax,eax
       mov       [rbx],rax
       call      qword ptr [0A098]
       mov       rcx,[rax]
       imul      edx,edi,0B
       add       edx,esi
       mov       eax,100
       cmp       edx,100
       cmovle    edx,eax
       cmp       [rcx],ecx
       call      qword ptr [98B8]; Precode of System.Buffers.SharedArrayPool`1[[System.Char, System.Private.CoreLib]].Rent(Int32)
       mov       [rbx+8],rax
       test      rax,rax
       je        short 000000000000C4E0
       lea       rcx,[rax+10]
       mov       eax,[rax+8]
M18_L00:
       mov       [rbx+18],rcx
       mov       [rbx+20],eax
       xor       eax,eax
       mov       [rbx+10],eax
       mov       byte ptr [rbx+14],0
       add       rsp,20
       pop       rbx
       pop       rsi
       pop       rdi
       ret
M18_L01:
       xor       ecx,ecx
       xor       eax,eax
       jmp       short 000000000000C4C8
; Total bytes of code 102
```
```assembly
; System.Runtime.CompilerServices.DefaultInterpolatedStringHandler.AppendLiteral(System.String)
       push      rdi
       push      rsi
       push      rbx
       sub       rsp,20
       mov       rbx,rcx
       mov       rsi,rdx
       lea       r8,[rbx+18]
       mov       edx,[rbx+10]
       mov       ecx,[r8+8]
       cmp       edx,ecx
       ja        short 00000000000024EB
       mov       r8,[r8]
       mov       eax,edx
       lea       rax,[r8+rax*2]
       sub       ecx,edx
       mov       edi,[rsi+8]
       cmp       edi,ecx
       ja        short 00000000000024F2
       mov       r8d,edi
       add       r8,r8
       lea       rdx,[rsi+0C]
       mov       rcx,rax
       call      qword ptr [5818]; System.SpanHelpers.Memmove(Byte ByRef, Byte ByRef, UIntPtr)
       mov       rcx,7FF83A801618
       call      0000000000008420
       add       [rbx+10],edi
       add       rsp,20
       pop       rbx
       pop       rsi
       pop       rdi
       ret
M19_L00:
       call      qword ptr [7C30]; Precode of System.ThrowHelper.ThrowArgumentOutOfRangeException()
       int       3
M19_L01:
       mov       rcx,7FF83A80161C
       call      0000000000008420
       mov       rcx,rbx
       mov       rdx,rsi
       add       rsp,20
       pop       rbx
       pop       rsi
       pop       rdi
       jmp       qword ptr [67D8]; Precode of System.Runtime.CompilerServices.DefaultInterpolatedStringHandler.GrowThenCopyString(System.String)
; Total bytes of code 132
```
```assembly
; System.Runtime.CompilerServices.DefaultInterpolatedStringHandler.AppendFormatted[[System.Int32, System.Private.CoreLib]](Int32)
       push      rdi
       push      rsi
       push      rbp
       push      rbx
       sub       rsp,58
       xorps     xmm4,xmm4
       movaps    [rsp+30],xmm4
       movaps    [rsp+40],xmm4
       mov       rbx,rcx
       mov       esi,edx
       cmp       byte ptr [rbx+14],0
       jne       short 000000000000F15B
M20_L00:
       lea       rdx,[rbx+18]
       mov       r8d,[rbx+10]
       mov       edi,[rdx+8]
       cmp       r8d,edi
       ja        near ptr 000000000000F1D8
       mov       rdx,[rdx]
       mov       ecx,r8d
       lea       rbp,[rdx+rcx*2]
       sub       edi,r8d
       mov       rcx,[rbx]
       test      esi,esi
       jl        short 000000000000F173
       mov       [rsp+40],rbp
       mov       [rsp+48],edi
       lea       rdx,[rsp+40]
       lea       r8,[rsp+50]
       mov       ecx,esi
       call      qword ptr [0CF8]; Precode of System.Number.TryUInt32ToDecStr[[System.Char, System.Private.CoreLib]](UInt32, System.Span`1<Char>, Int32 ByRef)
M20_L01:
       test      eax,eax
       jne       short 000000000000F152
       mov       rcx,rbx
       call      qword ptr [4FF8]
       jmp       short 000000000000F100
M20_L02:
       mov       eax,[rsp+50]
       add       [rbx+10],eax
       jmp       short 000000000000F169
M20_L03:
       mov       rcx,rbx
       mov       edx,esi
       xor       r8d,r8d
       call      qword ptr [1B50]
M20_L04:
       nop
       add       rsp,58
       pop       rbx
       pop       rbp
       pop       rsi
       pop       rdi
       ret
M20_L05:
       test      rcx,rcx
       je        short 000000000000F180
       call      qword ptr [1260]; Precode of System.Globalization.NumberFormatInfo.<GetInstance>g__GetProviderNonNull|58_0(System.IFormatProvider)
       jmp       short 000000000000F186
M20_L06:
       call      qword ptr [1248]; Precode of System.Globalization.NumberFormatInfo.get_CurrentInfo()
M20_L07:
       mov       r8,[rax+28]
       test      r8,r8
       jne       short 000000000000F197
       xor       r9d,r9d
       xor       r8d,r8d
       jmp       short 000000000000F19F
M20_L08:
       lea       r9,[r8+0C]
       mov       r8d,[r8+8]
M20_L09:
       mov       [rsp+30],r9
       mov       [rsp+38],r8d
       mov       [rsp+40],rbp
       mov       [rsp+48],edi
       lea       r8,[rsp+50]
       mov       [rsp+20],r8
       lea       r8,[rsp+30]
       lea       r9,[rsp+40]
       mov       ecx,esi
       mov       edx,0FFFFFFFF
       call      qword ptr [0CE0]
       jmp       near ptr 000000000000F143
M20_L10:
       call      qword ptr [0F2B8]
       int       3
; Total bytes of code 255
```
```assembly
; System.Runtime.CompilerServices.DefaultInterpolatedStringHandler.ToStringAndClear()
       push      rdi
       push      rsi
       push      rbp
       push      rbx
       sub       rsp,38
       xor       eax,eax
       mov       [rsp+28],rax
       mov       rbx,rcx
       lea       rsi,[rbx+18]
       mov       rcx,rsi
       mov       eax,[rbx+10]
       cmp       eax,[rcx+8]
       ja        short 000000000000C6F7
       mov       rcx,[rcx]
       mov       [rsp+28],rcx
       mov       [rsp+30],eax
       lea       rcx,[rsp+28]
       call      qword ptr [0BB28]; Precode of System.String.Ctor(System.ReadOnlySpan`1<Char>)
       mov       rdi,rax
       mov       rbp,[rbx+8]
       xor       eax,eax
       mov       [rbx+8],rax
       mov       [rsi],rax
       mov       [rsi+8],rax
       mov       [rbx+10],eax
       test      rbp,rbp
       je        short 000000000000C6EB
       call      qword ptr [0A098]
       mov       rcx,[rax]
       mov       rdx,rbp
       xor       r8d,r8d
       cmp       [rcx],ecx
       call      qword ptr [98C0]; Precode of System.Buffers.SharedArrayPool`1[[System.Char, System.Private.CoreLib]].Return(Char[], Boolean)
M21_L00:
       mov       rax,rdi
       add       rsp,38
       pop       rbx
       pop       rbp
       pop       rsi
       pop       rdi
       ret
M21_L01:
       call      qword ptr [0F2B8]
       int       3
; Total bytes of code 126
```
```assembly
; Tedd.MortonEncoding.Encode(UInt32, UInt32, UInt32)
       push      rbp
       mov       rbp,rsp
       mov       [rbp+10],ecx
       mov       [rbp+18],edx
       mov       [rbp+20],r8d
       mov       eax,[rbp+20]
       mov       ecx,24924924
       pdep      eax,eax,ecx
       mov       ecx,[rbp+18]
       mov       edx,12492492
       pdep      ecx,ecx,edx
       or        eax,ecx
       mov       ecx,[rbp+10]
       mov       edx,9249249
       pdep      ecx,ecx,edx
       or        eax,ecx
       pop       rbp
       ret
; Total bytes of code 59
```
**Method was not JITted yet.**
Tedd.Voxtree.OctreeThrowHelper.ThrowInvalidView()
Tedd.Voxtree.OctreeThrowHelper.ThrowCoordinate(System.String, Int32)
Tedd.Voxtree.OctreeThrowHelper.ThrowMalformed()
System.String.StrCns(UInt32, IntPtr)
System.ObjectDisposedException..ctor(System.String)
System.ArgumentOutOfRangeException..ctor(System.String)
System.ThrowHelper.ThrowArgumentOutOfRangeException()
System.InvalidOperationException..ctor(System.String)
System.ArgumentOutOfRangeException..ctor(System.String, System.Object, System.String)

## .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v3 (Job: Job-GJBZFV(IterationCount=7, IterationTime=150ms, LaunchCount=1, WarmupCount=3))

```assembly
; Tedd.Voxtree.Benchmark.Tests.DeferredChunkReads.DeferredMisses()
       push      r15
       push      r14
       push      r13
       push      r12
       push      rdi
       push      rsi
       push      rbp
       push      rbx
       sub       rsp,98
       vxorps    xmm4,xmm4,xmm4
       vmovdqu   ymmword ptr [rsp+40],ymm4
       vmovdqu   ymmword ptr [rsp+60],ymm4
       vmovdqa   xmmword ptr [rsp+80],xmm4
       mov       rbx,rcx
       mov       rsi,[rbx+28]
       xor       edi,edi
       xor       ebp,ebp
       jmp       near ptr 000000000000AD65
M00_L00:
       mov       r10,[rsp+38]
M00_L01:
       mov       r9d,0FFFFFFFF
M00_L02:
       test      r9d,r9d
       jge       near ptr 000000000000AFD9
M00_L03:
       mov       r15,[r15+8]
       mov       rdx,[r15+8]
       cmp       [rdx+8],eax
       jbe       near ptr 000000000000B16B
       cmp       eax,[rdx+8]
       jae       near ptr 000000000000B1AE
       mov       ecx,eax
       shl       rcx,4
       lea       rdx,[rdx+rcx+10]
       mov       rcx,[rdx]
       mov       eax,[rdx+8]
       mov       [rsp+54],eax
       mov       r8d,[rdx+0C]
       mov       [rsp+50],r8d
       xor       r10d,r10d
       xor       r9d,r9d
       test      rcx,rcx
       je        short 000000000000AC93
       mov       r10,[rcx]
       test      dword ptr [r10],80000000
       je        near ptr 000000000000B03A
       lea       r10,[rcx+10]
       mov       r9d,[rcx+8]
M00_L04:
       mov       eax,[rsp+54]
       and       eax,7FFFFFFF
       mov       ecx,eax
       mov       r8d,[rsp+50]
       mov       eax,r8d
       add       rax,rcx
       mov       r9d,r9d
       cmp       rax,r9
       ja        near ptr 000000000000B1A7
       add       r10,rcx
       mov       r9d,r8d
M00_L05:
       mov       rcx,r10
       mov       eax,[r15+10]
       cmp       r9d,1
       jbe       near ptr 000000000000B1AE
       movzx     edx,byte ptr [rcx+1]
       and       edx,3
       mov       [rsp+78],rcx
       mov       [rsp+80],r9d
       mov       [rsp+88],eax
       mov       [rsp+8C],dl
       xor       ecx,ecx
       mov       [rsp+58],ecx
       lea       rcx,[rsp+78]
       call      qword ptr [0D758]; Tedd.Voxtree.OctreeSpan.get_IsValid()
       test      eax,eax
       je        near ptr 000000000000B059
       mov       ecx,[rsp+88]
       mov       edx,1
       shlx      ecx,edx,ecx
       cmp       r13d,ecx
       jae       near ptr 000000000000B064
       cmp       r12d,ecx
       jae       near ptr 000000000000B07C
       cmp       r14d,ecx
       jae       near ptr 000000000000B094
       vmovdqu   xmm0,xmmword ptr [rsp+78]
       vmovdqu   xmmword ptr [rsp+40],xmm0
       mov       [rsp+20],r12d
       mov       [rsp+28],r14d
       lea       rcx,[rsp+58]
       mov       [rsp+30],rcx
       lea       rcx,[rsp+40]
       mov       edx,[rsp+88]
       movzx     r8d,byte ptr [rsp+8C]
       mov       r9d,r13d
       call      qword ptr [0E820]; Tedd.Voxtree.OctreeCodec.TryGetUnchecked(System.ReadOnlySpan`1<Byte>, Int32, Tedd.Voxtree.StorageKind, Int32, Int32, Int32, UInt32 ByRef)
       test      eax,eax
       je        near ptr 000000000000B0AC
       mov       eax,[rsp+58]
M00_L06:
       add       edi,eax
       inc       ebp
       cmp       ebp,100
       jge       near ptr 000000000000AEB1
M00_L07:
       cmp       ebp,[rsi+8]
       jae       near ptr 000000000000B1AE
       mov       r14d,[rsi+rbp*4+10]
       mov       r15,[rbx+18]
       mov       r13d,r14d
       sar       r13d,0A
       mov       r12d,r14d
       sar       r12d,5
       and       r12d,1F
       mov       eax,ebp
       and       eax,1
       mov       [rsp+94],eax
       and       r14d,1F
       cmp       [r15],r15b
       vxorps    xmm0,xmm0,xmm0
       vmovdqu   xmmword ptr [rsp+78],xmm0
       vmovdqu   xmmword ptr [rsp+80],xmm0
       cmp       byte ptr [r15+24],0
       jne       near ptr 000000000000B0B7
       mov       rdx,[r15+8]
       mov       rcx,[rdx+8]
       cmp       [rcx+8],eax
       jbe       near ptr 000000000000B0F3
       mov       eax,[rsp+94]
       mov       edx,[rdx+10]
       mov       ecx,edx
       and       ecx,1F
       mov       r8d,1
       shlx      r8d,r8d,ecx
       cmp       r13d,r8d
       jae       near ptr 000000000000B12F
       cmp       r12d,r8d
       jae       near ptr 000000000000B12F
       cmp       r14d,r8d
       jae       near ptr 000000000000B12F
       add       edx,edx
       shlx      edx,r13d,edx
       shlx      ecx,r12d,ecx
       or        edx,ecx
       or        edx,r14d
       cmp       qword ptr [r15+10],0
       jne       near ptr 000000000000AF1D
       mov       r10,[r15+18]
       test      r10,r10
       je        near ptr 000000000000AC10
       mov       [rsp+38],r10
       mov       ecx,[r10+30]
       test      ecx,ecx
       je        near ptr 000000000000AC01
       mov       r8,[r10+10]
       test      r8,r8
       je        near ptr 000000000000AF3B
       cmp       ecx,1
       je        near ptr 000000000000AEF0
       cmp       ecx,20
       jg        near ptr 000000000000AF80
       add       ecx,0F
       and       ecx,0FFFFFFF0
       cmp       [r8+8],ecx
       jb        near ptr 000000000000B1A7
       add       r8,10
       add       rcx,rcx
       shr       rcx,5
       cmp       rcx,7FFFFFFF
       ja        near ptr 000000000000B1B4
       vmovd     xmm0,edx
       vpbroadcastw ymm0,xmm0
       xor       edx,edx
       test      ecx,ecx
       jle       short 000000000000AEE6
M00_L08:
       mov       r9,rdx
       shl       r9,5
       vpcmpeqw  ymm1,ymm0,[r8+r9]
       vpmovmskb r9d,ymm1
       test      r9d,r9d
       jne       short 000000000000AECA
       inc       edx
       cmp       edx,ecx
       jl        short 000000000000AE90
       jmp       near ptr 000000000000ABFC
M00_L09:
       mov       eax,edi
       vzeroupper
       add       rsp,98
       pop       rbx
       pop       rbp
       pop       rsi
       pop       rdi
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       ret
M00_L10:
       mov       r11d,edx
       shl       r11d,4
       tzcnt     r9d,r9d
       sar       r9d,1
       add       r9d,r11d
       mov       r10,[rsp+38]
       jmp       near ptr 000000000000AC07
M00_L11:
       mov       r10,[rsp+38]
       jmp       near ptr 000000000000AC01
M00_L12:
       cmp       dword ptr [r8+8],0
       jbe       near ptr 000000000000B1AE
       movzx     ecx,word ptr [r8+10]
       cmp       ecx,edx
       je        short 000000000000AF0E
       mov       r10,[rsp+38]
       jmp       near ptr 000000000000AC01
M00_L13:
       xor       ecx,ecx
       xor       r9d,r9d
       mov       r10,[rsp+38]
       jmp       near ptr 000000000000AC07
M00_L14:
       mov       [rsp+20],r14d
       mov       rcx,[r15+10]
       mov       edx,eax
       mov       r8d,r13d
       mov       r9d,r12d
       cmp       [rcx],ecx
       call      qword ptr [0E730]; Tedd.Voxtree.HotOctreeChunk.get_Item(Int32, Int32, Int32, Int32)
       jmp       near ptr 000000000000AD55
M00_L15:
       mov       r10,[rsp+38]
       mov       r8,[r10+18]
       mov       r9d,ecx
       test      r8,r8
       je        near ptr 000000000000B1A7
       mov       r10,[rsp+38]
       cmp       [r8+8],r9d
       jb        near ptr 000000000000B1A7
       lea       rcx,[r8+10]
       mov       r8d,r9d
       call      qword ptr [4EA0]; Precode of System.SpanHelpers.NonPackedIndexOfValueType[[System.Int32, System.Private.CoreLib],[System.SpanHelpers+DontNegate`1[[System.Int32, System.Private.CoreLib]], System.Private.CoreLib]](Int32 ByRef, Int32, Int32)
       mov       r9d,eax
       mov       eax,[rsp+94]
       mov       r10,[rsp+38]
       jmp       near ptr 000000000000AC07
M00_L16:
       mov       r9d,ecx
       cmp       [r8+8],r9d
       jb        near ptr 000000000000B1A7
       lea       rcx,[r8+10]
       movzx     edx,dx
       movsx     rdx,dx
       movzx     r8d,dx
       dec       r8d
       cmp       r8d,0FE
       jae       short 000000000000AFB6
       mov       r8d,r9d
       call      qword ptr [0C378]; System.PackedSpanHelpers.IndexOf[[System.SpanHelpers+DontNegate`1[[System.Int16, System.Private.CoreLib]], System.Private.CoreLib],[System.PackedSpanHelpers+NopTransform, System.Private.CoreLib]](Int16 ByRef, Int16, Int32)
       mov       r9d,eax
       jmp       short 000000000000AFC2
M00_L17:
       mov       r8d,r9d
       call      qword ptr [61D8]
       mov       r9d,eax
M00_L18:
       mov       eax,r9d
       mov       r9d,eax
       mov       eax,[rsp+94]
       mov       r10,[rsp+38]
       jmp       near ptr 000000000000AC07
M00_L19:
       mov       rcx,r10
       mov       edx,eax
       mov       [rsp+74],r9d
       mov       r8d,r9d
       call      qword ptr [0E790]; Tedd.Voxtree.SparseVoxelEdits`1[[System.UInt32, System.Private.CoreLib]].HasValue(Int32, Int32)
       test      eax,eax
       je        short 000000000000B02E
       mov       r15,[rsp+38]
       mov       rdx,[r15+8]
       mov       r15d,[rsp+94]
       cmp       r15d,[rdx+8]
       jae       near ptr 000000000000B1AE
       mov       ecx,r15d
       mov       rdx,[rdx+rcx*8+10]
       mov       r15d,[rsp+74]
       cmp       r15d,[rdx+8]
       jae       near ptr 000000000000B1AE
       mov       ecx,r15d
       mov       eax,[rdx+rcx*4+10]
       jmp       near ptr 000000000000AD55
M00_L20:
       mov       eax,[rsp+94]
       jmp       near ptr 000000000000AC10
M00_L21:
       lea       rdx,[rsp+60]
       mov       r10,[rcx]
       mov       r10,[r10+40]
       call      qword ptr [r10+28]
       mov       r10,[rsp+60]
       mov       r9d,[rsp+68]
       jmp       near ptr 000000000000AC6B
M00_L22:
       call      qword ptr [0E7F0]; Precode of Tedd.Voxtree.OctreeThrowHelper.ThrowInvalidView()
       jmp       near ptr 000000000000AD55
M00_L23:
       mov       edx,r13d
       mov       rcx,25300202B18
       call      qword ptr [0E808]; Precode of Tedd.Voxtree.OctreeThrowHelper.ThrowCoordinate(System.String, Int32)
       jmp       near ptr 000000000000AD55
M00_L24:
       mov       edx,r12d
       mov       rcx,253002122F8
       call      qword ptr [0E808]; Precode of Tedd.Voxtree.OctreeThrowHelper.ThrowCoordinate(System.String, Int32)
       jmp       near ptr 000000000000AD55
M00_L25:
       mov       edx,r14d
       mov       rcx,25300212310
       call      qword ptr [0E808]; Precode of Tedd.Voxtree.OctreeThrowHelper.ThrowCoordinate(System.String, Int32)
       jmp       near ptr 000000000000AD55
M00_L26:
       call      qword ptr [0E838]; Precode of Tedd.Voxtree.OctreeThrowHelper.ThrowMalformed()
       jmp       near ptr 000000000000AD55
M00_L27:
       mov       rcx,offset MT_System.ObjectDisposedException
       call      0000000000005240
       mov       rbx,rax
       mov       ecx,3F5
       mov       rdx,7FF83A864140
       call      qword ptr [6EE0]; Precode of System.String.StrCns(UInt32, IntPtr)
       mov       rdx,rax
       mov       rcx,rbx
       call      qword ptr [7BD0]; Precode of System.ObjectDisposedException..ctor(System.String)
       mov       rcx,rbx
       call      000000000000B8A0
       int       3
M00_L28:
       mov       rcx,offset MT_System.ArgumentOutOfRangeException
       call      0000000000005240
       mov       rbx,rax
       mov       ecx,3E1
       mov       rdx,7FF83A864140
       call      qword ptr [6EE0]; Precode of System.String.StrCns(UInt32, IntPtr)
       mov       rdx,rax
       mov       rcx,rbx
       call      qword ptr [0D1D0]; Precode of System.ArgumentOutOfRangeException..ctor(System.String)
       mov       rcx,rbx
       call      000000000000B8A0
       int       3
M00_L29:
       mov       rcx,offset MT_System.ArgumentOutOfRangeException
       call      0000000000005240
       mov       rbx,rax
       mov       ecx,3F1
       mov       rdx,7FF83A864140
       call      qword ptr [6EE0]; Precode of System.String.StrCns(UInt32, IntPtr)
       mov       rdx,rax
       mov       rcx,rbx
       call      qword ptr [0D1D0]; Precode of System.ArgumentOutOfRangeException..ctor(System.String)
       mov       rcx,rbx
       call      000000000000B8A0
       int       3
M00_L30:
       mov       rcx,offset MT_System.ArgumentOutOfRangeException
       call      0000000000005240
       mov       rdi,rax
       mov       ecx,3E1
       mov       rdx,7FF83A864140
       call      qword ptr [6EE0]; Precode of System.String.StrCns(UInt32, IntPtr)
       mov       rdx,rax
       mov       rcx,rdi
       call      qword ptr [0D1D0]; Precode of System.ArgumentOutOfRangeException..ctor(System.String)
       mov       rcx,rdi
       call      000000000000B8A0
       int       3
M00_L31:
       call      qword ptr [7C18]; Precode of System.ThrowHelper.ThrowArgumentOutOfRangeException()
       int       3
M00_L32:
       call      0000000000001788
       int       3
M00_L33:
       call      0000000000001770
       int       3
; Total bytes of code 1530
```
```assembly
; Tedd.Voxtree.OctreeSpan.get_IsValid()
       cmp       dword ptr [rcx+8],0
       setne     al
       movzx     eax,al
       ret
; Total bytes of code 11
```
```assembly
; Tedd.Voxtree.OctreeCodec.TryGetUnchecked(System.ReadOnlySpan`1<Byte>, Int32, Tedd.Voxtree.StorageKind, Int32, Int32, Int32, UInt32 ByRef)
       push      r15
       push      r14
       push      r13
       push      r12
       push      rdi
       push      rsi
       push      rbp
       push      rbx
       sub       rsp,58
       xor       eax,eax
       mov       [rsp+28],rax
       vxorps    xmm4,xmm4,xmm4
       vmovdqu   ymmword ptr [rsp+30],ymm4
       mov       [rsp+50],rax
       mov       esi,r9d
       mov       rbx,[rsp+0D0]
       xor       eax,eax
       mov       [rbx],eax
       mov       eax,1
       shlx      edi,eax,edx
       cmp       r8b,1
       jne       near ptr 000000000000A903
       mov       eax,2
       mov       r8,[rcx]
       mov       edx,[rcx+8]
       xor       r10d,r10d
       mov       [rbx],r10d
       cmp       edx,2
       jbe       short 000000000000A8F2
M02_L00:
       lea       r9d,[rax+1]
       mov       eax,eax
       movzx     eax,byte ptr [r8+rax]
       cmp       r10d,1C
       je        short 000000000000A8CE
M02_L01:
       mov       r11d,eax
       and       r11d,7F
       shlx      r11d,r11d,r10d
       or        [rbx],r11d
       test      al,80
       jne       short 000000000000A8D4
       cmp       r9d,3
       jne       short 000000000000A8E8
M02_L02:
       cmp       r9d,[rcx+8]
       sete      al
       movzx     eax,al
       add       rsp,58
       pop       rbx
       pop       rbp
       pop       rsi
       pop       rdi
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       ret
M02_L03:
       cmp       r9d,edx
       mov       eax,r9d
       jae       short 000000000000A8F2
       jmp       short 000000000000A87F
M02_L04:
       test      al,0F0
       jne       short 000000000000A8E3
       jmp       short 000000000000A890
M02_L05:
       add       r10d,7
       cmp       r10d,1C
       jle       short 000000000000A8C4
       mov       eax,r9d
       jmp       short 000000000000A8F2
M02_L06:
       mov       eax,r9d
       jmp       short 000000000000A8F2
M02_L07:
       test      al,7F
       setne     al
       movzx     eax,al
       jmp       short 000000000000A8F9
M02_L08:
       xor       edx,edx
       mov       r9d,eax
       mov       eax,edx
M02_L09:
       test      eax,eax
       je        near ptr 000000000000AAB2
       jmp       short 000000000000A8A9
M02_L10:
       cmp       r8b,2
       jne       short 000000000000A942
       imul      esi,edi
       imul      esi,edi
       imul      edi,[rsp+0C0]
       add       esi,edi
       add       esi,[rsp+0C8]
       lea       eax,[rsi*4+2]
       mov       edx,eax
       add       rdx,4
       mov       r8d,[rcx+8]
       cmp       rdx,r8
       ja        short 000000000000A95E
       add       rax,[rcx]
       mov       eax,[rax]
       mov       [rbx],eax
       jmp       near ptr 000000000000AA9C
M02_L11:
       test      edx,edx
       je        near ptr 000000000000AAB2
       cmp       dword ptr [rcx+8],0C
       jl        near ptr 000000000000AAB2
       mov       edi,[rcx+8]
       dec       edi
       cmp       edi,[rcx+8]
       jbe       short 000000000000A965
M02_L12:
       call      qword ptr [7C18]; Precode of System.ThrowHelper.ThrowArgumentOutOfRangeException()
       int       3
M02_L13:
       mov       rbp,[rcx]
       mov       r8d,[rcx+8]
       dec       r8d
       cmp       r8d,[rcx+8]
       jae       near ptr 000000000000AAC5
       mov       rcx,[rcx]
       movzx     ecx,byte ptr [rcx+r8]
       mov       r14d,edi
       sub       r14d,ecx
       cmp       ecx,9
       jl        near ptr 000000000000AAB2
       cmp       ecx,29
       jg        near ptr 000000000000AAB2
       cmp       r14d,2
       jl        near ptr 000000000000AAB2
       lea       r15d,[rdx+0FFFF]
       test      r15d,r15d
       jl        near ptr 000000000000AAB2
M02_L14:
       cmp       r14d,edi
       jae       near ptr 000000000000AAB2
       mov       [rsp+50],r14d
       mov       ecx,[rsp+50]
       mov       edx,[rsp+50]
       inc       edx
       mov       [rsp+50],edx
       cmp       ecx,edi
       jae       near ptr 000000000000AAC5
       movzx     r13d,byte ptr [rcx+rbp]
       sarx      r12d,esi,r15d
       and       r12d,1
       shl       r12d,2
       sarx      r10d,[rsp+0C0],r15d
       and       r10d,1
       add       r10d,r10d
       or        r12d,r10d
       sarx      r9d,[rsp+0C8],r15d
       and       r9d,1
       or        r12d,r9d
       xor       r9d,r9d
       jmp       short 000000000000AA3E
M02_L15:
       mov       [rsp+28],rbp
       mov       [rsp+30],edi
       lea       rcx,[rsp+28]
       lea       rdx,[rsp+50]
       lea       r8,[rsp+38]
       call      qword ptr [0D5D8]; Tedd.Voxtree.OctreeCodec.TryReadVarUInt(System.ReadOnlySpan`1<Byte>, Int32 ByRef, UInt32 ByRef)
       test      eax,eax
       je        near ptr 000000000000AAB2
       mov       r9d,[rsp+44]
       inc       r9d
M02_L16:
       mov       [rsp+44],r9d
       cmp       r9d,r12d
       jl        short 000000000000AA10
       mov       [rsp+28],rbp
       mov       [rsp+30],edi
       lea       rcx,[rsp+28]
       lea       rdx,[rsp+50]
       lea       r8,[rsp+48]
       call      qword ptr [0D5D8]; Tedd.Voxtree.OctreeCodec.TryReadVarUInt(System.ReadOnlySpan`1<Byte>, Int32 ByRef, UInt32 ByRef)
       test      eax,eax
       je        short 000000000000AAB2
       bt        r13d,r12d
       jb        short 000000000000AA96
       test      r15d,r15d
       je        short 000000000000AAB2
       cmp       dword ptr [rsp+48],0
       je        short 000000000000AAB2
       lea       eax,[r14+0FFFE]
       cmp       [rsp+48],eax
       ja        short 000000000000AAB2
       sub       r14d,[rsp+48]
       dec       r15d
       jns       near ptr 000000000000A9B0
       jmp       short 000000000000AAB2
M02_L17:
       mov       eax,[rsp+48]
       mov       [rbx],eax
M02_L18:
       mov       eax,1
       add       rsp,58
       pop       rbx
       pop       rbp
       pop       rsi
       pop       rdi
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       ret
M02_L19:
       xor       eax,eax
       add       rsp,58
       pop       rbx
       pop       rbp
       pop       rsi
       pop       rdi
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       ret
M02_L20:
       call      0000000000001788
       int       3
; Total bytes of code 683
```
```assembly
; Tedd.Voxtree.HotOctreeChunk.get_Item(Int32, Int32, Int32, Int32)
       push      rbp
       sub       rsp,40
       lea       rbp,[rsp+40]
       xor       eax,eax
       mov       [rbp+0FFF0],rax
       mov       [rbp+0FFF8],rax
       mov       [rbp+10],rcx
       mov       [rbp+18],edx
       mov       [rbp+20],r8d
       mov       [rbp+28],r9d
       lea       rdx,[rbp+0FFF0]
       mov       rcx,[rbp+10]
       mov       r8d,[rbp+18]
       call      qword ptr [0E538]; Tedd.Voxtree.HotOctreeChunk.GetChannelSpan(Int32)
       mov       rcx,[rbp+10]
       call      qword ptr [0E550]; Tedd.Voxtree.HotOctreeChunk.get_Levels()
       mov       [rbp+0FFE8],eax
       mov       dword ptr [rsp+20],1
       mov       r9d,[rbp+0FFE8]
       mov       edx,[rbp+28]
       mov       r8d,[rbp+30]
       mov       ecx,[rbp+20]
       call      qword ptr [0E568]; Tedd.Voxtree.DenseVoxel.GetIndex(Int32, Int32, Int32, Int32, Tedd.Voxtree.DenseVoxelLayout)
       mov       [rbp+0FFEC],eax
       mov       eax,[rbp+0FFF8]
       cmp       [rbp+0FFEC],eax
       jae       short 0000000000007179
       mov       eax,[rbp+0FFEC]
       mov       rcx,[rbp+0FFF0]
       mov       eax,[rcx+rax*4]
       add       rsp,40
       pop       rbp
       ret
M03_L00:
       call      0000000000001788
       int       3
; Total bytes of code 127
```
```assembly
; System.SpanHelpers.NonPackedIndexOfValueType[[System.Int32, System.Private.CoreLib],[System.SpanHelpers+DontNegate`1[[System.Int32, System.Private.CoreLib]], System.Private.CoreLib]](Int32 ByRef, Int32, Int32)
       cmp       r8d,4
       jl        near ptr 0000000000000E5A
       movd      xmm0,edx
       pshufd    xmm0,xmm0,0
       mov       rdx,rcx
       lea       eax,[r8+0FFFC]
       cdqe
       shl       rax,2
       lea       r10,[rdx+rax]
       movups    xmm1,[rcx]
       pcmpeqd   xmm1,xmm0
       ptest     xmm1,xmm1
       je        short 0000000000000E13
M04_L00:
       movmskps  eax,xmm1
       bsf       r8d,eax
       mov       r10d,20
       test      eax,eax
       cmove     r8d,r10d
       mov       rax,rdx
       sub       rax,rcx
       shr       rax,2
       add       eax,r8d
M04_L01:
       ret
M04_L02:
       add       rdx,10
       cmp       rdx,r10
       jbe       near ptr 0000000000000F43
       mov       ecx,r8d
       test      cl,3
       je        near ptr 0000000000000F5A
       movups    xmm1,[r10]
       pcmpeqd   xmm1,xmm0
       ptest     xmm1,xmm1
       je        near ptr 0000000000000F5A
       movmskps  edx,xmm1
       bsf       r8d,edx
       mov       ecx,20
       test      edx,edx
       cmove     r8d,ecx
       shr       rax,2
       add       eax,r8d
       jmp       short 0000000000000E12
M04_L03:
       xor       r10d,r10d
       cmp       r8d,8
       jge       short 0000000000000E8D
M04_L04:
       cmp       r8d,4
       jge       short 0000000000000EDC
M04_L05:
       test      r8d,r8d
       jle       near ptr 0000000000000F5A
M04_L06:
       dec       r8d
       cmp       [rcx+r10*4],edx
       je        short 0000000000000E88
       inc       r10
       test      r8d,r8d
       jg        short 0000000000000E72
       jmp       near ptr 0000000000000F5A
M04_L07:
       mov       eax,r10d
       jmp       short 0000000000000E12
M04_L08:
       add       r8d,0FFFFFFF8
       cmp       [rcx+r10*4],edx
       je        short 0000000000000E88
       cmp       [rcx+r10*4+4],edx
       je        near ptr 0000000000000F3A
       cmp       [rcx+r10*4+8],edx
       je        near ptr 0000000000000F31
       cmp       [rcx+r10*4+0C],edx
       je        short 0000000000000F28
       cmp       [rcx+r10*4+10],edx
       je        short 0000000000000F1F
       cmp       [rcx+r10*4+14],edx
       je        short 0000000000000F16
       cmp       [rcx+r10*4+18],edx
       je        short 0000000000000F0D
       cmp       [rcx+r10*4+1C],edx
       je        short 0000000000000F04
       add       r10,8
       cmp       r8d,8
       jge       short 0000000000000E8D
       jmp       short 0000000000000E63
M04_L09:
       add       r8d,0FFFFFFFC
       cmp       [rcx+r10*4],edx
       je        short 0000000000000E88
       cmp       [rcx+r10*4+4],edx
       je        short 0000000000000F3A
       cmp       [rcx+r10*4+8],edx
       je        short 0000000000000F31
       cmp       [rcx+r10*4+0C],edx
       je        short 0000000000000F28
       add       r10,4
       jmp       near ptr 0000000000000E69
M04_L10:
       lea       eax,[r10+7]
       jmp       near ptr 0000000000000E12
M04_L11:
       lea       eax,[r10+6]
       jmp       near ptr 0000000000000E12
M04_L12:
       lea       eax,[r10+5]
       jmp       near ptr 0000000000000E12
M04_L13:
       lea       eax,[r10+4]
       jmp       near ptr 0000000000000E12
M04_L14:
       lea       eax,[r10+3]
       jmp       near ptr 0000000000000E12
M04_L15:
       lea       eax,[r10+2]
       jmp       near ptr 0000000000000E12
M04_L16:
       lea       eax,[r10+1]
       jmp       near ptr 0000000000000E12
M04_L17:
       movups    xmm1,[rdx]
       pcmpeqd   xmm1,xmm0
       ptest     xmm1,xmm1
       jne       near ptr 0000000000000DF2
       jmp       near ptr 0000000000000E13
M04_L18:
       mov       eax,0FFFFFFFF
       ret
; Total bytes of code 416
```
```assembly
; System.PackedSpanHelpers.IndexOf[[System.SpanHelpers+DontNegate`1[[System.Int16, System.Private.CoreLib]], System.Private.CoreLib],[System.PackedSpanHelpers+NopTransform, System.Private.CoreLib]](Int16 ByRef, Int16, Int32)
       push      r14
       push      rdi
       push      rsi
       push      rbp
       push      rbx
       sub       rsp,50
       vmovaps   [rsp+40],xmm6
       vmovaps   [rsp+30],xmm7
       vmovaps   [rsp+20],xmm8
       mov       rsi,rcx
       mov       edi,edx
       mov       ebx,r8d
       cmp       ebx,8
       jl        near ptr 000000000000D51C
       mov       rbp,rsi
       cmp       ebx,10
       jle       near ptr 000000000000D499
       vmovd     xmm6,edi
       vpbroadcastb ymm6,xmm6
       cmp       ebx,20
       jle       near ptr 000000000000D3D4
       lea       ecx,[rbx+0FFE0]
       movsxd    rcx,ecx
       lea       rdi,[rbp+rcx*2]
       vmovups   ymm0,[rsi]
       vpackuswb ymm0,ymm0,[rsi+20]
       vpcmpeqb  ymm7,ymm0,ymm6
       vptest    ymm7,ymm7
       jne       short 000000000000D383
M05_L00:
       add       rbp,40
       cmp       rbp,rdi
       jae       short 000000000000D3B9
       mov       rcx,7FF83A4B99B8
       vextractf128 xmm8,ymm6,1
       call      0000000000008420
       vmovups   ymm0,[rbp]
       vpackuswb ymm0,ymm0,[rbp+20]
       vinsertf128 ymm6,ymm6,xmm8,1
       vpcmpeqb  ymm7,ymm0,ymm6
       vptest    ymm7,ymm7
       je        short 000000000000D34A
M05_L01:
       mov       rcx,7FF83A4B99AC
       vextractf128 xmm8,ymm7,1
       call      0000000000008420
       mov       rax,rbp
       sub       rax,rsi
       shr       rax,1
       vinsertf128 ymm7,ymm7,xmm8,1
       vpermq    ymm0,ymm7,0D8
       vpmovmskb ecx,ymm0
       tzcnt     ecx,ecx
       add       eax,ecx
       jmp       short 000000000000D41C
M05_L02:
       mov       rcx,7FF83A4B99B4
       vextractf128 xmm8,ymm6,1
       call      0000000000008420
       vinsertf128 ymm6,ymm6,xmm8,1
M05_L03:
       add       ebx,0FFFFFFF0
       movsxd    rcx,ebx
       lea       rbx,[rsi+rcx*2]
       cmp       rbp,rbx
       ja        short 000000000000D43C
       mov       rdi,rbp
M05_L04:
       vmovups   ymm0,[rdi]
       vpackuswb ymm0,ymm0,[rbx]
       vpcmpeqb  ymm6,ymm0,ymm6
       vptest    ymm6,ymm6
       jne       short 000000000000D45C
       mov       rcx,7FF83A4B99C4
       call      0000000000008420
M05_L05:
       mov       rcx,7FF83A4B99D4
       call      0000000000008420
       mov       eax,0FFFFFFFF
M05_L06:
       vzeroupper
       vmovaps   xmm6,[rsp+40]
       vmovaps   xmm7,[rsp+30]
       vmovaps   xmm8,[rsp+20]
       add       rsp,50
       pop       rbx
       pop       rbp
       pop       rsi
       pop       rdi
       pop       r14
       ret
M05_L07:
       mov       rcx,7FF83A4B99BC
       vextractf128 xmm8,ymm6,1
       call      0000000000008420
       mov       rdi,rbx
       vinsertf128 ymm6,ymm6,xmm8,1
       jmp       short 000000000000D3E6
M05_L08:
       mov       rcx,7FF83A4B99C0
       vextractf128 xmm7,ymm6,1
       call      0000000000008420
       vinsertf128 ymm6,ymm6,xmm7,1
       vpermq    ymm0,ymm6,0D8
       vpmovmskb ecx,ymm0
       tzcnt     ecx,ecx
       cmp       ecx,10
       jge       near ptr 000000000000D670
M05_L09:
       sub       rdi,rsi
       shr       rdi,1
       lea       eax,[rdi+rcx]
       jmp       short 000000000000D41C
M05_L10:
       mov       rcx,7FF83A4B99B0
       call      0000000000008420
       vmovd     xmm6,edi
       vpbroadcastb xmm6,xmm6
       lea       ecx,[rbx+0FFF8]
       movsxd    rcx,ecx
       lea       rbx,[rsi+rcx*2]
       cmp       rsi,rbx
       ja        near ptr 000000000000D67B
       mov       rdi,rsi
M05_L11:
       vmovups   xmm0,[rdi]
       vpackuswb xmm0,xmm0,[rbx]
       vpcmpeqb  xmm6,xmm0,xmm6
       vptest    xmm6,xmm6
       jne       short 000000000000D4EE
       mov       rcx,7FF83A4B99D0
       call      0000000000008420
       jmp       near ptr 000000000000D408
M05_L12:
       mov       rcx,7FF83A4B99CC
       call      0000000000008420
       vpmovmskb ecx,xmm6
       tzcnt     ecx,ecx
       cmp       ecx,8
       jge       near ptr 000000000000D692
M05_L13:
       sub       rdi,rsi
       shr       rdi,1
       lea       eax,[rdi+rcx]
       jmp       near ptr 000000000000D41C
M05_L14:
       xor       ebp,ebp
       cmp       ebx,4
       jl        short 000000000000D575
       add       ebx,0FFFFFFFC
       movsx     rcx,word ptr [rsi]
       movsx     r14,di
       cmp       ecx,r14d
       je        near ptr 000000000000D5BE
       movsx     rcx,word ptr [rsi+2]
       cmp       ecx,r14d
       je        near ptr 000000000000D5EF
       movsx     rcx,word ptr [rsi+4]
       cmp       ecx,r14d
       je        near ptr 000000000000D623
       movsx     rcx,word ptr [rsi+6]
       cmp       ecx,r14d
       je        near ptr 000000000000D657
       mov       rcx,7FF83A4B99A0
       call      0000000000008420
       mov       ebp,4
M05_L15:
       test      ebx,ebx
       jle       near ptr 000000000000D408
       movsx     r14,di
M05_L16:
       dec       ebx
       movsx     rcx,word ptr [rsi+rbp*2]
       cmp       ecx,r14d
       je        short 000000000000D5A8
       mov       rcx,7FF83A4B99A8
       call      0000000000008420
       inc       rbp
       test      ebx,ebx
       jg        short 000000000000D581
       jmp       near ptr 000000000000D408
M05_L17:
       mov       rcx,7FF83A4B99A4
       call      0000000000008420
       mov       eax,ebp
       jmp       near ptr 000000000000D41C
M05_L18:
       mov       rcx,7FF83A4B9990
       call      0000000000008420
       xor       eax,eax
       vzeroupper
       vmovaps   xmm6,[rsp+40]
       vmovaps   xmm7,[rsp+30]
       vmovaps   xmm8,[rsp+20]
       add       rsp,50
       pop       rbx
       pop       rbp
       pop       rsi
       pop       rdi
       pop       r14
       ret
M05_L19:
       mov       rcx,7FF83A4B9994
       call      0000000000008420
       mov       eax,1
       vzeroupper
       vmovaps   xmm6,[rsp+40]
       vmovaps   xmm7,[rsp+30]
       vmovaps   xmm8,[rsp+20]
       add       rsp,50
       pop       rbx
       pop       rbp
       pop       rsi
       pop       rdi
       pop       r14
       ret
M05_L20:
       mov       rcx,7FF83A4B9998
       call      0000000000008420
       mov       eax,2
       vzeroupper
       vmovaps   xmm6,[rsp+40]
       vmovaps   xmm7,[rsp+30]
       vmovaps   xmm8,[rsp+20]
       add       rsp,50
       pop       rbx
       pop       rbp
       pop       rsi
       pop       rdi
       pop       r14
       ret
M05_L21:
       mov       rcx,7FF83A4B999C
       call      0000000000008420
       mov       eax,3
       jmp       near ptr 000000000000D41C
M05_L22:
       mov       rdi,rbx
       add       ecx,0FFFFFFF0
       jmp       near ptr 000000000000D48E
M05_L23:
       mov       rcx,7FF83A4B99C8
       call      0000000000008420
       mov       rdi,rbx
       jmp       near ptr 000000000000D4C7
M05_L24:
       mov       rdi,rbx
       add       ecx,0FFFFFFF8
       jmp       near ptr 000000000000D50E
; Total bytes of code 957
```
```assembly
; Tedd.Voxtree.SparseVoxelEdits`1[[System.UInt32, System.Private.CoreLib]].HasValue(Int32, Int32)
       push      rbp
       sub       rsp,20
       lea       rbp,[rsp+20]
       mov       [rbp+10],rcx
       mov       [rbp+18],edx
       mov       [rbp+20],r8d
       mov       rax,[rbp+10]
       mov       rax,[rax+20]
       mov       rcx,[rbp+10]
       mov       ecx,[rcx+2C]
       imul      ecx,[rbp+18]
       mov       edx,[rbp+20]
       sar       edx,6
       add       ecx,edx
       cmp       ecx,[rax+8]
       jae       short 00000000000073FB
       mov       edx,ecx
       lea       rax,[rax+rdx*8+10]
       mov       ecx,1
       mov       edx,[rbp+20]
       shlx      rcx,rcx,rdx
       and       rcx,[rax]
       test      rcx,rcx
       setne     al
       movzx     eax,al
       add       rsp,20
       pop       rbp
       ret
M06_L00:
       call      0000000000001788
       int       3
; Total bytes of code 97
```
```assembly
; Tedd.Voxtree.OctreeCodec.TryReadVarUInt(System.ReadOnlySpan`1<Byte>, Int32 ByRef, UInt32 ByRef)
       push      rbx
       sub       rsp,20
       mov       rax,[rcx]
       mov       ecx,[rcx+8]
       xor       r10d,r10d
       mov       [r8],r10d
       mov       r10d,[rdx]
       mov       r9d,r10d
       xor       r11d,r11d
       cmp       r10d,ecx
       jae       short 000000000000AB8B
M07_L00:
       mov       r10d,[rdx]
       lea       ebx,[r10+1]
       mov       [rdx],ebx
       cmp       r10d,ecx
       jae       short 000000000000AB93
       movzx     r10d,byte ptr [rax+r10]
       cmp       r11d,1C
       je        short 000000000000AB67
M07_L01:
       mov       ebx,r10d
       and       ebx,7F
       shlx      ebx,ebx,r11d
       or        [r8],ebx
       test      r10b,80
       jne       short 000000000000AB6F
       mov       eax,[rdx]
       sub       eax,r9d
       cmp       eax,1
       jne       short 000000000000AB7B
       mov       eax,1
       add       rsp,20
       pop       rbx
       ret
M07_L02:
       cmp       [rdx],ecx
       jae       short 000000000000AB8B
       jmp       short 000000000000AB1F
M07_L03:
       test      r10b,0F0
       jne       short 000000000000AB8B
       jmp       short 000000000000AB38
M07_L04:
       add       r11d,7
       cmp       r11d,1C
       jle       short 000000000000AB61
       jmp       short 000000000000AB8B
M07_L05:
       test      r10b,7F
       setne     al
       movzx     eax,al
       add       rsp,20
       pop       rbx
       ret
M07_L06:
       xor       eax,eax
       add       rsp,20
       pop       rbx
       ret
M07_L07:
       call      0000000000001788
       int       3
; Total bytes of code 153
```
```assembly
; Tedd.Voxtree.HotOctreeChunk.GetChannelSpan(Int32)
       push      rbp
       sub       rsp,50
       lea       rbp,[rsp+50]
       xor       eax,eax
       mov       [rbp+0FFD8],rax
       vxorps    xmm4,xmm4,xmm4
       vmovdqu   ymmword ptr [rbp+0FFE0],ymm4
       mov       [rbp+10],rcx
       mov       [rbp+18],rdx
       mov       [rbp+20],r8d
       mov       rcx,[rbp+10]
       call      qword ptr [0E598]; Tedd.Voxtree.HotOctreeChunk.GetValues()
       mov       [rbp+0FFF0],rax
       mov       rax,[rbp+0FFF0]
       mov       [rbp+0FFE8],rax
       mov       rcx,[rbp+10]
       call      qword ptr [0E5B0]; Tedd.Voxtree.HotOctreeChunk.get_ChannelCount()
       cmp       eax,[rbp+20]
       ja        short 000000000000693E
       mov       rcx,offset MT_System.ArgumentOutOfRangeException
       call      0000000000005240
       mov       [rbp+0FFE0],rax
       mov       ecx,3E1
       mov       rdx,7FF83A864140
       call      qword ptr [6EE0]; Precode of System.String.StrCns(UInt32, IntPtr)
       mov       [rbp+0FFD8],rax
       mov       rdx,[rbp+0FFD8]
       mov       rcx,[rbp+0FFE0]
       call      qword ptr [0D1D0]; Precode of System.ArgumentOutOfRangeException..ctor(System.String)
       mov       rcx,[rbp+0FFE0]
       call      000000000000B8A0
       int       3
M08_L00:
       mov       rcx,[rbp+10]
       call      qword ptr [0E550]; Tedd.Voxtree.HotOctreeChunk.get_Levels()
       mov       ecx,eax
       call      qword ptr [0D1B8]; Tedd.Voxtree.OctreeCodec.GetVoxelCount(Int32)
       mov       [rbp+0FFFC],eax
       mov       eax,[rbp+20]
       mov       r8d,eax
       imul      r8d,[rbp+0FFFC]
       mov       rcx,[rbp+18]
       mov       rdx,[rbp+0FFE8]
       mov       r9d,[rbp+0FFFC]
       call      qword ptr [0E580]; System.MemoryExtensions.AsSpan[[System.UInt32, System.Private.CoreLib]](UInt32[], Int32, Int32)
       mov       rax,[rbp+18]
       add       rsp,50
       pop       rbp
       ret
; Total bytes of code 202
```
```assembly
; Tedd.Voxtree.HotOctreeChunk.get_Levels()
       push      rbp
       mov       rbp,rsp
       mov       [rbp+10],rcx
       mov       rax,[rbp+10]
       mov       eax,[rax+20]
       pop       rbp
       ret
; Total bytes of code 17
```
```assembly
; Tedd.Voxtree.DenseVoxel.GetIndex(Int32, Int32, Int32, Int32, Tedd.Voxtree.DenseVoxelLayout)
       push      rbp
       sub       rsp,40
       lea       rbp,[rsp+40]
       vxorps    xmm4,xmm4,xmm4
       vmovdqu   xmmword ptr [rbp+0FFE8],xmm4
       xor       eax,eax
       mov       [rbp+0FFF8],rax
       mov       [rbp+10],ecx
       mov       [rbp+18],edx
       mov       [rbp+20],r8d
       mov       [rbp+28],r9d
       mov       ecx,[rbp+28]
       call      qword ptr [0D1A0]; Tedd.Voxtree.OctreeCodec.ValidateLevels(Int32)
       mov       ecx,[rbp+30]
       call      qword ptr [0D098]; Tedd.Voxtree.DenseVoxel.Validate(Tedd.Voxtree.DenseVoxelLayout)
       mov       eax,1
       mov       ecx,[rbp+28]
       shlx      eax,eax,ecx
       mov       [rbp+0FFFC],eax
       mov       eax,[rbp+10]
       cmp       eax,[rbp+0FFFC]
       jae       short 0000000000006B30
       mov       eax,[rbp+18]
       cmp       eax,[rbp+0FFFC]
       jae       short 0000000000006B74
       mov       eax,[rbp+20]
       cmp       eax,[rbp+0FFFC]
       jb        short 0000000000006B85
       mov       rcx,7FF83A92EAD0
       call      0000000000008420
M10_L00:
       mov       rcx,offset MT_System.ArgumentOutOfRangeException
       call      0000000000005240
       mov       [rbp+0FFF0],rax
       mov       ecx,3F1
       mov       rdx,7FF83A864140
       call      qword ptr [6EE0]; Precode of System.String.StrCns(UInt32, IntPtr)
       mov       [rbp+0FFE8],rax
       mov       rdx,[rbp+0FFE8]
       mov       rcx,[rbp+0FFF0]
       call      qword ptr [0D1D0]; Precode of System.ArgumentOutOfRangeException..ctor(System.String)
       mov       rcx,[rbp+0FFF0]
       call      000000000000B8A0
       int       3
M10_L01:
       mov       rcx,7FF83A92EAD4
       call      0000000000008420
       jmp       short 0000000000006B30
M10_L02:
       mov       rcx,7FF83A92EAD8
       call      0000000000008420
       mov       eax,[rbp+30]
       mov       [rsp+20],eax
       mov       ecx,[rbp+10]
       mov       edx,[rbp+18]
       mov       r8d,[rbp+20]
       mov       r9d,[rbp+0FFFC]
       call      qword ptr [0E5C8]; Tedd.Voxtree.DenseVoxel.Index(Int32, Int32, Int32, Int32, Tedd.Voxtree.DenseVoxelLayout)
       nop
       add       rsp,40
       pop       rbp
       ret
; Total bytes of code 246
```
```assembly
; Tedd.Voxtree.HotOctreeChunk.GetValues()
       push      rbp
       sub       rsp,40
       lea       rbp,[rsp+40]
       vxorps    xmm4,xmm4,xmm4
       vmovdqu   ymmword ptr [rbp+0FFE0],ymm4
       mov       [rbp+10],rcx
       mov       rax,[rbp+10]
       mov       rax,[rax+8]
       mov       [rbp+0FFF8],rax
       mov       rax,[rbp+0FFF8]
       mov       [rbp+0FFF0],rax
       cmp       qword ptr [rbp+0FFF8],0
       jne       short 0000000000006A06
       mov       rcx,offset MT_System.InvalidOperationException
       call      0000000000005240
       mov       [rbp+0FFE8],rax
       mov       ecx,9F3
       mov       rdx,7FF83A864140
       call      qword ptr [6EE0]; Precode of System.String.StrCns(UInt32, IntPtr)
       mov       [rbp+0FFE0],rax
       mov       rdx,[rbp+0FFE0]
       mov       rcx,[rbp+0FFE8]
       call      qword ptr [65E0]; Precode of System.InvalidOperationException..ctor(System.String)
       mov       rcx,[rbp+0FFE8]
       call      000000000000B8A0
       int       3
M11_L00:
       mov       rax,[rbp+0FFF0]
       add       rsp,40
       pop       rbp
       ret
; Total bytes of code 128
```
```assembly
; Tedd.Voxtree.HotOctreeChunk.get_ChannelCount()
       push      rbp
       mov       rbp,rsp
       mov       [rbp+10],rcx
       mov       rax,[rbp+10]
       mov       eax,[rax+24]
       pop       rbp
       ret
; Total bytes of code 17
```
```assembly
; Tedd.Voxtree.OctreeCodec.GetVoxelCount(Int32)
       push      rbp
       mov       rbp,rsp
       mov       [rbp+10],ecx
       mov       eax,1
       mov       ecx,[rbp+10]
       lea       ecx,[rcx+rcx*2]
       shlx      eax,eax,ecx
       pop       rbp
       ret
; Total bytes of code 25
```
```assembly
; System.MemoryExtensions.AsSpan[[System.UInt32, System.Private.CoreLib]](UInt32[], Int32, Int32)
       sub       rsp,28
       test      rdx,rdx
       je        short 0000000000006A8F
       mov       r8d,r8d
       mov       eax,r9d
       add       rax,r8
       mov       r10d,[rdx+8]
       cmp       rax,r10
       ja        short 0000000000006A9B
       lea       rax,[rdx+r8*4+10]
M14_L00:
       mov       [rcx],rax
       mov       [rcx+8],r9d
       mov       rax,rcx
       add       rsp,28
       ret
M14_L01:
       or        r8d,r9d
       jne       short 0000000000006A9B
       xor       eax,eax
       xor       r9d,r9d
       jmp       short 0000000000006A80
M14_L02:
       call      qword ptr [7C18]; Precode of System.ThrowHelper.ThrowArgumentOutOfRangeException()
       int       3
; Total bytes of code 66
```
```assembly
; Tedd.Voxtree.OctreeCodec.ValidateLevels(Int32)
       push      rbp
       sub       rsp,80
       lea       rbp,[rsp+80]
       xor       eax,eax
       mov       [rbp+0FFA8],rax
       vxorps    xmm4,xmm4,xmm4
       vmovdqu   ymmword ptr [rbp+0FFB0],ymm4
       vmovdqu   ymmword ptr [rbp+0FFD0],ymm4
       vmovdqa   xmmword ptr [rbp+0FFF0],xmm4
       mov       [rbp+10],ecx
       cmp       dword ptr [rbp+10],9
       jbe       near ptr 0000000000005D0F
       mov       rcx,offset MT_System.Int32
       call      0000000000005240
       mov       [rbp+0FFD0],rax
       mov       rax,[rbp+0FFD0]
       mov       ecx,[rbp+10]
       mov       [rax+8],ecx
       lea       rcx,[rbp+0FFD8]
       mov       edx,31
       mov       r8d,1
       call      qword ptr [6868]; System.Runtime.CompilerServices.DefaultInterpolatedStringHandler..ctor(Int32, Int32)
       mov       ecx,1341
       mov       rdx,7FF83A864140
       call      qword ptr [6EE0]; Precode of System.String.StrCns(UInt32, IntPtr)
       mov       [rbp+0FFC0],rax
       mov       rdx,[rbp+0FFC0]
       lea       rcx,[rbp+0FFD8]
       call      qword ptr [6C10]; System.Runtime.CompilerServices.DefaultInterpolatedStringHandler.AppendLiteral(System.String)
       lea       rcx,[rbp+0FFD8]
       mov       edx,9
       call      qword ptr [6AD8]; System.Runtime.CompilerServices.DefaultInterpolatedStringHandler.AppendFormatted[[System.Int32, System.Private.CoreLib]](Int32)
       mov       ecx,369
       mov       rdx,7FF83A864140
       call      qword ptr [6EE0]; Precode of System.String.StrCns(UInt32, IntPtr)
       mov       [rbp+0FFB8],rax
       mov       rdx,[rbp+0FFB8]
       lea       rcx,[rbp+0FFD8]
       call      qword ptr [6C10]; System.Runtime.CompilerServices.DefaultInterpolatedStringHandler.AppendLiteral(System.String)
       mov       rcx,offset MT_System.ArgumentOutOfRangeException
       call      0000000000005240
       mov       [rbp+0FFC8],rax
       mov       ecx,1333
       mov       rdx,7FF83A864140
       call      qword ptr [6EE0]; Precode of System.String.StrCns(UInt32, IntPtr)
       mov       [rbp+0FFB0],rax
       lea       rcx,[rbp+0FFD8]
       call      qword ptr [6898]; System.Runtime.CompilerServices.DefaultInterpolatedStringHandler.ToStringAndClear()
       mov       [rbp+0FFA8],rax
       mov       rdx,[rbp+0FFB0]
       mov       r9,[rbp+0FFA8]
       mov       r8,[rbp+0FFD0]
       mov       rcx,[rbp+0FFC8]
       call      qword ptr [7E58]; Precode of System.ArgumentOutOfRangeException..ctor(System.String, System.Object, System.String)
       mov       rcx,[rbp+0FFC8]
       call      000000000000B8A0
       int       3
M15_L00:
       add       rsp,80
       pop       rbp
       ret
; Total bytes of code 296
```
```assembly
; Tedd.Voxtree.DenseVoxel.Validate(Tedd.Voxtree.DenseVoxelLayout)
       push      rbp
       sub       rsp,30
       lea       rbp,[rsp+30]
       xor       eax,eax
       mov       [rbp+0FFF8],rax
       mov       [rbp+0FFF0],rax
       mov       [rbp+10],ecx
       cmp       dword ptr [rbp+10],0
       je        short 0000000000005DA6
       cmp       dword ptr [rbp+10],1
       je        short 0000000000005D97
       mov       rcx,offset MT_System.ArgumentOutOfRangeException
       call      0000000000005240
       mov       [rbp+0FFF8],rax
       mov       ecx,4B5
       mov       rdx,7FF83A864140
       call      qword ptr [6EE0]; Precode of System.String.StrCns(UInt32, IntPtr)
       mov       [rbp+0FFF0],rax
       mov       rdx,[rbp+0FFF0]
       mov       rcx,[rbp+0FFF8]
       call      qword ptr [0D1D0]; Precode of System.ArgumentOutOfRangeException..ctor(System.String)
       mov       rcx,[rbp+0FFF8]
       call      000000000000B8A0
       int       3
M16_L00:
       mov       rcx,7FF83A92E880
       call      0000000000008420
M16_L01:
       mov       rcx,7FF83A92E884
       call      0000000000008420
       nop
       add       rsp,30
       pop       rbp
       ret
; Total bytes of code 140
```
```assembly
; Tedd.Voxtree.DenseVoxel.Index(Int32, Int32, Int32, Int32, Tedd.Voxtree.DenseVoxelLayout)
       push      rbp
       sub       rsp,20
       lea       rbp,[rsp+20]
       mov       [rbp+10],ecx
       mov       [rbp+18],edx
       mov       [rbp+20],r8d
       mov       [rbp+28],r9d
       cmp       dword ptr [rbp+30],0
       je        short 0000000000006C14
       mov       rcx,7FF83A92EB10
       call      0000000000008420
       mov       ecx,[rbp+10]
       mov       edx,[rbp+18]
       mov       r8d,[rbp+20]
       call      qword ptr [0E5E0]; Tedd.MortonEncoding.Encode(UInt32, UInt32, UInt32)
       nop
       add       rsp,20
       pop       rbp
       ret
M17_L00:
       mov       rcx,7FF83A92EB14
       call      0000000000008420
       mov       eax,[rbp+10]
       imul      eax,[rbp+28]
       add       eax,[rbp+18]
       imul      eax,[rbp+28]
       add       eax,[rbp+20]
       add       rsp,20
       pop       rbp
       ret
; Total bytes of code 106
```
```assembly
; System.Runtime.CompilerServices.DefaultInterpolatedStringHandler..ctor(Int32, Int32)
       push      rdi
       push      rsi
       push      rbx
       sub       rsp,20
       mov       rbx,rcx
       mov       esi,edx
       mov       edi,r8d
       xor       eax,eax
       mov       [rbx],rax
       call      qword ptr [0A098]
       mov       rcx,[rax]
       imul      edx,edi,0B
       add       edx,esi
       mov       eax,100
       cmp       edx,100
       cmovle    edx,eax
       cmp       [rcx],ecx
       call      qword ptr [98B8]; Precode of System.SZGenericArrayEnumeratorBase.Dispose()
       mov       [rbx+8],rax
       test      rax,rax
       je        short 000000000000C4E0
       lea       rcx,[rax+10]
       mov       eax,[rax+8]
M18_L00:
       mov       [rbx+18],rcx
       mov       [rbx+20],eax
       xor       eax,eax
       mov       [rbx+10],eax
       mov       byte ptr [rbx+14],0
       add       rsp,20
       pop       rbx
       pop       rsi
       pop       rdi
       ret
M18_L01:
       xor       ecx,ecx
       xor       eax,eax
       jmp       short 000000000000C4C8
; Total bytes of code 102
```
```assembly
; System.Runtime.CompilerServices.DefaultInterpolatedStringHandler.AppendLiteral(System.String)
       push      rdi
       push      rsi
       push      rbx
       sub       rsp,20
       mov       rbx,rcx
       mov       rsi,rdx
       lea       r8,[rbx+18]
       mov       edx,[rbx+10]
       mov       ecx,[r8+8]
       cmp       edx,ecx
       ja        short 00000000000040CB
       mov       r8,[r8]
       mov       eax,edx
       lea       rax,[r8+rax*2]
       sub       ecx,edx
       mov       edi,[rsi+8]
       cmp       edi,ecx
       ja        short 00000000000040D2
       mov       r8d,edi
       add       r8,r8
       lea       rdx,[rsi+0C]
       mov       rcx,rax
       call      qword ptr [5818]; System.SpanHelpers.Memmove(Byte ByRef, Byte ByRef, UIntPtr)
       mov       rcx,7FF83A8139B0
       call      0000000000008420
       add       [rbx+10],edi
       add       rsp,20
       pop       rbx
       pop       rsi
       pop       rdi
       ret
M19_L00:
       call      qword ptr [7C18]; Precode of System.ThrowHelper.ThrowArgumentOutOfRangeException()
       int       3
M19_L01:
       mov       rcx,7FF83A8139B4
       call      0000000000008420
       mov       rcx,rbx
       mov       rdx,rsi
       add       rsp,20
       pop       rbx
       pop       rsi
       pop       rdi
       jmp       qword ptr [6880]; Precode of System.Runtime.CompilerServices.DefaultInterpolatedStringHandler.GrowThenCopyString(System.String)
; Total bytes of code 132
```
```assembly
; System.Runtime.CompilerServices.DefaultInterpolatedStringHandler.AppendFormatted[[System.Int32, System.Private.CoreLib]](Int32)
       push      rdi
       push      rsi
       push      rbp
       push      rbx
       sub       rsp,58
       xorps     xmm4,xmm4
       movaps    [rsp+30],xmm4
       movaps    [rsp+40],xmm4
       mov       rbx,rcx
       mov       esi,edx
       cmp       byte ptr [rbx+14],0
       jne       short 000000000000F15B
M20_L00:
       lea       rdx,[rbx+18]
       mov       r8d,[rbx+10]
       mov       edi,[rdx+8]
       cmp       r8d,edi
       ja        near ptr 000000000000F1D8
       mov       rdx,[rdx]
       mov       ecx,r8d
       lea       rbp,[rdx+rcx*2]
       sub       edi,r8d
       mov       rcx,[rbx]
       test      esi,esi
       jl        short 000000000000F173
       mov       [rsp+40],rbp
       mov       [rsp+48],edi
       lea       rdx,[rsp+40]
       lea       r8,[rsp+50]
       mov       ecx,esi
       call      qword ptr [0CF8]; Precode of System.Number.TryUInt32ToDecStr[[System.Char, System.Private.CoreLib]](UInt32, System.Span`1<Char>, Int32 ByRef)
M20_L01:
       test      eax,eax
       jne       short 000000000000F152
       mov       rcx,rbx
       call      qword ptr [4FF8]
       jmp       short 000000000000F100
M20_L02:
       mov       eax,[rsp+50]
       add       [rbx+10],eax
       jmp       short 000000000000F169
M20_L03:
       mov       rcx,rbx
       mov       edx,esi
       xor       r8d,r8d
       call      qword ptr [1B50]
M20_L04:
       nop
       add       rsp,58
       pop       rbx
       pop       rbp
       pop       rsi
       pop       rdi
       ret
M20_L05:
       test      rcx,rcx
       je        short 000000000000F180
       call      qword ptr [1260]; Precode of System.Globalization.NumberFormatInfo.<GetInstance>g__GetProviderNonNull|58_0(System.IFormatProvider)
       jmp       short 000000000000F186
M20_L06:
       call      qword ptr [1248]; Precode of System.Globalization.NumberFormatInfo.get_CurrentInfo()
M20_L07:
       mov       r8,[rax+28]
       test      r8,r8
       jne       short 000000000000F197
       xor       r9d,r9d
       xor       r8d,r8d
       jmp       short 000000000000F19F
M20_L08:
       lea       r9,[r8+0C]
       mov       r8d,[r8+8]
M20_L09:
       mov       [rsp+30],r9
       mov       [rsp+38],r8d
       mov       [rsp+40],rbp
       mov       [rsp+48],edi
       lea       r8,[rsp+50]
       mov       [rsp+20],r8
       lea       r8,[rsp+30]
       lea       r9,[rsp+40]
       mov       ecx,esi
       mov       edx,0FFFFFFFF
       call      qword ptr [0CE0]
       jmp       near ptr 000000000000F143
M20_L10:
       call      qword ptr [0F2B8]
       int       3
; Total bytes of code 255
```
```assembly
; System.Runtime.CompilerServices.DefaultInterpolatedStringHandler.ToStringAndClear()
       push      rdi
       push      rsi
       push      rbp
       push      rbx
       sub       rsp,38
       xor       eax,eax
       mov       [rsp+28],rax
       mov       rbx,rcx
       lea       rsi,[rbx+18]
       mov       rcx,rsi
       mov       eax,[rbx+10]
       cmp       eax,[rcx+8]
       ja        short 000000000000C6F7
       mov       rcx,[rcx]
       mov       [rsp+28],rcx
       mov       [rsp+30],eax
       lea       rcx,[rsp+28]
       call      qword ptr [0BB28]; Precode of System.String.Ctor(System.ReadOnlySpan`1<Char>)
       mov       rdi,rax
       mov       rbp,[rbx+8]
       xor       eax,eax
       mov       [rbx+8],rax
       mov       [rsi],rax
       mov       [rsi+8],rax
       mov       [rbx+10],eax
       test      rbp,rbp
       je        short 000000000000C6EB
       call      qword ptr [0A098]
       mov       rcx,[rax]
       mov       rdx,rbp
       xor       r8d,r8d
       cmp       [rcx],ecx
       call      qword ptr [98C0]; Precode of System.SZArrayHelper.get_Count[[System.Double, System.Private.CoreLib]]()
M21_L00:
       mov       rax,rdi
       add       rsp,38
       pop       rbx
       pop       rbp
       pop       rsi
       pop       rdi
       ret
M21_L01:
       call      qword ptr [0F2B8]
       int       3
; Total bytes of code 126
```
```assembly
; Tedd.MortonEncoding.Encode(UInt32, UInt32, UInt32)
       push      rbp
       mov       rbp,rsp
       mov       [rbp+10],ecx
       mov       [rbp+18],edx
       mov       [rbp+20],r8d
       mov       eax,[rbp+20]
       mov       ecx,24924924
       pdep      eax,eax,ecx
       mov       ecx,[rbp+18]
       mov       edx,12492492
       pdep      ecx,ecx,edx
       or        eax,ecx
       mov       ecx,[rbp+10]
       mov       edx,9249249
       pdep      ecx,ecx,edx
       or        eax,ecx
       pop       rbp
       ret
; Total bytes of code 59
```
**Method was not JITted yet.**
Tedd.Voxtree.OctreeThrowHelper.ThrowInvalidView()
Tedd.Voxtree.OctreeThrowHelper.ThrowCoordinate(System.String, Int32)
Tedd.Voxtree.OctreeThrowHelper.ThrowMalformed()
System.String.StrCns(UInt32, IntPtr)
System.ObjectDisposedException..ctor(System.String)
System.ArgumentOutOfRangeException..ctor(System.String)
System.ThrowHelper.ThrowArgumentOutOfRangeException()
System.InvalidOperationException..ctor(System.String)
System.ArgumentOutOfRangeException..ctor(System.String, System.Object, System.String)

## .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v3 (Job: Job-GJBZFV(IterationCount=7, IterationTime=150ms, LaunchCount=1, WarmupCount=3))

```assembly
; Tedd.Voxtree.Benchmark.Tests.DeferredChunkReads.DeferredMisses()
       push      r15
       push      r14
       push      r13
       push      r12
       push      rdi
       push      rsi
       push      rbp
       push      rbx
       sub       rsp,98
       vxorps    xmm4,xmm4,xmm4
       vmovdqu   ymmword ptr [rsp+40],ymm4
       vmovdqu   ymmword ptr [rsp+60],ymm4
       vmovdqa   xmmword ptr [rsp+80],xmm4
       mov       rbx,rcx
       mov       rsi,[rbx+28]
       xor       edi,edi
       xor       ebp,ebp
       jmp       near ptr 000000000000CF65
M00_L00:
       mov       r10,[rsp+38]
M00_L01:
       mov       r9d,0FFFFFFFF
M00_L02:
       test      r9d,r9d
       jge       near ptr 000000000000D1D9
M00_L03:
       mov       r15,[r15+8]
       mov       rdx,[r15+8]
       cmp       [rdx+8],eax
       jbe       near ptr 000000000000D36B
       cmp       eax,[rdx+8]
       jae       near ptr 000000000000D3AE
       mov       ecx,eax
       shl       rcx,4
       lea       rdx,[rdx+rcx+10]
       mov       rcx,[rdx]
       mov       eax,[rdx+8]
       mov       [rsp+54],eax
       mov       r8d,[rdx+0C]
       mov       [rsp+50],r8d
       xor       r10d,r10d
       xor       r9d,r9d
       test      rcx,rcx
       je        short 000000000000CE93
       mov       r10,[rcx]
       test      dword ptr [r10],80000000
       je        near ptr 000000000000D23A
       lea       r10,[rcx+10]
       mov       r9d,[rcx+8]
M00_L04:
       mov       eax,[rsp+54]
       and       eax,7FFFFFFF
       mov       ecx,eax
       mov       r8d,[rsp+50]
       mov       eax,r8d
       add       rax,rcx
       mov       r9d,r9d
       cmp       rax,r9
       ja        near ptr 000000000000D3A7
       add       r10,rcx
       mov       r9d,r8d
M00_L05:
       mov       rcx,r10
       mov       eax,[r15+10]
       cmp       r9d,1
       jbe       near ptr 000000000000D3AE
       movzx     edx,byte ptr [rcx+1]
       and       edx,3
       mov       [rsp+78],rcx
       mov       [rsp+80],r9d
       mov       [rsp+88],eax
       mov       [rsp+8C],dl
       xor       ecx,ecx
       mov       [rsp+58],ecx
       lea       rcx,[rsp+78]
       call      qword ptr [0D740]; Tedd.Voxtree.OctreeSpan.get_IsValid()
       test      eax,eax
       je        near ptr 000000000000D259
       mov       ecx,[rsp+88]
       mov       edx,1
       shlx      ecx,edx,ecx
       cmp       r13d,ecx
       jae       near ptr 000000000000D264
       cmp       r12d,ecx
       jae       near ptr 000000000000D27C
       cmp       r14d,ecx
       jae       near ptr 000000000000D294
       vmovdqu   xmm0,xmmword ptr [rsp+78]
       vmovdqu   xmmword ptr [rsp+40],xmm0
       mov       [rsp+20],r12d
       mov       [rsp+28],r14d
       lea       rcx,[rsp+58]
       mov       [rsp+30],rcx
       lea       rcx,[rsp+40]
       mov       edx,[rsp+88]
       movzx     r8d,byte ptr [rsp+8C]
       mov       r9d,r13d
       call      qword ptr [0E8E0]; Tedd.Voxtree.OctreeCodec.TryGetUnchecked(System.ReadOnlySpan`1<Byte>, Int32, Tedd.Voxtree.StorageKind, Int32, Int32, Int32, UInt32 ByRef)
       test      eax,eax
       je        near ptr 000000000000D2AC
       mov       eax,[rsp+58]
M00_L06:
       add       edi,eax
       inc       ebp
       cmp       ebp,100
       jge       near ptr 000000000000D0B1
M00_L07:
       cmp       ebp,[rsi+8]
       jae       near ptr 000000000000D3AE
       mov       r14d,[rsi+rbp*4+10]
       mov       r15,[rbx+18]
       mov       r13d,r14d
       sar       r13d,0A
       mov       r12d,r14d
       sar       r12d,5
       and       r12d,1F
       mov       eax,ebp
       and       eax,1
       mov       [rsp+94],eax
       and       r14d,1F
       cmp       [r15],r15b
       vxorps    xmm0,xmm0,xmm0
       vmovdqu   xmmword ptr [rsp+78],xmm0
       vmovdqu   xmmword ptr [rsp+80],xmm0
       cmp       byte ptr [r15+24],0
       jne       near ptr 000000000000D2B7
       mov       rdx,[r15+8]
       mov       rcx,[rdx+8]
       cmp       [rcx+8],eax
       jbe       near ptr 000000000000D2F3
       mov       eax,[rsp+94]
       mov       edx,[rdx+10]
       mov       ecx,edx
       and       ecx,1F
       mov       r8d,1
       shlx      r8d,r8d,ecx
       cmp       r13d,r8d
       jae       near ptr 000000000000D32F
       cmp       r12d,r8d
       jae       near ptr 000000000000D32F
       cmp       r14d,r8d
       jae       near ptr 000000000000D32F
       add       edx,edx
       shlx      edx,r13d,edx
       shlx      ecx,r12d,ecx
       or        edx,ecx
       or        edx,r14d
       cmp       qword ptr [r15+10],0
       jne       near ptr 000000000000D11D
       mov       r10,[r15+18]
       test      r10,r10
       je        near ptr 000000000000CE10
       mov       [rsp+38],r10
       mov       ecx,[r10+30]
       test      ecx,ecx
       je        near ptr 000000000000CE01
       mov       r8,[r10+10]
       test      r8,r8
       je        near ptr 000000000000D13B
       cmp       ecx,1
       je        near ptr 000000000000D0F0
       cmp       ecx,20
       jg        near ptr 000000000000D180
       add       ecx,0F
       and       ecx,0FFFFFFF0
       cmp       [r8+8],ecx
       jb        near ptr 000000000000D3A7
       add       r8,10
       add       rcx,rcx
       shr       rcx,5
       cmp       rcx,7FFFFFFF
       ja        near ptr 000000000000D3B4
       vmovd     xmm0,edx
       vpbroadcastw ymm0,xmm0
       xor       edx,edx
       test      ecx,ecx
       jle       short 000000000000D0E6
M00_L08:
       mov       r9,rdx
       shl       r9,5
       vpcmpeqw  ymm1,ymm0,[r8+r9]
       vpmovmskb r9d,ymm1
       test      r9d,r9d
       jne       short 000000000000D0CA
       inc       edx
       cmp       edx,ecx
       jl        short 000000000000D090
       jmp       near ptr 000000000000CDFC
M00_L09:
       mov       eax,edi
       vzeroupper
       add       rsp,98
       pop       rbx
       pop       rbp
       pop       rsi
       pop       rdi
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       ret
M00_L10:
       mov       r11d,edx
       shl       r11d,4
       tzcnt     r9d,r9d
       sar       r9d,1
       add       r9d,r11d
       mov       r10,[rsp+38]
       jmp       near ptr 000000000000CE07
M00_L11:
       mov       r10,[rsp+38]
       jmp       near ptr 000000000000CE01
M00_L12:
       cmp       dword ptr [r8+8],0
       jbe       near ptr 000000000000D3AE
       movzx     ecx,word ptr [r8+10]
       cmp       ecx,edx
       je        short 000000000000D10E
       mov       r10,[rsp+38]
       jmp       near ptr 000000000000CE01
M00_L13:
       xor       ecx,ecx
       xor       r9d,r9d
       mov       r10,[rsp+38]
       jmp       near ptr 000000000000CE07
M00_L14:
       mov       [rsp+20],r14d
       mov       rcx,[r15+10]
       mov       edx,eax
       mov       r8d,r13d
       mov       r9d,r12d
       cmp       [rcx],ecx
       call      qword ptr [0E820]; Tedd.Voxtree.HotOctreeChunk.get_Item(Int32, Int32, Int32, Int32)
       jmp       near ptr 000000000000CF55
M00_L15:
       mov       r10,[rsp+38]
       mov       r8,[r10+18]
       mov       r9d,ecx
       test      r8,r8
       je        near ptr 000000000000D3A7
       mov       r10,[rsp+38]
       cmp       [r8+8],r9d
       jb        near ptr 000000000000D3A7
       lea       rcx,[r8+10]
       mov       r8d,r9d
       call      qword ptr [5410]; Precode of System.SpanHelpers.NonPackedIndexOfValueType[[System.Int32, System.Private.CoreLib],[System.SpanHelpers+DontNegate`1[[System.Int32, System.Private.CoreLib]], System.Private.CoreLib]](Int32 ByRef, Int32, Int32)
       mov       r9d,eax
       mov       eax,[rsp+94]
       mov       r10,[rsp+38]
       jmp       near ptr 000000000000CE07
M00_L16:
       mov       r9d,ecx
       cmp       [r8+8],r9d
       jb        near ptr 000000000000D3A7
       lea       rcx,[r8+10]
       movzx     edx,dx
       movsx     rdx,dx
       movzx     r8d,dx
       dec       r8d
       cmp       r8d,0FE
       jae       short 000000000000D1B6
       mov       r8d,r9d
       call      qword ptr [0C378]; System.PackedSpanHelpers.IndexOf[[System.SpanHelpers+DontNegate`1[[System.Int16, System.Private.CoreLib]], System.Private.CoreLib],[System.PackedSpanHelpers+NopTransform, System.Private.CoreLib]](Int16 ByRef, Int16, Int32)
       mov       r9d,eax
       jmp       short 000000000000D1C2
M00_L17:
       mov       r8d,r9d
       call      qword ptr [61D8]
       mov       r9d,eax
M00_L18:
       mov       eax,r9d
       mov       r9d,eax
       mov       eax,[rsp+94]
       mov       r10,[rsp+38]
       jmp       near ptr 000000000000CE07
M00_L19:
       mov       rcx,r10
       mov       edx,eax
       mov       [rsp+74],r9d
       mov       r8d,r9d
       call      qword ptr [0E880]; Tedd.Voxtree.SparseVoxelEdits`1[[System.UInt32, System.Private.CoreLib]].HasValue(Int32, Int32)
       test      eax,eax
       je        short 000000000000D22E
       mov       r15,[rsp+38]
       mov       rdx,[r15+8]
       mov       r15d,[rsp+94]
       cmp       r15d,[rdx+8]
       jae       near ptr 000000000000D3AE
       mov       ecx,r15d
       mov       rdx,[rdx+rcx*8+10]
       mov       r15d,[rsp+74]
       cmp       r15d,[rdx+8]
       jae       near ptr 000000000000D3AE
       mov       ecx,r15d
       mov       eax,[rdx+rcx*4+10]
       jmp       near ptr 000000000000CF55
M00_L20:
       mov       eax,[rsp+94]
       jmp       near ptr 000000000000CE10
M00_L21:
       lea       rdx,[rsp+60]
       mov       r10,[rcx]
       mov       r10,[r10+40]
       call      qword ptr [r10+28]
       mov       r10,[rsp+60]
       mov       r9d,[rsp+68]
       jmp       near ptr 000000000000CE6B
M00_L22:
       call      qword ptr [0E8B0]; Precode of Tedd.Voxtree.OctreeThrowHelper.ThrowInvalidView()
       jmp       near ptr 000000000000CF55
M00_L23:
       mov       edx,r13d
       mov       rcx,19F002D2B18
       call      qword ptr [0E8C8]; Precode of Tedd.Voxtree.OctreeThrowHelper.ThrowCoordinate(System.String, Int32)
       jmp       near ptr 000000000000CF55
M00_L24:
       mov       edx,r12d
       mov       rcx,19F002E22F8
       call      qword ptr [0E8C8]; Precode of Tedd.Voxtree.OctreeThrowHelper.ThrowCoordinate(System.String, Int32)
       jmp       near ptr 000000000000CF55
M00_L25:
       mov       edx,r14d
       mov       rcx,19F002E2310
       call      qword ptr [0E8C8]; Precode of Tedd.Voxtree.OctreeThrowHelper.ThrowCoordinate(System.String, Int32)
       jmp       near ptr 000000000000CF55
M00_L26:
       call      qword ptr [0E8F8]; Precode of Tedd.Voxtree.OctreeThrowHelper.ThrowMalformed()
       jmp       near ptr 000000000000CF55
M00_L27:
       mov       rcx,offset MT_System.ObjectDisposedException
       call      0000000000005240
       mov       rbx,rax
       mov       ecx,3F5
       mov       rdx,7FF83A862588
       call      qword ptr [7270]; Precode of System.String.StrCns(UInt32, IntPtr)
       mov       rdx,rax
       mov       rcx,rbx
       call      qword ptr [7B28]; Precode of System.ObjectDisposedException..ctor(System.String)
       mov       rcx,rbx
       call      000000000000B8A0
       int       3
M00_L28:
       mov       rcx,offset MT_System.ArgumentOutOfRangeException
       call      0000000000005240
       mov       rbx,rax
       mov       ecx,3E1
       mov       rdx,7FF83A862588
       call      qword ptr [7270]; Precode of System.String.StrCns(UInt32, IntPtr)
       mov       rdx,rax
       mov       rcx,rbx
       call      qword ptr [0D1A0]; Precode of System.ArgumentOutOfRangeException..ctor(System.String)
       mov       rcx,rbx
       call      000000000000B8A0
       int       3
M00_L29:
       mov       rcx,offset MT_System.ArgumentOutOfRangeException
       call      0000000000005240
       mov       rbx,rax
       mov       ecx,3F1
       mov       rdx,7FF83A862588
       call      qword ptr [7270]; Precode of System.String.StrCns(UInt32, IntPtr)
       mov       rdx,rax
       mov       rcx,rbx
       call      qword ptr [0D1A0]; Precode of System.ArgumentOutOfRangeException..ctor(System.String)
       mov       rcx,rbx
       call      000000000000B8A0
       int       3
M00_L30:
       mov       rcx,offset MT_System.ArgumentOutOfRangeException
       call      0000000000005240
       mov       rdi,rax
       mov       ecx,3E1
       mov       rdx,7FF83A862588
       call      qword ptr [7270]; Precode of System.String.StrCns(UInt32, IntPtr)
       mov       rdx,rax
       mov       rcx,rdi
       call      qword ptr [0D1A0]; Precode of System.ArgumentOutOfRangeException..ctor(System.String)
       mov       rcx,rdi
       call      000000000000B8A0
       int       3
M00_L31:
       call      qword ptr [7C18]; Precode of System.ThrowHelper.ThrowArgumentOutOfRangeException()
       int       3
M00_L32:
       call      0000000000001788
       int       3
M00_L33:
       call      0000000000001770
       int       3
; Total bytes of code 1530
```
```assembly
; Tedd.Voxtree.OctreeSpan.get_IsValid()
       cmp       dword ptr [rcx+8],0
       setne     al
       movzx     eax,al
       ret
; Total bytes of code 11
```
```assembly
; Tedd.Voxtree.OctreeCodec.TryGetUnchecked(System.ReadOnlySpan`1<Byte>, Int32, Tedd.Voxtree.StorageKind, Int32, Int32, Int32, UInt32 ByRef)
       push      r15
       push      r14
       push      r13
       push      r12
       push      rdi
       push      rsi
       push      rbp
       push      rbx
       sub       rsp,38
       vxorps    xmm4,xmm4,xmm4
       vmovdqa   xmmword ptr [rsp+20],xmm4
       xor       eax,eax
       mov       [rsp+30],rax
       mov       rbx,rcx
       mov       eax,[rsp+0A0]
       mov       r10d,[rsp+0A8]
       mov       rcx,[rsp+0B0]
       xor       r11d,r11d
       mov       [rcx],r11d
       mov       r11d,1
       shlx      r11d,r11d,edx
       movzx     r8d,r8b
       cmp       r8d,1
       je        near ptr 000000000000CC84
       cmp       r8d,2
       je        near ptr 000000000000CCD8
       test      edx,edx
       je        near ptr 000000000000CD2B
       mov       r8d,[rbx+8]
       cmp       r8d,0C
       jl        near ptr 000000000000CD2B
       lea       r11d,[r8+0FFFF]
       mov       esi,r11d
       cmp       esi,r8d
       ja        near ptr 000000000000CD0F
       mov       rdi,[rbx]
       mov       rbx,rdi
       cmp       r11d,r8d
       jae       near ptr 000000000000CD3E
       mov       r8d,r11d
       movzx     r8d,byte ptr [rdi+r8]
       mov       r11d,esi
       sub       r11d,r8d
       sub       r8d,9
       cmp       r8d,20
       ja        near ptr 000000000000CD2B
       cmp       r11d,2
       jl        near ptr 000000000000CD2B
       dec       edx
       js        near ptr 000000000000CD2B
M02_L00:
       cmp       r11d,esi
       jae       near ptr 000000000000CD2B
       lea       r8d,[r11+1]
       mov       edi,r11d
       movzx     edi,byte ptr [rbx+rdi]
       mov       ebp,edx
       and       ebp,1F
       sarx      r14d,r9d,ebp
       and       r14d,1
       shl       r14d,2
       mov       [rsp+0A0],eax
       sarx      r15d,eax,ebp
       and       r15d,1
       add       r15d,r15d
       or        r14d,r15d
       sarx      ebp,r10d,ebp
       and       ebp,1
       or        ebp,r14d
       jle       short 000000000000CBBB
       mov       r14d,ebp
M02_L01:
       mov       r15d,r8d
       xor       r13d,r13d
       cmp       r15d,esi
       jae       near ptr 000000000000CD2B
M02_L02:
       lea       r12d,[r8+1]
       mov       r8d,r8d
       movzx     r8d,byte ptr [rbx+r8]
       cmp       r13d,1C
       je        near ptr 000000000000CD16
M02_L03:
       test      r8b,80
       jne       short 000000000000CB9F
       mov       r13d,r12d
       sub       r13d,r15d
       cmp       r13d,1
       je        short 000000000000CB95
       test      r8b,7F
       je        near ptr 000000000000CD2B
M02_L04:
       dec       r14d
       je        short 000000000000CBBE
       mov       r8d,r12d
       jmp       short 000000000000CB54
M02_L05:
       add       r13d,7
       cmp       r13d,1C
       jg        near ptr 000000000000CD2B
       cmp       r12d,esi
       mov       r8d,r12d
       jae       near ptr 000000000000CD2B
       jmp       short 000000000000CB63
M02_L06:
       mov       r12d,r8d
M02_L07:
       xor       r8d,r8d
       mov       r14d,r12d
       xor       r15d,r15d
       cmp       r14d,esi
       jae       near ptr 000000000000CD2B
M02_L08:
       mov       r13d,r12d
       lea       r12d,[r13+1]
       cmp       r13d,esi
       jae       near ptr 000000000000CD3E
       movzx     r13d,byte ptr [rbx+r13]
       cmp       r15d,1C
       je        near ptr 000000000000CD21
M02_L09:
       mov       eax,r13d
       and       eax,7F
       shlx      eax,eax,r15d
       or        r8d,eax
       test      r13b,80
       jne       short 000000000000CC36
       mov       eax,r12d
       sub       eax,r14d
       cmp       eax,1
       je        short 000000000000CC18
       test      r13b,7F
       je        near ptr 000000000000CD2B
M02_L10:
       bt        edi,ebp
       jae       short 000000000000CC4F
       mov       [rcx],r8d
M02_L11:
       mov       eax,1
       add       rsp,38
       pop       rbx
       pop       rbp
       pop       rsi
       pop       rdi
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       ret
M02_L12:
       add       r15d,7
       cmp       r15d,1C
       jg        near ptr 000000000000CD2B
       cmp       r12d,esi
       jae       near ptr 000000000000CD2B
       jmp       short 000000000000CBD0
M02_L13:
       test      edx,edx
       je        near ptr 000000000000CD2B
       test      r8d,r8d
       je        near ptr 000000000000CD2B
       lea       eax,[r11+0FFFE]
       cmp       r8d,eax
       ja        near ptr 000000000000CD2B
       sub       r11d,r8d
       dec       edx
       mov       eax,[rsp+0A0]
       jns       near ptr 000000000000CB07
       jmp       near ptr 000000000000CD2B
M02_L14:
       mov       [rsp+0B0],rcx
       mov       dword ptr [rsp+30],2
       vmovdqu   xmm0,xmmword ptr [rbx]
       vmovdqu   xmmword ptr [rsp+20],xmm0
       lea       rcx,[rsp+20]
       lea       rdx,[rsp+30]
       mov       r8,[rsp+0B0]
       call      qword ptr [0D5C0]; Tedd.Voxtree.OctreeCodec.TryReadVarUInt(System.ReadOnlySpan`1<Byte>, Int32 ByRef, UInt32 ByRef)
       test      eax,eax
       je        short 000000000000CD2B
       mov       eax,[rsp+30]
       cmp       eax,[rbx+8]
       sete      al
       movzx     eax,al
       add       rsp,38
       pop       rbx
       pop       rbp
       pop       rsi
       pop       rdi
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       ret
M02_L15:
       imul      r9d,r11d
       imul      r9d,r11d
       imul      eax,r11d
       add       eax,r9d
       add       eax,r10d
       lea       eax,[rax*4+2]
       mov       edx,eax
       add       rdx,4
       mov       r8d,[rbx+8]
       cmp       rdx,r8
       ja        short 000000000000CD0F
       mov       rdi,[rbx]
       add       rax,rdi
       mov       eax,[rax]
       mov       [rcx],eax
       jmp       near ptr 000000000000CC20
M02_L16:
       call      qword ptr [7C18]; Precode of System.ThrowHelper.ThrowArgumentOutOfRangeException()
       int       3
M02_L17:
       test      r8b,0F0
       jne       short 000000000000CD2B
       jmp       near ptr 000000000000CB79
M02_L18:
       test      r13b,0F0
       je        near ptr 000000000000CBEF
M02_L19:
       xor       eax,eax
       add       rsp,38
       pop       rbx
       pop       rbp
       pop       rsi
       pop       rdi
       pop       r12
       pop       r13
       pop       r14
       pop       r15
       ret
M02_L20:
       call      0000000000001788
       int       3
; Total bytes of code 772
```
```assembly
; Tedd.Voxtree.HotOctreeChunk.get_Item(Int32, Int32, Int32, Int32)
       push      rbp
       sub       rsp,40
       lea       rbp,[rsp+40]
       xor       eax,eax
       mov       [rbp+0FFF0],rax
       mov       [rbp+0FFF8],rax
       mov       [rbp+10],rcx
       mov       [rbp+18],edx
       mov       [rbp+20],r8d
       mov       [rbp+28],r9d
       lea       rdx,[rbp+0FFF0]
       mov       rcx,[rbp+10]
       mov       r8d,[rbp+18]
       call      qword ptr [0E628]; Tedd.Voxtree.HotOctreeChunk.GetChannelSpan(Int32)
       mov       rcx,[rbp+10]
       call      qword ptr [0E640]; Tedd.Voxtree.HotOctreeChunk.get_Levels()
       mov       [rbp+0FFE8],eax
       mov       dword ptr [rsp+20],1
       mov       r9d,[rbp+0FFE8]
       mov       edx,[rbp+28]
       mov       r8d,[rbp+30]
       mov       ecx,[rbp+20]
       call      qword ptr [0E658]; Tedd.Voxtree.DenseVoxel.GetIndex(Int32, Int32, Int32, Int32, Tedd.Voxtree.DenseVoxelLayout)
       mov       [rbp+0FFEC],eax
       mov       eax,[rbp+0FFF8]
       cmp       [rbp+0FFEC],eax
       jae       short 0000000000009459
       mov       eax,[rbp+0FFEC]
       mov       rcx,[rbp+0FFF0]
       mov       eax,[rcx+rax*4]
       add       rsp,40
       pop       rbp
       ret
M03_L00:
       call      0000000000001788
       int       3
; Total bytes of code 127
```
```assembly
; System.SpanHelpers.NonPackedIndexOfValueType[[System.Int32, System.Private.CoreLib],[System.SpanHelpers+DontNegate`1[[System.Int32, System.Private.CoreLib]], System.Private.CoreLib]](Int32 ByRef, Int32, Int32)
       cmp       r8d,4
       jl        near ptr 0000000000000E5A
       movd      xmm0,edx
       pshufd    xmm0,xmm0,0
       mov       rdx,rcx
       lea       eax,[r8+0FFFC]
       cdqe
       shl       rax,2
       lea       r10,[rdx+rax]
       movups    xmm1,[rcx]
       pcmpeqd   xmm1,xmm0
       ptest     xmm1,xmm1
       je        short 0000000000000E13
M04_L00:
       movmskps  eax,xmm1
       bsf       r8d,eax
       mov       r10d,20
       test      eax,eax
       cmove     r8d,r10d
       mov       rax,rdx
       sub       rax,rcx
       shr       rax,2
       add       eax,r8d
M04_L01:
       ret
M04_L02:
       add       rdx,10
       cmp       rdx,r10
       jbe       near ptr 0000000000000F43
       mov       ecx,r8d
       test      cl,3
       je        near ptr 0000000000000F5A
       movups    xmm1,[r10]
       pcmpeqd   xmm1,xmm0
       ptest     xmm1,xmm1
       je        near ptr 0000000000000F5A
       movmskps  edx,xmm1
       bsf       r8d,edx
       mov       ecx,20
       test      edx,edx
       cmove     r8d,ecx
       shr       rax,2
       add       eax,r8d
       jmp       short 0000000000000E12
M04_L03:
       xor       r10d,r10d
       cmp       r8d,8
       jge       short 0000000000000E8D
M04_L04:
       cmp       r8d,4
       jge       short 0000000000000EDC
M04_L05:
       test      r8d,r8d
       jle       near ptr 0000000000000F5A
M04_L06:
       dec       r8d
       cmp       [rcx+r10*4],edx
       je        short 0000000000000E88
       inc       r10
       test      r8d,r8d
       jg        short 0000000000000E72
       jmp       near ptr 0000000000000F5A
M04_L07:
       mov       eax,r10d
       jmp       short 0000000000000E12
M04_L08:
       add       r8d,0FFFFFFF8
       cmp       [rcx+r10*4],edx
       je        short 0000000000000E88
       cmp       [rcx+r10*4+4],edx
       je        near ptr 0000000000000F3A
       cmp       [rcx+r10*4+8],edx
       je        near ptr 0000000000000F31
       cmp       [rcx+r10*4+0C],edx
       je        short 0000000000000F28
       cmp       [rcx+r10*4+10],edx
       je        short 0000000000000F1F
       cmp       [rcx+r10*4+14],edx
       je        short 0000000000000F16
       cmp       [rcx+r10*4+18],edx
       je        short 0000000000000F0D
       cmp       [rcx+r10*4+1C],edx
       je        short 0000000000000F04
       add       r10,8
       cmp       r8d,8
       jge       short 0000000000000E8D
       jmp       short 0000000000000E63
M04_L09:
       add       r8d,0FFFFFFFC
       cmp       [rcx+r10*4],edx
       je        short 0000000000000E88
       cmp       [rcx+r10*4+4],edx
       je        short 0000000000000F3A
       cmp       [rcx+r10*4+8],edx
       je        short 0000000000000F31
       cmp       [rcx+r10*4+0C],edx
       je        short 0000000000000F28
       add       r10,4
       jmp       near ptr 0000000000000E69
M04_L10:
       lea       eax,[r10+7]
       jmp       near ptr 0000000000000E12
M04_L11:
       lea       eax,[r10+6]
       jmp       near ptr 0000000000000E12
M04_L12:
       lea       eax,[r10+5]
       jmp       near ptr 0000000000000E12
M04_L13:
       lea       eax,[r10+4]
       jmp       near ptr 0000000000000E12
M04_L14:
       lea       eax,[r10+3]
       jmp       near ptr 0000000000000E12
M04_L15:
       lea       eax,[r10+2]
       jmp       near ptr 0000000000000E12
M04_L16:
       lea       eax,[r10+1]
       jmp       near ptr 0000000000000E12
M04_L17:
       movups    xmm1,[rdx]
       pcmpeqd   xmm1,xmm0
       ptest     xmm1,xmm1
       jne       near ptr 0000000000000DF2
       jmp       near ptr 0000000000000E13
M04_L18:
       mov       eax,0FFFFFFFF
       ret
; Total bytes of code 416
```
```assembly
; System.PackedSpanHelpers.IndexOf[[System.SpanHelpers+DontNegate`1[[System.Int16, System.Private.CoreLib]], System.Private.CoreLib],[System.PackedSpanHelpers+NopTransform, System.Private.CoreLib]](Int16 ByRef, Int16, Int32)
       push      r14
       push      rdi
       push      rsi
       push      rbp
       push      rbx
       sub       rsp,50
       vmovaps   [rsp+40],xmm6
       vmovaps   [rsp+30],xmm7
       vmovaps   [rsp+20],xmm8
       mov       rsi,rcx
       mov       edi,edx
       mov       ebx,r8d
       cmp       ebx,8
       jl        near ptr 000000000000D4FC
       mov       rbp,rsi
       cmp       ebx,10
       jle       near ptr 000000000000D479
       vmovd     xmm6,edi
       vpbroadcastb ymm6,xmm6
       cmp       ebx,20
       jle       near ptr 000000000000D3B4
       lea       ecx,[rbx+0FFE0]
       movsxd    rcx,ecx
       lea       rdi,[rbp+rcx*2]
       vmovups   ymm0,[rsi]
       vpackuswb ymm0,ymm0,[rsi+20]
       vpcmpeqb  ymm7,ymm0,ymm6
       vptest    ymm7,ymm7
       jne       short 000000000000D363
M05_L00:
       add       rbp,40
       cmp       rbp,rdi
       jae       short 000000000000D399
       mov       rcx,7FF83A4BB8A0
       vextractf128 xmm8,ymm6,1
       call      0000000000008420
       vmovups   ymm0,[rbp]
       vpackuswb ymm0,ymm0,[rbp+20]
       vinsertf128 ymm6,ymm6,xmm8,1
       vpcmpeqb  ymm7,ymm0,ymm6
       vptest    ymm7,ymm7
       je        short 000000000000D32A
M05_L01:
       mov       rcx,7FF83A4BB894
       vextractf128 xmm8,ymm7,1
       call      0000000000008420
       mov       rax,rbp
       sub       rax,rsi
       shr       rax,1
       vinsertf128 ymm7,ymm7,xmm8,1
       vpermq    ymm0,ymm7,0D8
       vpmovmskb ecx,ymm0
       tzcnt     ecx,ecx
       add       eax,ecx
       jmp       short 000000000000D3FC
M05_L02:
       mov       rcx,7FF83A4BB89C
       vextractf128 xmm8,ymm6,1
       call      0000000000008420
       vinsertf128 ymm6,ymm6,xmm8,1
M05_L03:
       add       ebx,0FFFFFFF0
       movsxd    rcx,ebx
       lea       rbx,[rsi+rcx*2]
       cmp       rbp,rbx
       ja        short 000000000000D41C
       mov       rdi,rbp
M05_L04:
       vmovups   ymm0,[rdi]
       vpackuswb ymm0,ymm0,[rbx]
       vpcmpeqb  ymm6,ymm0,ymm6
       vptest    ymm6,ymm6
       jne       short 000000000000D43C
       mov       rcx,7FF83A4BB8AC
       call      0000000000008420
M05_L05:
       mov       rcx,7FF83A4BB8BC
       call      0000000000008420
       mov       eax,0FFFFFFFF
M05_L06:
       vzeroupper
       vmovaps   xmm6,[rsp+40]
       vmovaps   xmm7,[rsp+30]
       vmovaps   xmm8,[rsp+20]
       add       rsp,50
       pop       rbx
       pop       rbp
       pop       rsi
       pop       rdi
       pop       r14
       ret
M05_L07:
       mov       rcx,7FF83A4BB8A4
       vextractf128 xmm8,ymm6,1
       call      0000000000008420
       mov       rdi,rbx
       vinsertf128 ymm6,ymm6,xmm8,1
       jmp       short 000000000000D3C6
M05_L08:
       mov       rcx,7FF83A4BB8A8
       vextractf128 xmm7,ymm6,1
       call      0000000000008420
       vinsertf128 ymm6,ymm6,xmm7,1
       vpermq    ymm0,ymm6,0D8
       vpmovmskb ecx,ymm0
       tzcnt     ecx,ecx
       cmp       ecx,10
       jge       near ptr 000000000000D650
M05_L09:
       sub       rdi,rsi
       shr       rdi,1
       lea       eax,[rdi+rcx]
       jmp       short 000000000000D3FC
M05_L10:
       mov       rcx,7FF83A4BB898
       call      0000000000008420
       vmovd     xmm6,edi
       vpbroadcastb xmm6,xmm6
       lea       ecx,[rbx+0FFF8]
       movsxd    rcx,ecx
       lea       rbx,[rsi+rcx*2]
       cmp       rsi,rbx
       ja        near ptr 000000000000D65B
       mov       rdi,rsi
M05_L11:
       vmovups   xmm0,[rdi]
       vpackuswb xmm0,xmm0,[rbx]
       vpcmpeqb  xmm6,xmm0,xmm6
       vptest    xmm6,xmm6
       jne       short 000000000000D4CE
       mov       rcx,7FF83A4BB8B8
       call      0000000000008420
       jmp       near ptr 000000000000D3E8
M05_L12:
       mov       rcx,7FF83A4BB8B4
       call      0000000000008420
       vpmovmskb ecx,xmm6
       tzcnt     ecx,ecx
       cmp       ecx,8
       jge       near ptr 000000000000D672
M05_L13:
       sub       rdi,rsi
       shr       rdi,1
       lea       eax,[rdi+rcx]
       jmp       near ptr 000000000000D3FC
M05_L14:
       xor       ebp,ebp
       cmp       ebx,4
       jl        short 000000000000D555
       add       ebx,0FFFFFFFC
       movsx     rcx,word ptr [rsi]
       movsx     r14,di
       cmp       ecx,r14d
       je        near ptr 000000000000D59E
       movsx     rcx,word ptr [rsi+2]
       cmp       ecx,r14d
       je        near ptr 000000000000D5CF
       movsx     rcx,word ptr [rsi+4]
       cmp       ecx,r14d
       je        near ptr 000000000000D603
       movsx     rcx,word ptr [rsi+6]
       cmp       ecx,r14d
       je        near ptr 000000000000D637
       mov       rcx,7FF83A4BB888
       call      0000000000008420
       mov       ebp,4
M05_L15:
       test      ebx,ebx
       jle       near ptr 000000000000D3E8
       movsx     r14,di
M05_L16:
       dec       ebx
       movsx     rcx,word ptr [rsi+rbp*2]
       cmp       ecx,r14d
       je        short 000000000000D588
       mov       rcx,7FF83A4BB890
       call      0000000000008420
       inc       rbp
       test      ebx,ebx
       jg        short 000000000000D561
       jmp       near ptr 000000000000D3E8
M05_L17:
       mov       rcx,7FF83A4BB88C
       call      0000000000008420
       mov       eax,ebp
       jmp       near ptr 000000000000D3FC
M05_L18:
       mov       rcx,7FF83A4BB878
       call      0000000000008420
       xor       eax,eax
       vzeroupper
       vmovaps   xmm6,[rsp+40]
       vmovaps   xmm7,[rsp+30]
       vmovaps   xmm8,[rsp+20]
       add       rsp,50
       pop       rbx
       pop       rbp
       pop       rsi
       pop       rdi
       pop       r14
       ret
M05_L19:
       mov       rcx,7FF83A4BB87C
       call      0000000000008420
       mov       eax,1
       vzeroupper
       vmovaps   xmm6,[rsp+40]
       vmovaps   xmm7,[rsp+30]
       vmovaps   xmm8,[rsp+20]
       add       rsp,50
       pop       rbx
       pop       rbp
       pop       rsi
       pop       rdi
       pop       r14
       ret
M05_L20:
       mov       rcx,7FF83A4BB880
       call      0000000000008420
       mov       eax,2
       vzeroupper
       vmovaps   xmm6,[rsp+40]
       vmovaps   xmm7,[rsp+30]
       vmovaps   xmm8,[rsp+20]
       add       rsp,50
       pop       rbx
       pop       rbp
       pop       rsi
       pop       rdi
       pop       r14
       ret
M05_L21:
       mov       rcx,7FF83A4BB884
       call      0000000000008420
       mov       eax,3
       jmp       near ptr 000000000000D3FC
M05_L22:
       mov       rdi,rbx
       add       ecx,0FFFFFFF0
       jmp       near ptr 000000000000D46E
M05_L23:
       mov       rcx,7FF83A4BB8B0
       call      0000000000008420
       mov       rdi,rbx
       jmp       near ptr 000000000000D4A7
M05_L24:
       mov       rdi,rbx
       add       ecx,0FFFFFFF8
       jmp       near ptr 000000000000D4EE
; Total bytes of code 957
```
```assembly
; Tedd.Voxtree.SparseVoxelEdits`1[[System.UInt32, System.Private.CoreLib]].HasValue(Int32, Int32)
       push      rbp
       sub       rsp,20
       lea       rbp,[rsp+20]
       mov       [rbp+10],rcx
       mov       [rbp+18],edx
       mov       [rbp+20],r8d
       mov       rax,[rbp+10]
       mov       rax,[rax+20]
       mov       rcx,[rbp+10]
       mov       ecx,[rcx+2C]
       imul      ecx,[rbp+18]
       mov       edx,[rbp+20]
       sar       edx,6
       add       ecx,edx
       cmp       ecx,[rax+8]
       jae       short 00000000000096DB
       mov       edx,ecx
       lea       rax,[rax+rdx*8+10]
       mov       ecx,1
       mov       edx,[rbp+20]
       shlx      rcx,rcx,rdx
       and       rcx,[rax]
       test      rcx,rcx
       setne     al
       movzx     eax,al
       add       rsp,20
       pop       rbp
       ret
M06_L00:
       call      0000000000001788
       int       3
; Total bytes of code 97
```
```assembly
; Tedd.Voxtree.OctreeCodec.TryReadVarUInt(System.ReadOnlySpan`1<Byte>, Int32 ByRef, UInt32 ByRef)
       push      rbx
       sub       rsp,20
       mov       rax,[rcx]
       mov       ecx,[rcx+8]
       xor       r10d,r10d
       mov       [r8],r10d
       mov       r10d,[rdx]
       mov       r9d,r10d
       xor       r11d,r11d
       cmp       r10d,ecx
       jae       short 000000000000A927
M07_L00:
       mov       r10d,[rdx]
       lea       ebx,[r10+1]
       mov       [rdx],ebx
       cmp       r10d,ecx
       jae       short 000000000000A92F
       movzx     r10d,byte ptr [rax+r10]
       cmp       r11d,1C
       je        short 000000000000A921
M07_L01:
       mov       ebx,r10d
       and       ebx,7F
       shlx      ebx,ebx,r11d
       or        [r8],ebx
       test      r10b,80
       jne       short 000000000000A901
       mov       eax,[rdx]
       sub       eax,r9d
       cmp       eax,1
       jne       short 000000000000A911
       mov       eax,1
       add       rsp,20
       pop       rbx
       ret
M07_L02:
       add       r11d,7
       cmp       r11d,1C
       jg        short 000000000000A927
       cmp       [rdx],ecx
       jae       short 000000000000A927
       jmp       short 000000000000A8BF
M07_L03:
       test      r10b,7F
       setne     al
       movzx     eax,al
       add       rsp,20
       pop       rbx
       ret
M07_L04:
       test      r10b,0F0
       je        short 000000000000A8D8
M07_L05:
       xor       eax,eax
       add       rsp,20
       pop       rbx
       ret
M07_L06:
       call      0000000000001788
       int       3
; Total bytes of code 149
```
```assembly
; Tedd.Voxtree.HotOctreeChunk.GetChannelSpan(Int32)
       push      rbp
       sub       rsp,50
       lea       rbp,[rsp+50]
       xor       eax,eax
       mov       [rbp+0FFD8],rax
       vxorps    xmm4,xmm4,xmm4
       vmovdqu   ymmword ptr [rbp+0FFE0],ymm4
       mov       [rbp+10],rcx
       mov       [rbp+18],rdx
       mov       [rbp+20],r8d
       mov       rcx,[rbp+10]
       call      qword ptr [0E688]; Tedd.Voxtree.HotOctreeChunk.GetValues()
       mov       [rbp+0FFF0],rax
       mov       rax,[rbp+0FFF0]
       mov       [rbp+0FFE8],rax
       mov       rcx,[rbp+10]
       call      qword ptr [0E6A0]; Tedd.Voxtree.HotOctreeChunk.get_ChannelCount()
       cmp       eax,[rbp+20]
       ja        short 0000000000008C1E
       mov       rcx,offset MT_System.ArgumentOutOfRangeException
       call      0000000000005240
       mov       [rbp+0FFE0],rax
       mov       ecx,3E1
       mov       rdx,7FF83A862588
       call      qword ptr [7270]; Precode of System.String.StrCns(UInt32, IntPtr)
       mov       [rbp+0FFD8],rax
       mov       rdx,[rbp+0FFD8]
       mov       rcx,[rbp+0FFE0]
       call      qword ptr [0D1A0]; Precode of System.ArgumentOutOfRangeException..ctor(System.String)
       mov       rcx,[rbp+0FFE0]
       call      000000000000B8A0
       int       3
M08_L00:
       mov       rcx,[rbp+10]
       call      qword ptr [0E640]; Tedd.Voxtree.HotOctreeChunk.get_Levels()
       mov       ecx,eax
       call      qword ptr [0D188]; Tedd.Voxtree.OctreeCodec.GetVoxelCount(Int32)
       mov       [rbp+0FFFC],eax
       mov       eax,[rbp+20]
       mov       r8d,eax
       imul      r8d,[rbp+0FFFC]
       mov       rcx,[rbp+18]
       mov       rdx,[rbp+0FFE8]
       mov       r9d,[rbp+0FFFC]
       call      qword ptr [0E670]; System.MemoryExtensions.AsSpan[[System.UInt32, System.Private.CoreLib]](UInt32[], Int32, Int32)
       mov       rax,[rbp+18]
       add       rsp,50
       pop       rbp
       ret
; Total bytes of code 202
```
```assembly
; Tedd.Voxtree.HotOctreeChunk.get_Levels()
       push      rbp
       mov       rbp,rsp
       mov       [rbp+10],rcx
       mov       rax,[rbp+10]
       mov       eax,[rax+20]
       pop       rbp
       ret
; Total bytes of code 17
```
```assembly
; Tedd.Voxtree.DenseVoxel.GetIndex(Int32, Int32, Int32, Int32, Tedd.Voxtree.DenseVoxelLayout)
       push      rbp
       sub       rsp,40
       lea       rbp,[rsp+40]
       vxorps    xmm4,xmm4,xmm4
       vmovdqu   xmmword ptr [rbp+0FFE8],xmm4
       xor       eax,eax
       mov       [rbp+0FFF8],rax
       mov       [rbp+10],ecx
       mov       [rbp+18],edx
       mov       [rbp+20],r8d
       mov       [rbp+28],r9d
       mov       ecx,[rbp+28]
       call      qword ptr [0D170]; Tedd.Voxtree.OctreeCodec.ValidateLevels(Int32)
       mov       ecx,[rbp+30]
       call      qword ptr [0D068]; Tedd.Voxtree.DenseVoxel.Validate(Tedd.Voxtree.DenseVoxelLayout)
       mov       eax,1
       mov       ecx,[rbp+28]
       shlx      eax,eax,ecx
       mov       [rbp+0FFFC],eax
       mov       eax,[rbp+10]
       cmp       eax,[rbp+0FFFC]
       jae       short 0000000000008E10
       mov       eax,[rbp+18]
       cmp       eax,[rbp+0FFFC]
       jae       short 0000000000008E54
       mov       eax,[rbp+20]
       cmp       eax,[rbp+0FFFC]
       jb        short 0000000000008E65
       mov       rcx,7FF83A952740
       call      0000000000008420
M10_L00:
       mov       rcx,offset MT_System.ArgumentOutOfRangeException
       call      0000000000005240
       mov       [rbp+0FFF0],rax
       mov       ecx,3F1
       mov       rdx,7FF83A862588
       call      qword ptr [7270]; Precode of System.String.StrCns(UInt32, IntPtr)
       mov       [rbp+0FFE8],rax
       mov       rdx,[rbp+0FFE8]
       mov       rcx,[rbp+0FFF0]
       call      qword ptr [0D1A0]; Precode of System.ArgumentOutOfRangeException..ctor(System.String)
       mov       rcx,[rbp+0FFF0]
       call      000000000000B8A0
       int       3
M10_L01:
       mov       rcx,7FF83A952744
       call      0000000000008420
       jmp       short 0000000000008E10
M10_L02:
       mov       rcx,7FF83A952748
       call      0000000000008420
       mov       eax,[rbp+30]
       mov       [rsp+20],eax
       mov       ecx,[rbp+10]
       mov       edx,[rbp+18]
       mov       r8d,[rbp+20]
       mov       r9d,[rbp+0FFFC]
       call      qword ptr [0E6B8]; Tedd.Voxtree.DenseVoxel.Index(Int32, Int32, Int32, Int32, Tedd.Voxtree.DenseVoxelLayout)
       nop
       add       rsp,40
       pop       rbp
       ret
; Total bytes of code 246
```
```assembly
; Tedd.Voxtree.HotOctreeChunk.GetValues()
       push      rbp
       sub       rsp,40
       lea       rbp,[rsp+40]
       vxorps    xmm4,xmm4,xmm4
       vmovdqu   ymmword ptr [rbp+0FFE0],ymm4
       mov       [rbp+10],rcx
       mov       rax,[rbp+10]
       mov       rax,[rax+8]
       mov       [rbp+0FFF8],rax
       mov       rax,[rbp+0FFF8]
       mov       [rbp+0FFF0],rax
       cmp       qword ptr [rbp+0FFF8],0
       jne       short 0000000000008CE6
       mov       rcx,offset MT_System.InvalidOperationException
       call      0000000000005240
       mov       [rbp+0FFE8],rax
       mov       ecx,9F3
       mov       rdx,7FF83A862588
       call      qword ptr [7270]; Precode of System.String.StrCns(UInt32, IntPtr)
       mov       [rbp+0FFE0],rax
       mov       rdx,[rbp+0FFE0]
       mov       rcx,[rbp+0FFE8]
       call      qword ptr [65C8]; Precode of System.InvalidOperationException..ctor(System.String)
       mov       rcx,[rbp+0FFE8]
       call      000000000000B8A0
       int       3
M11_L00:
       mov       rax,[rbp+0FFF0]
       add       rsp,40
       pop       rbp
       ret
; Total bytes of code 128
```
```assembly
; Tedd.Voxtree.HotOctreeChunk.get_ChannelCount()
       push      rbp
       mov       rbp,rsp
       mov       [rbp+10],rcx
       mov       rax,[rbp+10]
       mov       eax,[rax+24]
       pop       rbp
       ret
; Total bytes of code 17
```
```assembly
; Tedd.Voxtree.OctreeCodec.GetVoxelCount(Int32)
       push      rbp
       mov       rbp,rsp
       mov       [rbp+10],ecx
       mov       eax,1
       mov       ecx,[rbp+10]
       lea       ecx,[rcx+rcx*2]
       shlx      eax,eax,ecx
       pop       rbp
       ret
; Total bytes of code 25
```
```assembly
; System.MemoryExtensions.AsSpan[[System.UInt32, System.Private.CoreLib]](UInt32[], Int32, Int32)
       sub       rsp,28
       test      rdx,rdx
       je        short 0000000000008D6F
       mov       r8d,r8d
       mov       eax,r9d
       add       rax,r8
       mov       r10d,[rdx+8]
       cmp       rax,r10
       ja        short 0000000000008D7B
       lea       rax,[rdx+r8*4+10]
M14_L00:
       mov       [rcx],rax
       mov       [rcx+8],r9d
       mov       rax,rcx
       add       rsp,28
       ret
M14_L01:
       or        r8d,r9d
       jne       short 0000000000008D7B
       xor       eax,eax
       xor       r9d,r9d
       jmp       short 0000000000008D60
M14_L02:
       call      qword ptr [7C18]; Precode of System.ThrowHelper.ThrowArgumentOutOfRangeException()
       int       3
; Total bytes of code 66
```
```assembly
; Tedd.Voxtree.OctreeCodec.ValidateLevels(Int32)
       push      rbp
       sub       rsp,80
       lea       rbp,[rsp+80]
       xor       eax,eax
       mov       [rbp+0FFA8],rax
       vxorps    xmm4,xmm4,xmm4
       vmovdqu   ymmword ptr [rbp+0FFB0],ymm4
       vmovdqu   ymmword ptr [rbp+0FFD0],ymm4
       vmovdqa   xmmword ptr [rbp+0FFF0],xmm4
       mov       [rbp+10],ecx
       cmp       dword ptr [rbp+10],9
       jbe       near ptr 0000000000007FEF
       mov       rcx,offset MT_System.Int32
       call      0000000000005240
       mov       [rbp+0FFD0],rax
       mov       rax,[rbp+0FFD0]
       mov       ecx,[rbp+10]
       mov       [rax+8],ecx
       lea       rcx,[rbp+0FFD8]
       mov       edx,31
       mov       r8d,1
       call      qword ptr [68C8]; System.Runtime.CompilerServices.DefaultInterpolatedStringHandler..ctor(Int32, Int32)
       mov       ecx,1341
       mov       rdx,7FF83A862588
       call      qword ptr [7270]; Precode of System.String.StrCns(UInt32, IntPtr)
       mov       [rbp+0FFC0],rax
       mov       rdx,[rbp+0FFC0]
       lea       rcx,[rbp+0FFD8]
       call      qword ptr [6C10]; System.Runtime.CompilerServices.DefaultInterpolatedStringHandler.AppendLiteral(System.String)
       lea       rcx,[rbp+0FFD8]
       mov       edx,9
       call      qword ptr [6AC0]; System.Runtime.CompilerServices.DefaultInterpolatedStringHandler.AppendFormatted[[System.Int32, System.Private.CoreLib]](Int32)
       mov       ecx,369
       mov       rdx,7FF83A862588
       call      qword ptr [7270]; Precode of System.String.StrCns(UInt32, IntPtr)
       mov       [rbp+0FFB8],rax
       mov       rdx,[rbp+0FFB8]
       lea       rcx,[rbp+0FFD8]
       call      qword ptr [6C10]; System.Runtime.CompilerServices.DefaultInterpolatedStringHandler.AppendLiteral(System.String)
       mov       rcx,offset MT_System.ArgumentOutOfRangeException
       call      0000000000005240
       mov       [rbp+0FFC8],rax
       mov       ecx,1333
       mov       rdx,7FF83A862588
       call      qword ptr [7270]; Precode of System.String.StrCns(UInt32, IntPtr)
       mov       [rbp+0FFB0],rax
       lea       rcx,[rbp+0FFD8]
       call      qword ptr [68F8]; System.Runtime.CompilerServices.DefaultInterpolatedStringHandler.ToStringAndClear()
       mov       [rbp+0FFA8],rax
       mov       rdx,[rbp+0FFB0]
       mov       r9,[rbp+0FFA8]
       mov       r8,[rbp+0FFD0]
       mov       rcx,[rbp+0FFC8]
       call      qword ptr [7AC8]; Precode of System.ArgumentOutOfRangeException..ctor(System.String, System.Object, System.String)
       mov       rcx,[rbp+0FFC8]
       call      000000000000B8A0
       int       3
M15_L00:
       add       rsp,80
       pop       rbp
       ret
; Total bytes of code 296
```
```assembly
; Tedd.Voxtree.DenseVoxel.Validate(Tedd.Voxtree.DenseVoxelLayout)
       push      rbp
       sub       rsp,30
       lea       rbp,[rsp+30]
       xor       eax,eax
       mov       [rbp+0FFF8],rax
       mov       [rbp+0FFF0],rax
       mov       [rbp+10],ecx
       cmp       dword ptr [rbp+10],0
       je        short 0000000000008086
       cmp       dword ptr [rbp+10],1
       je        short 0000000000008077
       mov       rcx,offset MT_System.ArgumentOutOfRangeException
       call      0000000000005240
       mov       [rbp+0FFF8],rax
       mov       ecx,4B5
       mov       rdx,7FF83A862588
       call      qword ptr [7270]; Precode of System.String.StrCns(UInt32, IntPtr)
       mov       [rbp+0FFF0],rax
       mov       rdx,[rbp+0FFF0]
       mov       rcx,[rbp+0FFF8]
       call      qword ptr [0D1A0]; Precode of System.ArgumentOutOfRangeException..ctor(System.String)
       mov       rcx,[rbp+0FFF8]
       call      000000000000B8A0
       int       3
M16_L00:
       mov       rcx,7FF83A9524F0
       call      0000000000008420
M16_L01:
       mov       rcx,7FF83A9524F4
       call      0000000000008420
       nop
       add       rsp,30
       pop       rbp
       ret
; Total bytes of code 140
```
```assembly
; Tedd.Voxtree.DenseVoxel.Index(Int32, Int32, Int32, Int32, Tedd.Voxtree.DenseVoxelLayout)
       push      rbp
       sub       rsp,20
       lea       rbp,[rsp+20]
       mov       [rbp+10],ecx
       mov       [rbp+18],edx
       mov       [rbp+20],r8d
       mov       [rbp+28],r9d
       cmp       dword ptr [rbp+30],0
       je        short 0000000000008EF4
       mov       rcx,7FF83A952780
       call      0000000000008420
       mov       ecx,[rbp+10]
       mov       edx,[rbp+18]
       mov       r8d,[rbp+20]
       call      qword ptr [0E6D0]; Tedd.MortonEncoding.Encode(UInt32, UInt32, UInt32)
       nop
       add       rsp,20
       pop       rbp
       ret
M17_L00:
       mov       rcx,7FF83A952784
       call      0000000000008420
       mov       eax,[rbp+10]
       imul      eax,[rbp+28]
       add       eax,[rbp+18]
       imul      eax,[rbp+28]
       add       eax,[rbp+20]
       add       rsp,20
       pop       rbp
       ret
; Total bytes of code 106
```
```assembly
; System.Runtime.CompilerServices.DefaultInterpolatedStringHandler..ctor(Int32, Int32)
       push      rdi
       push      rsi
       push      rbx
       sub       rsp,20
       mov       rbx,rcx
       mov       esi,edx
       mov       edi,r8d
       xor       eax,eax
       mov       [rbx],rax
       call      qword ptr [0A098]
       mov       rcx,[rax]
       imul      edx,edi,0B
       add       edx,esi
       mov       eax,100
       cmp       edx,100
       cmovle    edx,eax
       cmp       [rcx],ecx
       call      qword ptr [98B8]; Precode of System.Buffers.SharedArrayPool`1[[System.Char, System.Private.CoreLib]].Rent(Int32)
       mov       [rbx+8],rax
       test      rax,rax
       je        short 000000000000C4E0
       lea       rcx,[rax+10]
       mov       eax,[rax+8]
M18_L00:
       mov       [rbx+18],rcx
       mov       [rbx+20],eax
       xor       eax,eax
       mov       [rbx+10],eax
       mov       byte ptr [rbx+14],0
       add       rsp,20
       pop       rbx
       pop       rsi
       pop       rdi
       ret
M18_L01:
       xor       ecx,ecx
       xor       eax,eax
       jmp       short 000000000000C4C8
; Total bytes of code 102
```
```assembly
; System.Runtime.CompilerServices.DefaultInterpolatedStringHandler.AppendLiteral(System.String)
       push      rdi
       push      rsi
       push      rbx
       sub       rsp,20
       mov       rbx,rcx
       mov       rsi,rdx
       lea       r8,[rbx+18]
       mov       edx,[rbx+10]
       mov       ecx,[r8+8]
       cmp       edx,ecx
       ja        short 0000000000004F2B
       mov       r8,[r8]
       mov       eax,edx
       lea       rax,[r8+rax*2]
       sub       ecx,edx
       mov       edi,[rsi+8]
       cmp       edi,ecx
       ja        short 0000000000004F32
       mov       r8d,edi
       add       r8,r8
       lea       rdx,[rsi+0C]
       mov       rcx,rax
       call      qword ptr [5818]; System.SpanHelpers.Memmove(Byte ByRef, Byte ByRef, UIntPtr)
       mov       rcx,7FF83A818D10
       call      0000000000008420
       add       [rbx+10],edi
       add       rsp,20
       pop       rbx
       pop       rsi
       pop       rdi
       ret
M19_L00:
       call      qword ptr [7C18]; Precode of System.ThrowHelper.ThrowArgumentOutOfRangeException()
       int       3
M19_L01:
       mov       rcx,7FF83A818D14
       call      0000000000008420
       mov       rcx,rbx
       mov       rdx,rsi
       add       rsp,20
       pop       rbx
       pop       rsi
       pop       rdi
       jmp       qword ptr [68E0]; Precode of System.Runtime.CompilerServices.DefaultInterpolatedStringHandler.GrowThenCopyString(System.String)
; Total bytes of code 132
```
```assembly
; System.Runtime.CompilerServices.DefaultInterpolatedStringHandler.AppendFormatted[[System.Int32, System.Private.CoreLib]](Int32)
       push      rdi
       push      rsi
       push      rbp
       push      rbx
       sub       rsp,58
       xorps     xmm4,xmm4
       movaps    [rsp+30],xmm4
       movaps    [rsp+40],xmm4
       mov       rbx,rcx
       mov       esi,edx
       cmp       byte ptr [rbx+14],0
       jne       short 000000000000F15B
M20_L00:
       lea       rdx,[rbx+18]
       mov       r8d,[rbx+10]
       mov       edi,[rdx+8]
       cmp       r8d,edi
       ja        near ptr 000000000000F1D8
       mov       rdx,[rdx]
       mov       ecx,r8d
       lea       rbp,[rdx+rcx*2]
       sub       edi,r8d
       mov       rcx,[rbx]
       test      esi,esi
       jl        short 000000000000F173
       mov       [rsp+40],rbp
       mov       [rsp+48],edi
       lea       rdx,[rsp+40]
       lea       r8,[rsp+50]
       mov       ecx,esi
       call      qword ptr [0CF8]; Precode of System.Number.TryUInt32ToDecStr[[System.Char, System.Private.CoreLib]](UInt32, System.Span`1<Char>, Int32 ByRef)
M20_L01:
       test      eax,eax
       jne       short 000000000000F152
       mov       rcx,rbx
       call      qword ptr [4FF8]
       jmp       short 000000000000F100
M20_L02:
       mov       eax,[rsp+50]
       add       [rbx+10],eax
       jmp       short 000000000000F169
M20_L03:
       mov       rcx,rbx
       mov       edx,esi
       xor       r8d,r8d
       call      qword ptr [1B50]
M20_L04:
       nop
       add       rsp,58
       pop       rbx
       pop       rbp
       pop       rsi
       pop       rdi
       ret
M20_L05:
       test      rcx,rcx
       je        short 000000000000F180
       call      qword ptr [1260]; Precode of System.Globalization.NumberFormatInfo.<GetInstance>g__GetProviderNonNull|58_0(System.IFormatProvider)
       jmp       short 000000000000F186
M20_L06:
       call      qword ptr [1248]; Precode of System.Globalization.NumberFormatInfo.get_CurrentInfo()
M20_L07:
       mov       r8,[rax+28]
       test      r8,r8
       jne       short 000000000000F197
       xor       r9d,r9d
       xor       r8d,r8d
       jmp       short 000000000000F19F
M20_L08:
       lea       r9,[r8+0C]
       mov       r8d,[r8+8]
M20_L09:
       mov       [rsp+30],r9
       mov       [rsp+38],r8d
       mov       [rsp+40],rbp
       mov       [rsp+48],edi
       lea       r8,[rsp+50]
       mov       [rsp+20],r8
       lea       r8,[rsp+30]
       lea       r9,[rsp+40]
       mov       ecx,esi
       mov       edx,0FFFFFFFF
       call      qword ptr [0CE0]
       jmp       near ptr 000000000000F143
M20_L10:
       call      qword ptr [0F2B8]
       int       3
; Total bytes of code 255
```
```assembly
; System.Runtime.CompilerServices.DefaultInterpolatedStringHandler.ToStringAndClear()
       push      rdi
       push      rsi
       push      rbp
       push      rbx
       sub       rsp,38
       xor       eax,eax
       mov       [rsp+28],rax
       mov       rbx,rcx
       lea       rsi,[rbx+18]
       mov       rcx,rsi
       mov       eax,[rbx+10]
       cmp       eax,[rcx+8]
       ja        short 000000000000C6F7
       mov       rcx,[rcx]
       mov       [rsp+28],rcx
       mov       [rsp+30],eax
       lea       rcx,[rsp+28]
       call      qword ptr [0BB28]; Precode of System.String.Ctor(System.ReadOnlySpan`1<Char>)
       mov       rdi,rax
       mov       rbp,[rbx+8]
       xor       eax,eax
       mov       [rbx+8],rax
       mov       [rsi],rax
       mov       [rsi+8],rax
       mov       [rbx+10],eax
       test      rbp,rbp
       je        short 000000000000C6EB
       call      qword ptr [0A098]
       mov       rcx,[rax]
       mov       rdx,rbp
       xor       r8d,r8d
       cmp       [rcx],ecx
       call      qword ptr [98C0]; Precode of System.Buffers.SharedArrayPool`1[[System.Char, System.Private.CoreLib]].Return(Char[], Boolean)
M21_L00:
       mov       rax,rdi
       add       rsp,38
       pop       rbx
       pop       rbp
       pop       rsi
       pop       rdi
       ret
M21_L01:
       call      qword ptr [0F2B8]
       int       3
; Total bytes of code 126
```
```assembly
; Tedd.MortonEncoding.Encode(UInt32, UInt32, UInt32)
       push      rbp
       mov       rbp,rsp
       mov       [rbp+10],ecx
       mov       [rbp+18],edx
       mov       [rbp+20],r8d
       mov       eax,[rbp+20]
       mov       ecx,24924924
       pdep      eax,eax,ecx
       mov       ecx,[rbp+18]
       mov       edx,12492492
       pdep      ecx,ecx,edx
       or        eax,ecx
       mov       ecx,[rbp+10]
       mov       edx,9249249
       pdep      ecx,ecx,edx
       or        eax,ecx
       pop       rbp
       ret
; Total bytes of code 59
```
**Method was not JITted yet.**
Tedd.Voxtree.OctreeThrowHelper.ThrowInvalidView()
Tedd.Voxtree.OctreeThrowHelper.ThrowCoordinate(System.String, Int32)
Tedd.Voxtree.OctreeThrowHelper.ThrowMalformed()
System.String.StrCns(UInt32, IntPtr)
System.ObjectDisposedException..ctor(System.String)
System.ArgumentOutOfRangeException..ctor(System.String)
System.ThrowHelper.ThrowArgumentOutOfRangeException()
System.InvalidOperationException..ctor(System.String)
System.ArgumentOutOfRangeException..ctor(System.String, System.Object, System.String)

