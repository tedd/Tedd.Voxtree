using ChunkGeometry = global::Tedd.Forcecraft.Common.ChunkGeometry;
// Purpose: encode and decode exact block-type palettes shared by chunks and LOD payloads.
// Responsibilities: retain first-seen IDs, validate framing, and pack build-sized chunk indices without shared state.
// Design intent: private prepared indices allow independent complete-byte stores while preserving wire bytes.
using System;
using System.Buffers.Binary;

namespace Tedd.Forcecraft.Common.Models
{
    /// <summary>
    /// Palette compression for a 16-cubed array of block type ids, shared by the chunk wire/file format
    /// (<c>ChunkObjectBase</c>, payload <c>Constants.ChunkPayload_BlockTypeArrayPalette</c>) and by the LOD
    /// node payload (<c>LodPayloadCodec</c>).
    /// </summary>
    /// <remarks>
    /// <para>
    /// A terrain chunk holds a handful of distinct block types, so an index needs 1 to 8 bits rather than
    /// 16; the 8 KB raw array becomes 512 B to 4 KB before LZ4 even runs, and after LZ4 the measured wire
    /// size of a surface chunk drops from 511 to 191 bytes (<c>bench/README.md</c>).
    /// </para>
    /// <para>
    /// Body layout: <c>byte paletteCount | ushort[paletteCount] palette (little endian) | byte bitsPerIndex |
    /// packed indices</c>. Bits per index is 1, 2, 4 or 8 so a byte never straddles two entries and the
    /// slot arithmetic is a shift and a mask rather than a division per block.
    /// </para>
    /// </remarks>
    public static class BlockTypeArrayCodec
    {
        public const int BlockCount = Constants.ChunkSideLength * Constants.ChunkSideLength * Constants.ChunkSideLength;

        /// <summary>Largest palette the format allows; a chunk more varied than this is written raw.</summary>
        public const int MaxPaletteSize = 255;

        /// <summary>Upper bound on <see cref="TryWritePalette"/> output, for sizing a scratch buffer.</summary>
        public const int MaxPaletteBodyLength = 1 + MaxPaletteSize * 2 + 1 + BlockCount;

        /// <summary>True when every entry is the same value.</summary>
        public static bool IsUniform(ReadOnlySpan<ushort> types, out ushort value)
        {
            value = types.Length > 0 ? types[0] : (ushort)0;
            for (var i = 1; i < types.Length; i++)
            {
                if (types[i] != value)
                    return false;
            }
            return true;
        }

        /// <summary>
        /// Writes <paramref name="types"/> (exactly <see cref="BlockCount"/> entries) as a palette body.
        /// </summary>
        /// <returns>
        /// False when a palette would not save anything - more than <see cref="MaxPaletteSize"/> distinct
        /// types - in which case nothing is written and the caller should fall back to the raw array.
        /// </returns>
        public static bool TryWritePalette(ReadOnlySpan<ushort> types, Span<byte> destination, out int length)
        {
#if PERF_CHUNK_TRANSFER || PERF_CHUNK_TRANSFER_PALETTE_WRITE
            using var measure = Diagnostics.Telemetry.Measure(Diagnostics.ChunkTransferMetrics.PaletteWrite);
#endif
            return TryWritePaletteCore(types, destination, out length);
        }

        private static bool TryWritePaletteCore(ReadOnlySpan<ushort> types, Span<byte> destination, out int length)
        {
            length = 0;
            if (types.Length != BlockCount)
                throw new ArgumentException("Expected exactly " + BlockCount + " block types.", nameof(types));
            // Zero denotes an empty slot. The low byte stores palette index + 1; the upper
            // bits retain the full ushort type, including type zero and ushort.MaxValue.
            // Preparation uses 6,654 stack bytes and no shared mutable lookup state.
            Span<uint> table = stackalloc uint[512];
            table.Clear();
            Span<ushort> palette = stackalloc ushort[MaxPaletteSize];
            using var indicesScratch = new global::Tedd.Forcecraft.Common.ChunkScratch<byte>(ChunkGeometry.Side == 16 ? stackalloc byte[BlockCount] : default, BlockCount);
            Span<byte> indices = indicesScratch.Span;
            var count = 0;
            var previous = unchecked((ushort)(types[0] + 1));
            byte lastIndex = 0;
            for (var i = 0; i < types.Length; i++)
            {
                var type = types[i];
                if (type != previous)
                {
                    var slot = (int)(unchecked((uint)type * 2654435761u) >> 23);
                    // At most 255 of 512 slots are occupied. No deletion or resize, and full key equality.
                    while (table[slot] != 0 && (table[slot] >> 8) != type)
                        slot = (slot + 1) & 511;
                    if (table[slot] == 0)
                    {
                        if (count == MaxPaletteSize)
                            return false;
                        lastIndex = (byte)count;
                        palette[count++] = type;
                        table[slot] = ((uint)type << 8) | (uint)count;
                    }
                    else
                        lastIndex = (byte)((table[slot] & 255) - 1);
                    previous = type;
                }
                indices[i] = lastIndex;
            }
            var bits = BitsFor(count);
            var bytes = BlockCount * bits / 8;
            var total = 2 + 2 * count + bytes;
            if (destination.Length < total)
                throw new ArgumentException("Destination too small: need " + total + " bytes.", nameof(destination));
            destination[0] = (byte)count;
            for (var i = 0; i < count; i++)
                BinaryPrimitives.WriteUInt16LittleEndian(destination.Slice(1 + i * 2), palette[i]);
            destination[1 + count * 2] = (byte)bits;
            var packed = destination.Slice(2 + count * 2, bytes);
            PackIndices(indices, packed, bits);
            length = total;
            return true;
        }

        // Only the prepared chunk-index span reaches this helper. Width is 1, 2, 4 or 8,
        // each index fits that width, and packed is the exact validated destination slice.
        // Input scratch and caller-owned output are disjoint for the synchronous call.
        // Construct a whole byte before storing it: repeated |= stores serialize consecutive
        // indices through one destination address. Separate complete bytes have no such dependency.
        private static void PackIndices(ReadOnlySpan<byte> indices, Span<byte> packed, int bits)
        {
            switch (bits)
            {
                case 1:
                    for (var i = 0; i < packed.Length; i++)
                    {
                        var offset = i * 8;
                        var lo = (indices[offset] | (indices[offset + 1] << 1))
                            | ((indices[offset + 2] << 2) | (indices[offset + 3] << 3));
                        var hi = ((indices[offset + 4] << 4) | (indices[offset + 5] << 5))
                            | ((indices[offset + 6] << 6) | (indices[offset + 7] << 7));
                        packed[i] = (byte)(lo | hi);
                    }
                    break;
                case 2:
                    for (var i = 0; i < packed.Length; i++)
                    {
                        var offset = i * 4;
                        packed[i] = (byte)((indices[offset] | (indices[offset + 1] << 2))
                            | ((indices[offset + 2] << 4) | (indices[offset + 3] << 6)));
                    }
                    break;
                case 4:
                    for (var i = 0; i < packed.Length; i++)
                        packed[i] = (byte)(indices[i * 2] | (indices[i * 2 + 1] << 4));
                    break;
                case 8:
                    indices.CopyTo(packed);
                    break;
                default: throw new ArgumentOutOfRangeException(nameof(bits));
            }
        }

        /// <summary>Bits per index, rounded up to a divisor of 8 so a byte never straddles two entries.</summary>
        public static int BitsFor(int paletteCount)
        {
            if (paletteCount <= 2) return 1;
            if (paletteCount <= 4) return 2;
            if (paletteCount <= 16) return 4;
            return 8;
        }

        /// <summary>Reads a palette body written by <see cref="TryWritePalette"/> into <paramref name="types"/>.</summary>
        /// <exception cref="ArgumentException">The body is malformed or truncated.</exception>
        public static void ReadPalette(ReadOnlySpan<byte> body, Span<ushort> types)
        {
            if (types.Length < BlockCount)
                throw new ArgumentException("Destination must hold " + BlockCount + " block types.", "types");
            if (body.Length < 2)
                throw new ArgumentException("Palette body is truncated.", "body");

            var paletteCount = body[0];
            if (paletteCount == 0 || body.Length < 2 + paletteCount * 2)
                throw new ArgumentException("Palette body is malformed.", "body");

            Span<ushort> palette = stackalloc ushort[paletteCount];
            for (var p = 0; p < paletteCount; p++)
                palette[p] = BinaryPrimitives.ReadUInt16LittleEndian(body.Slice(1 + p * 2));

            var bits = body[1 + paletteCount * 2];
            if (bits != 1 && bits != 2 && bits != 4 && bits != 8)
                throw new ArgumentException("Palette body has an unsupported index width: " + bits + ".", "body");

            var packedBytes = (BlockCount * bits + 7) / 8;
            var packed = body.Slice(2 + paletteCount * 2);
            if (packed.Length < packedBytes)
                throw new ArgumentException("Palette body is truncated.", "body");

            var perByteShift = bits == 1 ? 3 : bits == 2 ? 2 : bits == 4 ? 1 : 0;
            var slotMask = (1 << perByteShift) - 1;
            var mask = (1 << bits) - 1;

            for (var i = 0; i < BlockCount; i++)
            {
                var b = packed[i >> perByteShift];
                var index = (b >> ((i & slotMask) * bits)) & mask;
                if (index >= paletteCount)
                    throw new ArgumentException("Palette body references index " + index + " of a " + paletteCount + " entry palette.", "body");
                types[i] = palette[index];
            }
        }
    }
}
