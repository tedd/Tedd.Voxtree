// Purpose: bound stack usage for build-time chunk layouts without recurring large-array allocations.
// Responsibilities: borrow a caller's small stack buffer or lease an exact-length view of pooled storage.
// Design intent: 16-cube builds keep their stack path; larger builds return scratch even on exceptions.
using System.Buffers;
using System.Runtime.CompilerServices;

namespace Tedd.Forcecraft.Common;

public ref struct ChunkScratch<T> where T : unmanaged
{
    private T[] _rented;
    public Span<T> Span { get; private set; }

    [MethodImpl(MethodImplOptions.AggressiveInlining)]
    public ChunkScratch(Span<T> stack, int length)
    {
        _rented = stack.Length >= length ? null : ArrayPool<T>.Shared.Rent(length);
        Span = _rented == null ? stack[..length] : _rented.AsSpan(0, length);
        // Match newly allocated scratch semantics; never expose data from the previous borrower.
        if (_rented != null) Span.Clear();
    }

    [MethodImpl(MethodImplOptions.AggressiveInlining)]
    public void Dispose()
    {
        if (_rented != null) ArrayPool<T>.Shared.Return(_rented);
        _rented = null;
        Span = default;
    }
}
