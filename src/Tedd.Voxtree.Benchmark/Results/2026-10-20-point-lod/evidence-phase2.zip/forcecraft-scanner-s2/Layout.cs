// The offline reader is bound to layout 5, independently of the game's current build setting.
namespace Tedd.Forcecraft.Common;
public static class Constants { public const int ChunkSideLength = 32; }
public static class ChunkGeometry { public const int Side = 32; }
