// Offline, read-only region census. Never loads Forcecraft or opens its stores.
using System.Buffers.Binary;
using System.Security.Cryptography;
using System.Text.Json;
using K4os.Compression.LZ4;

if (args.Length != 2) throw new ArgumentException("world-directory output-directory");
var source = Path.GetFullPath(args[0]);
var output = Path.GetFullPath(args[1]);
if (!output.StartsWith(@"D:\Workspaces\AI\voxtree-point-lod-20261020\", StringComparison.OrdinalIgnoreCase))
    throw new ArgumentException("Output must be task-local.");
Directory.CreateDirectory(output);
var samples = Path.Combine(output, "samples");
Directory.CreateDirectory(samples);
var cache = new Dictionary<string, Statistics>();
var selected = new Dictionary<string, object>();
var files = new List<object>();
var payloadCounts = new SortedDictionary<ushort, long>();
var payloadBytes = new SortedDictionary<ushort, long>();
long records = 0, blockRecords = 0;
using var csv = new StreamWriter(Path.Combine(output, "chunks.csv"));
csv.WriteLine("region,slot,payload_bytes,block_encoding,voxel_sha256,distinct,maximum,nonzero,linear_runs,uniform_2cubes,lod0,lod1,lod2,lod3,lod4,lod5,stratum");
foreach (var path in Directory.GetFiles(source, "*.region", SearchOption.AllDirectories).Order(StringComparer.Ordinal))
{
    // FileShare.Read denies concurrent writers for the duration of this file's census.
    using var stream = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.Read);
    var before = Convert.ToHexString(SHA256.HashData(stream));
    stream.Position = 0;
    var header = Read(stream, 32);
    Require(header.AsSpan(0, 4).SequenceEqual("FCRG"u8), "Region magic");
    Require(U16(header, 4) == 1 && header[6] == 5 && header[7] == 9 && header[12] == 5, "Unsupported region/chunk layout");
    Require(U32(header, 8) == 32768 && header.AsSpan(13).IndexOfAnyExcept((byte)0) < 0, "Region header");
    var table = Read(stream, 32768 * 8);
    var relative = Path.GetRelativePath(source, path).Replace('\\', '/');
    long fileRecords = 0;
    for (int slot = 0; slot < 32768; slot++)
    {
        var sector = U32(table, slot * 8);
        var length = U32(table, slot * 8 + 4);
        if (sector == 0) { Require(length == 0, "Empty slot length"); continue; }
        Require(sector >= 513 && length is >= 2 and <= 67108864 && sector * 512L + 12 + length <= stream.Length, "Record bounds");
        stream.Position = sector * 512L;
        var record = Read(stream, 12);
        Require(record.AsSpan(0, 4).SequenceEqual("CHNK"u8) && U32(record, 4) == length, "Record header");
        var envelope = Read(stream, checked((int)length));
        Require(Crc32(envelope) == U32(record, 8), "Record CRC");
        Require(envelope[0] == 5 && envelope[1] <= 1, "Envelope version/compression");
        var body = envelope[1] == 1 ? LZ4Pickler.Unpickle(envelope.AsSpan(2)) : envelope[2..];
        Require(body.Length >= 2 && body.Length <= 67108864, "Payload bounds");
        int count = U16(body, 0), cursor = 2;
        ushort[]? voxels = null;
        ushort encoding = 0;
        for (int p = 0; p < count; p++)
        {
            Require(cursor <= body.Length - 6, "Payload header");
            var id = U16(body, cursor);
            var size = BinaryPrimitives.ReadInt32LittleEndian(body.AsSpan(cursor + 2));
            cursor += 6;
            Require(size >= 0 && size <= body.Length - cursor, "Payload length");
            var payload = body.AsSpan(cursor, size);
            cursor += size;
            payloadCounts[id] = payloadCounts.GetValueOrDefault(id) + 1;
            payloadBytes[id] = payloadBytes.GetValueOrDefault(id) + size;
            if (id is 2 or 3 or 6)
            {
                Require(voxels == null, "Duplicate block payload");
                encoding = id;
                voxels = Decode(id, payload);
            }
        }
        Require(cursor == body.Length, "Trailing payload bytes");
        records++; fileRecords++;
        if (voxels == null) continue;
        blockRecords++;
        var raw = new byte[voxels.Length * 2];
        for (int i = 0; i < voxels.Length; i++) BinaryPrimitives.WriteUInt16LittleEndian(raw.AsSpan(i * 2), voxels[i]);
        var hash = Convert.ToHexString(SHA256.HashData(raw));
        if (!cache.TryGetValue(hash, out var stats)) cache[hash] = stats = Analyze(voxels);
        csv.WriteLine($"{relative},{slot},{length},{encoding},{hash},{stats.Distinct},{stats.Maximum},{stats.Nonzero},{stats.Runs},{stats.Uniform2},{string.Join(',', stats.LodVoxels)},{stats.Stratum}");
        // Prospective selection: first lexical region/slot for each semantic stratum.
        // Timing does not participate in selection; every chunk remains in chunks.csv.
        if (!selected.ContainsKey(stats.Stratum))
        {
            var sampleName = stats.Stratum + ".u16le";
            File.WriteAllBytes(Path.Combine(samples, sampleName), raw);
            selected[stats.Stratum] = new { region = relative, slot, sampleName, hash, statistics = stats };
        }
    }
    stream.Position = 0;
    var after = Convert.ToHexString(SHA256.HashData(stream));
    Require(before == after, "Source changed during census");
    files.Add(new { region = relative, bytes = stream.Length, sha256 = before, records = fileRecords });
    Console.WriteLine($"{relative}: {fileRecords} records");
}
csv.Flush();
var report = new { format = "Forcecraft region v1, chunk layout 5 (32 cubed), LZ4 pickle envelope", records, blockRecords,
    uniqueVoxelArrays = cache.Count, files, payloadCounts, payloadBytes, selection = "First lexical region and slot per predeclared semantic stratum; full census retained", samples = selected };
File.WriteAllText(Path.Combine(output, "census.json"), JsonSerializer.Serialize(report, new JsonSerializerOptions { WriteIndented = true }));
Console.WriteLine($"Total: {records} records; {blockRecords} block records; {cache.Count} unique voxel arrays; {selected.Count} strata");

static Statistics Analyze(ushort[] v)
{
    int distinct = v.Distinct().Count(), runs = 1, nonzero = 0, uniform2 = 0;
    ushort maximum = 0;
    for (int i = 0; i < v.Length; i++) { maximum = Math.Max(maximum, v[i]); if (v[i] != 0) nonzero++; if (i > 0 && v[i] != v[i - 1]) runs++; }
    var lod = new long[6];
    void Visit(int x, int y, int z, int level)
    {
        int side = 1 << level;
        ushort first = v[(x * 32 + y) * 32 + z];
        bool same = true;
        for (int a = x; a < x + side && same; a++)
            for (int b = y; b < y + side && same; b++)
                for (int c = z; c < z + side; c++)
                    if (v[(a * 32 + b) * 32 + c] != first) { same = false; break; }
        if (same) { lod[level] += 1L << (3 * level); return; }
        Require(level > 0, "Leaf equality");
        int half = side / 2;
        for (int a = 0; a < 2; a++) for (int b = 0; b < 2; b++) for (int c = 0; c < 2; c++) Visit(x + a * half, y + b * half, z + c * half, level - 1);
    }
    Visit(0, 0, 0, 5);
    for (int x = 0; x < 32; x += 2) for (int y = 0; y < 32; y += 2) for (int z = 0; z < 32; z += 2)
    {
        ushort first = v[(x * 32 + y) * 32 + z];
        bool same = true;
        for (int a = 0; a < 2; a++) for (int b = 0; b < 2; b++) for (int c = 0; c < 2; c++) same &= v[((x + a) * 32 + y + b) * 32 + z + c] == first;
        if (same) uniform2++;
    }
    Require(lod.Sum() == 32768, "LOD coverage");
    string topology = distinct == 1 ? "uniform" : lod[0] == 0 ? "coarse" : uniform2 == 0 ? "full" : "mixed";
    string width = maximum < 128 ? "u7" : maximum < 256 ? "u8" : "u16";
    string density = nonzero == 0 ? "empty" : nonzero == v.Length ? "solid" : "air";
    return new(distinct, maximum, nonzero, runs, uniform2, lod, $"{topology}-{width}-{density}");
}
static ushort[] Decode(ushort id, ReadOnlySpan<byte> body)
{
    var result = new ushort[32768];
    if (id == 2) { Require(body.Length == 2, "Mono length"); Array.Fill(result, BinaryPrimitives.ReadUInt16BigEndian(body)); }
    else if (id == 3) { Require(body.Length == result.Length * 2, "Raw length"); for (int i = 0; i < result.Length; i++) result[i] = BinaryPrimitives.ReadUInt16LittleEndian(body[(i * 2)..]); }
    else
    {
        Require(body.Length >= 2, "Palette header");
        int count = body[0];
        Require(count > 0 && body.Length >= 2 + count * 2, "Palette table");
        int bits = body[1 + count * 2];
        Require(bits is 1 or 2 or 4 or 8, "Palette width");
        var packed = body[(2 + count * 2)..];
        Require(packed.Length == result.Length * bits / 8, "Palette length");
        for (int i = 0; i < result.Length; i++)
        {
            int index = (packed[i * bits / 8] >> ((i * bits) & 7)) & ((1 << bits) - 1);
            Require(index < count, "Palette index");
            result[i] = BinaryPrimitives.ReadUInt16LittleEndian(body[(1 + index * 2)..]);
        }
    }
    return result;
}
static byte[] Read(Stream s, int size) { var bytes = new byte[size]; s.ReadExactly(bytes); return bytes; }
static ushort U16(byte[] b, int offset) => BinaryPrimitives.ReadUInt16LittleEndian(b.AsSpan(offset));
static uint U32(byte[] b, int offset) => BinaryPrimitives.ReadUInt32LittleEndian(b.AsSpan(offset));
static void Require(bool condition, string message) { if (!condition) throw new InvalidDataException(message); }
static uint Crc32(ReadOnlySpan<byte> b) { uint crc = uint.MaxValue; foreach (byte x in b) { crc ^= x; for (int i = 0; i < 8; i++) crc = (crc >> 1) ^ ((crc & 1) != 0 ? 0xEDB88320u : 0); } return ~crc; }
record Statistics(int Distinct, ushort Maximum, int Nonzero, int Runs, int Uniform2, long[] LodVoxels, string Stratum);
