param([string]$HostFile,[string]$Output)
$ErrorActionPreference='Stop'
. $HostFile
try {
    $lease=Enter-VoxtreePerformanceHost -DriverPath $PSCommandPath
    try { @{admitted=$true;rejected=$false} | ConvertTo-Json | Set-Content -LiteralPath $Output }
    finally {Exit-VoxtreePerformanceHost $lease}
} catch {
    if($_.Exception.Message -notlike 'queued_driver_changed:*'){throw}
    @{admitted=$false;rejected=$true;reason=$_.Exception.Message} | ConvertTo-Json | Set-Content -LiteralPath $Output
}
